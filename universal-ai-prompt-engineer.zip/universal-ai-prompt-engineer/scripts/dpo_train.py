"""
DPO (Direct Preference Optimization) Training for Stable Diffusion
===================================================================
Enhances model aesthetics and alignment with human preferences.

Usage:
  python scripts/dpo_train.py --base_model <path_to_sd_weights> \
      --data_dir <preference_pairs_dir> --output <output_path> \
      --beta 0.1 --lr 1e-6 --steps 1000

Preference data format (JSON lines):
  {"prompt": "...", "chosen_tokens": [...], "rejected_tokens": [...],
   "chosen_image": "path/to/chosen.png", "rejected_image": "path/to/rejected.png"}

Or with pre-encoded latents:
  {"prompt": "...", "chosen_tokens": [...], "rejected_tokens": [...],
   "chosen_latent": "path/to/chosen.pt", "rejected_latent": "path/to/rejected.pt"}
"""

import argparse
import copy
import json
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

# Import model from sd_model
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sd_model import StableDiffusionModel, load_weights


class PreferenceDataset(Dataset):
    """
    Dataset for DPO preference pairs.
    Each item: (prompt_tokens, chosen_latent, rejected_latent, timestep)
    """

    def __init__(self, data_path: str, first_stage_model=None, latent_scale: float = 0.18215):
        self.items = []
        self.first_stage = first_stage_model
        self.latent_scale = latent_scale

        with open(data_path, "r") as f:
            for line in f:
                line = line.strip()
                if line:
                    self.items.append(json.loads(line))

    def __len__(self):
        return len(self.items)

    def _encode_image_to_latent(self, image_path):
        """Encode an image file to latent using VAE encoder."""
        try:
            from PIL import Image
            import torchvision.transforms as T
        except ImportError:
            raise ImportError("PIL and torchvision required for image encoding")

        img = Image.open(image_path).convert("RGB")
        transform = T.Compose([
            T.Resize(512),
            T.CenterCrop(512),
            T.ToTensor(),
            T.Normalize([0.5], [0.5]),
        ])
        img_tensor = transform(img).unsqueeze(0)

        if self.first_stage is not None:
            with torch.no_grad():
                mean, logvar = self.first_stage.encode(img_tensor)
                z = self.first_stage.reparameterize(mean, logvar)
                return z.squeeze(0) * self.latent_scale
        return img_tensor.squeeze(0)

    def __getitem__(self, idx):
        item = self.items[idx]
        tokens = torch.tensor(item["chosen_tokens"], dtype=torch.long)

        # Load chosen latent
        if "chosen_latent" in item:
            chosen = torch.load(item["chosen_latent"], map_location="cpu")
        elif "chosen_image" in item:
            chosen = self._encode_image_to_latent(item["chosen_image"])
        else:
            chosen = torch.randn(4, 64, 64)

        # Load rejected latent
        if "rejected_latent" in item:
            rejected = torch.load(item["rejected_latent"], map_location="cpu")
        elif "rejected_image" in item:
            rejected = self._encode_image_to_latent(item["rejected_image"])
        else:
            rejected = torch.randn(4, 64, 64)

        # Random timestep
        t = torch.randint(0, 1000, (1,)).long()

        return {"tokens": tokens, "chosen": chosen, "rejected": rejected, "t": t}


def collate_fn(batch):
    """Custom collate for variable-size data."""
    tokens = torch.stack([b["tokens"] for b in batch])
    chosen = torch.stack([b["chosen"] for b in batch])
    rejected = torch.stack([b["rejected"] for b in batch])
    t = torch.cat([b["t"] for b in batch])
    return {"tokens": tokens, "chosen": chosen, "rejected": rejected, "t": t}


class DPOTrainer:
    """
    Direct Preference Optimization trainer for Stable Diffusion.

    DPO loss optimizes the policy model to prefer chosen over rejected samples
    while staying close to the reference model (KL constraint via beta).

    Loss = -log_sigmoid(beta * (log_pi_chosen - log_ref_chosen
                                - log_pi_rejected + log_ref_rejected))
    """

    def __init__(self, policy_model: StableDiffusionModel,
                 ref_model: StableDiffusionModel,
                 beta: float = 0.1, lr: float = 1e-6):
        self.policy = policy_model
        self.ref = ref_model
        self.beta = beta
        self.optimizer = torch.optim.AdamW(
            self.policy.unet.parameters(), lr=lr, weight_decay=0.01
        )
        self.latent_scale = policy_model.latent_scale

    def _get_log_prob(self, model, latent, tokens, t):
        """
        Compute log probability of latent under the model.
        Uses noise prediction to estimate log p(x_0 | x_t, text).
        """
        text_emb = model.get_text_embedding(tokens)

        # Add noise
        noise = torch.randn_like(latent)
        noisy_latent, _ = model.scheduler.add_noise(latent, t)

        # Predict noise
        pred_noise = model.unet(noisy_latent, t, text_emb)

        # MSE as negative log-likelihood proxy
        mse = F.mse_loss(pred_noise, noise, reduction="none")
        # Average over spatial dims, sum over channels
        log_prob = -mse.mean(dim=[1, 2, 3])
        return log_prob

    def compute_loss(self, batch):
        """Compute DPO loss for a batch of preference pairs."""
        tokens = batch["tokens"]
        chosen = batch["chosen"]
        rejected = batch["rejected"]
        t = batch["t"]

        device = next(self.policy.parameters()).device
        tokens = tokens.to(device)
        chosen = chosen.to(device)
        rejected = rejected.to(device)
        t = t.to(device)

        # Policy model log probs
        log_pi_chosen = self._get_log_prob(self.policy, chosen, tokens, t)
        log_pi_rejected = self._get_log_prob(self.policy, rejected, tokens, t)

        # Reference model log probs (no grad)
        with torch.no_grad():
            log_ref_chosen = self._get_log_prob(self.ref, chosen, tokens, t)
            log_ref_rejected = self._get_log_prob(self.ref, rejected, tokens, t)

        # DPO loss
        rewards = self.beta * (
            (log_pi_chosen - log_ref_chosen) - (log_pi_rejected - log_ref_rejected)
        )
        loss = -F.logsigmoid(rewards).mean()

        # Metrics
        with torch.no_grad():
            accuracy = (rewards > 0).float().mean()
            reward_margin = rewards.mean()

        return loss, {
            "dpo_loss": loss.item(),
            "accuracy": accuracy.item(),
            "reward_margin": reward_margin.item(),
            "log_pi_chosen": log_pi_chosen.mean().item(),
            "log_pi_rejected": log_pi_rejected.mean().item(),
        }

    def train_step(self, batch):
        """Single training step."""
        self.optimizer.zero_grad()
        loss, metrics = self.compute_loss(batch)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.policy.unet.parameters(), 1.0)
        self.optimizer.step()
        return metrics


def main():
    parser = argparse.ArgumentParser(description="DPO Training for Stable Diffusion")
    parser.add_argument("--base_model", type=str, required=True, help="Path to base SD weights (.ckpt/.safetensors)")
    parser.add_argument("--data_dir", type=str, required=True, help="Path to preference data JSONL file")
    parser.add_argument("--output", type=str, default="dpo_model.safetensors", help="Output model path")
    parser.add_argument("--beta", type=float, default=0.1, help="KL penalty coefficient")
    parser.add_argument("--lr", type=float, default=1e-6, help="Learning rate")
    parser.add_argument("--steps", type=int, default=1000, help="Training steps")
    parser.add_argument("--batch_size", type=int, default=1, help="Batch size")
    parser.add_argument("--log_interval", type=int, default=10, help="Log every N steps")
    parser.add_argument("--save_interval", type=int, default=100, help="Save checkpoint every N steps")
    parser.add_argument("--fp16", action="store_true", default=True, help="Use FP16")
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    device = torch.device(args.device)

    # Build policy model and load base weights
    print("[INFO] Building policy model...")
    policy = StableDiffusionModel()
    load_info = load_weights(policy, args.base_model)
    print(f"[INFO] Base model loaded: {load_info}")

    if args.fp16:
        policy = policy.to_fp16()
    policy = policy.to(device)

    # Build reference model (frozen copy)
    print("[INFO] Building reference model (frozen copy)...")
    ref = StableDiffusionModel()
    load_weights(ref, args.base_model)
    if args.fp16:
        ref = ref.to_fp16()
    ref = ref.to(device)
    ref.eval()
    for p in ref.parameters():
        p.requires_grad = False

    # Dataset
    print(f"[INFO] Loading preference data from {args.data_dir}...")
    dataset = PreferenceDataset(args.data_dir, first_stage_model=policy.first_stage)
    dataloader = DataLoader(
        dataset, batch_size=args.batch_size, shuffle=True,
        collate_fn=collate_fn, drop_last=True
    )

    # Trainer
    trainer = DPOTrainer(policy, ref, beta=args.beta, lr=args.lr)

    # Training loop
    print(f"[INFO] Starting DPO training: beta={args.beta}, lr={args.lr}, steps={args.steps}")
    global_step = 0
    data_iter = iter(dataloader)

    while global_step < args.steps:
        try:
            batch = next(data_iter)
        except StopIteration:
            data_iter = iter(dataloader)
            batch = next(data_iter)

        metrics = trainer.train_step(batch)
        global_step += 1

        if global_step % args.log_interval == 0:
            print(json.dumps({
                "step": global_step,
                **metrics,
            }, indent=2))

        if global_step % args.save_interval == 0:
            save_path = f"{args.output}.step{global_step}"
            torch.save(policy.unet.state_dict(), save_path)
            print(f"[INFO] Checkpoint saved: {save_path}")

    # Final save
    torch.save(policy.unet.state_dict(), args.output)
    print(json.dumps({
        "status": "success",
        "message": "DPO training completed",
        "output": args.output,
        "total_steps": global_step,
        "final_metrics": metrics,
    }, indent=2))


if __name__ == "__main__":
    main()
