"""
LoRA (Low-Rank Adaptation) Fine-Tuning for Stable Diffusion
=============================================================
Efficiently fine-tune SD model for specific styles/domains.
Only trains 0.1-1% of parameters via low-rank decomposition.

Usage:
  python scripts/lora_train.py \
      --base_model ./sd_weights.safetensors \
      --data_dir ./training_images/ \
      --output ./my_style_lora.pt \
      --rank 16 --lr 1e-4 --steps 500

Data formats (choose one):
  1. Image dir + caption txt: each image has a same-name .txt file
     training_images/
       img001.png
       img001.txt  (contains: "a beautiful sunset over mountains")
       img002.png
       img002.txt  (contains: ...)

  2. JSONL manifest:
     {"image": "img001.png", "caption": "a beautiful sunset"}
     {"image": "img002.png", "caption": "a cat sitting on a chair"}
"""

import argparse
import copy
import glob
import json
import math
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sd_model import StableDiffusionModel, load_weights, CrossAttentionLayer


# =============================================================================
# LoRA Implementation
# =============================================================================

class LoRALinear(nn.Module):
    """
    Low-Rank Adaptation of a Linear layer.
    W' = W + (alpha/r) * B @ A
    where A: (rank, in_features), B: (out_features, rank)
    Only A and B are trainable; W is frozen.
    """

    def __init__(self, original_linear: nn.Linear, rank: int = 16, alpha: float = 16.0):
        super().__init__()
        self.original = original_linear
        self.rank = rank
        self.alpha = alpha
        self.scaling = alpha / rank

        in_features = original_linear.in_features
        out_features = original_linear.out_features

        # Low-rank matrices (initialized small)
        self.lora_A = nn.Parameter(torch.randn(rank, in_features) * 0.01)
        self.lora_B = nn.Parameter(torch.zeros(out_features, rank))

        # Freeze original weights
        for p in self.original.parameters():
            p.requires_grad = False

    def forward(self, x):
        # Original output + low-rank delta
        original_out = self.original(x)
        lora_out = (x @ self.lora_A.T) @ self.lora_B.T * self.scaling
        return original_out + lora_out

    def merge_weights(self):
        """Merge LoRA weights into original linear layer (for inference)."""
        with torch.no_grad():
            delta = (self.lora_B @ self.lora_A) * self.scaling
            self.original.weight += delta
            if self.original.bias is not None:
                pass  # bias unchanged
        return self.original


def inject_lora(model, rank: int = 16, alpha: float = 16.0, target_modules=None):
    """
    Inject LoRA into cross-attention layers of UNet.
    Targets: k_proj and v_proj (Linear layers in CrossAttentionLayer).

    Args:
        model: StableDiffusionModel
        rank: LoRA rank (4-32, higher = more capacity but more params)
        alpha: LoRA alpha scaling factor
        target_modules: list of module name substrings to target (default: k_proj, v_proj)
    Returns:
        dict mapping module paths to LoRALinear instances
    """
    if target_modules is None:
        target_modules = ["k_proj", "v_proj"]

    lora_layers = {}

    for name, module in model.unet.named_modules():
        if isinstance(module, nn.Linear):
            if any(target in name for target in target_modules):
                parent_path = ".".join(name.split(".")[:-1])
                attr_name = name.split(".")[-1]

                # Navigate to parent
                parent = model.unet
                for part in parent_path.split("."):
                    if part:
                        parent = getattr(parent, part)

                # Replace with LoRA version
                lora_layer = LoRALinear(module, rank=rank, alpha=alpha)
                setattr(parent, attr_name, lora_layer)
                lora_layers[name] = lora_layer

    return lora_layers


def get_lora_parameters(model):
    """Get only trainable LoRA parameters."""
    lora_params = []
    for name, param in model.named_parameters():
        if "lora_A" in name or "lora_B" in name:
            lora_params.append(param)
    return lora_params


def count_lora_params(model):
    """Count LoRA parameters vs total."""
    lora_count = sum(p.numel() for n, p in model.named_parameters()
                     if "lora_A" in n or "lora_B" in n)
    total_count = sum(p.numel() for p in model.parameters())
    return lora_count, total_count


def save_lora_weights(model, path: str):
    """Save only LoRA weights (small file, easy to distribute)."""
    lora_state = {}
    for name, param in model.named_parameters():
        if "lora_A" in name or "lora_B" in name:
            lora_state[name] = param.data.cpu().clone()
    torch.save(lora_state, path)
    size_mb = os.path.getsize(path) / (1024 * 1024)
    return {"status": "success", "path": path, "keys": len(lora_state), "size_mb": round(size_mb, 2)}


def load_lora_weights(model, path: str):
    """Load LoRA weights into model."""
    lora_state = torch.load(path, map_location="cpu")
    missing, unexpected = [], []
    for name, param in model.named_parameters():
        if name in lora_state:
            param.data.copy_(lora_state[name])
        elif "lora_A" in name or "lora_B" in name:
            missing.append(name)
    return {"status": "success", "loaded": len(lora_state), "missing": len(missing)}


# =============================================================================
# Training Dataset
# =============================================================================

class ImageCaptionDataset(Dataset):
    """
    Dataset for LoRA training: image + text caption pairs.
    Supports two formats:
      1. Image directory with same-name .txt caption files
      2. JSONL manifest with image path and caption
    """

    def __init__(self, data_path: str, image_size: int = 512, tokenizer_fn=None):
        self.items = []
        self.image_size = image_size
        self.tokenizer_fn = tokenizer_fn

        if os.path.isfile(data_path) and data_path.endswith(".jsonl"):
            # JSONL format
            with open(data_path, "r") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        item = json.loads(line)
                        self.items.append({
                            "image": item["image"],
                            "caption": item["caption"],
                        })
        elif os.path.isdir(data_path):
            # Directory format: images + .txt captions
            for img_path in sorted(glob.glob(os.path.join(data_path, "*"))):
                ext = os.path.splitext(img_path)[1].lower()
                if ext in (".png", ".jpg", ".jpeg", ".webp", ".bmp"):
                    txt_path = os.path.splitext(img_path)[0] + ".txt"
                    caption = ""
                    if os.path.exists(txt_path):
                        with open(txt_path, "r") as f:
                            caption = f.read().strip()
                    if caption:
                        self.items.append({"image": img_path, "caption": caption})
        else:
            raise ValueError(f"Invalid data path: {data_path}. Use a directory or .jsonl file.")

        if len(self.items) == 0:
            raise ValueError(f"No training data found in {data_path}")

    def __len__(self):
        return len(self.items)

    def _load_image(self, path):
        """Load and preprocess image to tensor."""
        try:
            from PIL import Image
            import torchvision.transforms as T
        except ImportError:
            # Fallback: generate random tensor (for testing without PIL)
            return torch.randn(3, self.image_size, self.image_size)

        img = Image.open(path).convert("RGB")
        transform = T.Compose([
            T.Resize(self.image_size),
            T.CenterCrop(self.image_size),
            T.ToTensor(),
            T.Normalize([0.5], [0.5]),
        ])
        return transform(img)

    def _tokenize(self, text):
        """Simple tokenizer: hash-based pseudo tokenization for demo."""
        # In production, use CLIP tokenizer or similar
        tokens = torch.zeros(77, dtype=torch.long)
        words = text.lower().split()
        for i, word in enumerate(words[:77]):
            tokens[i] = hash(word) % 49408
        return tokens

    def __getitem__(self, idx):
        item = self.items[idx]
        image = self._load_image(item["image"])

        if self.tokenizer_fn:
            tokens = self.tokenizer_fn(item["caption"])
        else:
            tokens = self._tokenize(item["caption"])

        return {"image": image, "tokens": tokens, "caption": item["caption"]}


def collate_fn(batch):
    images = torch.stack([b["image"] for b in batch])
    tokens = torch.stack([b["tokens"] for b in batch])
    captions = [b["caption"] for b in batch]
    return {"images": images, "tokens": tokens, "captions": captions}


# =============================================================================
# Training Loop
# =============================================================================

def train_lora(model, dataloader, args):
    """
    LoRA training loop.
    Freezes all original weights, only trains LoRA A/B matrices.
    """
    device = torch.device(args.device)

    # Freeze everything except LoRA
    for p in model.parameters():
        p.requires_grad = False
    for p in get_lora_parameters(model):
        p.requires_grad = True

    lora_params = get_lora_parameters(model)
    lora_count, total_count = count_lora_params(model)

    print(json.dumps({
        "lora_params": f"{lora_count:,}",
        "total_params": f"{total_count:,}",
        "trainable_ratio": f"{lora_count / total_count * 100:.2f}%",
        "rank": args.rank,
        "training_samples": len(dataloader.dataset),
    }, indent=2))

    optimizer = torch.optim.AdamW(lora_params, lr=args.lr, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.steps)

    model.train()
    global_step = 0
    data_iter = iter(dataloader)
    running_loss = 0.0

    while global_step < args.steps:
        try:
            batch = next(data_iter)
        except StopIteration:
            data_iter = iter(dataloader)
            batch = next(data_iter)

        images = batch["images"].to(device)
        tokens = batch["tokens"].to(device)

        # Forward pass (training mode)
        noise_pred, noise_target, noisy_z = model(images, tokens,
                                                    t=torch.randint(0, 1000, (images.shape[0],), device=device))

        # MSE loss between predicted and actual noise
        loss = F.mse_loss(noise_pred.float(), noise_target.float())

        # Backward
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(lora_params, 1.0)
        optimizer.step()
        scheduler.step()

        running_loss += loss.item()
        global_step += 1

        if global_step % args.log_interval == 0:
            avg_loss = running_loss / args.log_interval
            lr = optimizer.param_groups[0]["lr"]
            print(json.dumps({
                "step": global_step,
                "loss": round(avg_loss, 6),
                "lr": f"{lr:.2e}",
            }))
            running_loss = 0.0

        if global_step % args.save_interval == 0 and global_step < args.steps:
            save_path = f"{args.output}.step{global_step}"
            info = save_lora_weights(model, save_path)
            print(f"[INFO] Checkpoint saved: {info}")

    # Final save
    info = save_lora_weights(model, args.output)
    return info


# =============================================================================
# Entry Point
# =============================================================================

def main():
    parser = argparse.ArgumentParser(description="LoRA Fine-Tuning for Stable Diffusion")
    parser.add_argument("--base_model", type=str, required=True, help="Path to base SD weights (.ckpt/.safetensors)")
    parser.add_argument("--data_dir", type=str, required=True, help="Training data: image directory or .jsonl file")
    parser.add_argument("--output", type=str, default="lora_weights.pt", help="Output LoRA weights path")
    parser.add_argument("--rank", type=int, default=16, help="LoRA rank (4-32, default 16)")
    parser.add_argument("--alpha", type=float, default=16.0, help="LoRA alpha scaling (default 16.0)")
    parser.add_argument("--lr", type=float, default=1e-4, help="Learning rate (default 1e-4)")
    parser.add_argument("--weight_decay", type=float, default=0.01, help="Weight decay")
    parser.add_argument("--steps", type=int, default=500, help="Training steps")
    parser.add_argument("--batch_size", type=int, default=1, help="Batch size")
    parser.add_argument("--image_size", type=int, default=512, help="Training image size")
    parser.add_argument("--log_interval", type=int, default=10, help="Log every N steps")
    parser.add_argument("--save_interval", type=int, default=100, help="Save checkpoint every N steps")
    parser.add_argument("--fp16", action="store_true", default=True, help="Use FP16")
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--target_modules", type=str, nargs="+", default=["k_proj", "v_proj"],
                        help="Module name substrings to apply LoRA (default: k_proj v_proj)")
    parser.add_argument("--merge", action="store_true", help="Merge LoRA into base model and save full weights")
    args = parser.parse_args()

    device = torch.device(args.device)

    # Build model and load base weights
    print("[INFO] Building model...")
    model = StableDiffusionModel()
    load_info = load_weights(model, args.base_model)
    print(f"[INFO] Base model loaded: {load_info}")

    if args.fp16:
        model = model.to_fp16()
    model = model.to(device)

    # Freeze VAE and text encoder (only train UNet LoRA)
    for p in model.first_stage.parameters():
        p.requires_grad = False
    for p in model.text_encoder.parameters():
        p.requires_grad = False

    # Inject LoRA into UNet cross-attention
    print(f"[INFO] Injecting LoRA (rank={args.rank}, alpha={args.alpha}) into: {args.target_modules}")
    lora_layers = inject_lora(model, rank=args.rank, alpha=args.alpha, target_modules=args.target_modules)
    lora_count, total_count = count_lora_params(model)
    print(f"[INFO] LoRA params: {lora_count:,} / {total_count:,} ({lora_count/total_count*100:.2f}%)")

    # Dataset
    print(f"[INFO] Loading training data from: {args.data_dir}")
    dataset = ImageCaptionDataset(args.data_dir, image_size=args.image_size)
    dataloader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True,
                            collate_fn=collate_fn, drop_last=True)
    print(f"[INFO] Training samples: {len(dataset)}")

    # Train
    print(f"[INFO] Starting LoRA training: {args.steps} steps, lr={args.lr}")
    result = train_lora(model, dataloader, args)

    # Optional: merge LoRA into base model
    if args.merge:
        print("[INFO] Merging LoRA weights into base model...")
        for name, layer in lora_layers.items():
            layer.merge_weights()
        merge_path = args.output.replace(".pt", "_merged.pt")
        torch.save(model.unet.state_dict(), merge_path)
        result["merged_path"] = merge_path

    result["message"] = "LoRA training completed"
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
