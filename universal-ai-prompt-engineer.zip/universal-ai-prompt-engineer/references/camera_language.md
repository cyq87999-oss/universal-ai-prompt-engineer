# ③ 镜头语言 (Camera Language) - 完整数据

## 景别分类详解

### 1. 远景/大全景 (Extreme Long Shot / Establishing Shot)

**定义**: 展示广阔环境，人物在画面中占比很小（通常小于画面高度的1/8）。

**作用**: 
- 建立场景（establishing shot）
- 展示环境与人物的关系
- 表现人物的渺小或环境的宏大
- 用于开场或转场

**使用场景**:
- 电影开场建立世界观
- 展示壮丽自然风光
- 表现人物的孤独/渺小
- 战争场面、灾难场面

**即梦提示词示例**:
```
wide shot, establishing shot, vast landscape, tiny figure in enormous environment, epic scale, panoramic view, extreme long shot, environmental context
远景大全景，广阔天地间渺小的人物身影，史诗般的规模，全景视角，环境交代
```

**注意事项**: 人物面部细节无法看清，不适合需要表现情绪的场景

---

### 2. 全景 (Full Shot / Wide Shot)

**定义**: 展示人物全身及周围环境，人物从头顶到脚底完整呈现。

**作用**:
- 展示人物完整姿态和服装
- 展示人物与环境的空间关系
- 适合动作场景、舞蹈场景
- 保持一定的环境信息

**使用场景**:
- 武打/动作场面
- 时装展示
- 走路/奔跑的动作
- 人物互动（保持距离时）

**即梦提示词示例**:
```
full shot, wide shot, full body visible, complete figure, entire posture shown, surrounding environment, character in context
全景，完整展现人物全身，周围环境可见，完整姿态，人物在环境之中
```

---

### 3. 中景 (Medium Shot)

**定义**: 拍摄人物膝盖以上的部分（对话场景中最常用）。

**作用**:
- 对话场景的标准景别
- 展示上半身肢体语言
- 保持一定环境但聚焦人物
- 最自然的观看距离感

**使用场景**:
- 两人或多人对白
- 采访/访谈
- 一般叙事段落
- 日常场景

**即梦提示词示例**:
```
medium shot, waist up, upper body framing, conversational shot, natural viewing distance, balanced character and environment
中景，腰部以上构图，对话场景常用景别，自然的观看距离
```

---

### 4. 中近景 (Medium Close-Up)

**定义**: 拍摄人物胸部以上，比中景更聚焦于人物。

**作用**:
- 强调面部表情和情绪
- 更亲密的观看感受
- 适合独白、内心戏
- 减少环境干扰

**使用场景**:
- 重要对话的特写反应
- 独白、内心活动
- 歌唱表演
- 情感交流

**即梦提示词示例**:
```
medium close-up, chest up, intimate framing, focused on face and expression, reduced environment, emotional emphasis
中近景，胸部以上构图，聚焦面部表情，减少环境干扰，强调情感
```

---

### 5. 近景/特写 (Close-Up)

**定义**: 拍摄人物胸部或头部，面部占据画面主要部分。

**作用**:
- 强烈的情感传达
- 展示细微表情变化
- 与观众建立情感连接
- 制造亲密感或压迫感

**使用场景**:
- 情绪高潮
- 重要发现/揭示
- 泪水、笑容等关键表情
- 制造紧张感

**即梦提示词示例**:
```
close-up, tight framing on face, intense emotion, detailed facial features, intimate perspective, eye contact possible
近景/特写，紧密的面部构图，强烈情感，细腻的表情细节，亲密视角
```

---

### 6. 大特写 (Extreme Close-Up / Insert Shot)

**定义**: 只拍摄面部局部（眼睛/嘴唇）或某个重要物体细节。

**作用**:
- 极致的强调
- 制造悬念或揭示关键信息
- 抽象化（只看局部引发想象）
- 强烈的感官刺激

**使用场景**:
- 眼睛特写（情绪/觉醒）
- 嘴唇特写（亲吻/说话）
- 关键道具特写（信件/武器/戒指）
- 某个细节的揭示

**即梦提示词示例**:
```
extreme close-up, insert shot, detail shot, eyes only, lips only, object detail, intense focus, macro view, partial face
大特写，极致局部聚焦，眼部/唇部/道具细节，宏观视角，画面局部
```

---

## 运镜方式详解

### 固定镜头 (Static Shot / Fixed Camera)

**定义**: 相机位置完全不动，所有运动来自被摄体。

**效果**:
- 稳定、客观、纪实感
- 让观众自行观察画面
- 可以营造静谧或紧张（取决于内容）
- 经典电影美学

**变体**:
- **潜望镜头 (Proxy Shot)**: 固定位置但通过某种框架看
- ** POV静态**: 角色视线方向的固定镜头

**提示词**: `static camera, fixed position, stationary shot, tripod shot, locked-off, no camera movement`

---

### 推镜头 (Dolly In / Push In)

**定义**: 相机向主体方向移动靠近。

**效果**:
- 强调主体重要性
- 制造压迫感、紧张感
- 引导观众注意力
- 情绪递进

**速度变体**:
- **缓慢推**: 温柔、亲密、逐渐发现
- **快速推**: 冲击、震惊、紧急
- **斯坦尼康推**: 平滑推进，沉浸感

**提示词**: `dolly in, push in, moving closer, camera approaches subject, advancing shot, closing in, slow push in, dolly zoom in`

---

### 拉镜头 (Dolly Out / Pull Back)

**定义**: 相机远离主体移动。

**效果**:
- 揭示更多环境信息
- 表现孤独、疏离、失落
- 从具体到抽象/从小到大
- 结束段的收束感

**经典用法**:
- 从人物脸部拉远到显示其独自一人
- 从细节拉远揭示完整场景
- 结尾镜头拉远表示故事的结束

**提示词**: `dolly out, pull back, camera retreats, revealing shot, zoom out, pulling away, widening view, reveal environment`

---

### 摇镜头 (Pan)

**定义**: 相机水平方向转动（左右摇）。

**效果**:
- 扫描环境（跟眼神或注意力）
- 展示宽广场景（超出画面范围）
- 发现（从A摇到B，B是重点）
- 连接两个相关元素

**类型**:
- **左摇/右摇 (Pan Left/Right)**: 标准水平转动
- **甩镜头 (Swish Pan)**: 快速模糊转动
- **全景摇 (Panoramic)**: 180°或更大范围扫描

**提示词**: `pan left, pan right, panning shot, camera pans, horizontal movement, scanning view, swish pan, whip pan, panoramic sweep`

---

### 移镜头 (Tracking Shot / Dolly Shot)

**定义**: 相机平行跟随主体移动（通常在侧面）。

**效果**:
- 跟随主体的沉浸感
- 展示运动过程
- 与角色并肩的感觉
- 行走/奔跑时的陪伴感

**变体**:
- **侧跟踪 (Lateral Tracking)**: 在侧面平行移动
- **弧形轨道 (Arc Shot)**: 围绕主体弧形运动
- **环绕轨道 (Orbit/Circular)**: 360度围绕主体

**提示词**: `tracking shot, dolly alongside, lateral movement, following subject, side tracking, arc shot, orbit shot, circular camera movement, 360 degree rotation`

---

### 升降镜头 (Crane Shot / Boom Shot)

**定义**: 相机垂直方向上下移动（通常借助摇臂/无人机）。

**效果**:
- **上升 (Crane Up/Bird's Eye)**: 俯瞰、上帝视角、揭示全局
- **下降 (Crane Down)**: 从宏观到微观、进入场景
- 展示规模（升降能体现空间高度）
- 戏剧性的进入/离开

**使用场景**:
- 从高空俯冲到人物面前
- 从人物升起展示战场全貌
- 开场的宏大建立镜头

**提示词**: `crane shot, boom up, boom down, rising camera, descending shot, aerial descent, bird's eye reveal, dramatic vertical movement, jib shot`

---

### 旋转镜头 (Spin Shot / 360° Orbit)

**定义**: 相机围绕主体360度旋转。

**效果**:
- 迷幻、眩晕感
- 展示全方位的环境
- 表现角色的混乱/失控
- 超现实的视觉冲击
- 时间流逝感（配合变速）

**使用注意**:
- 容易造成观众不适，需谨慎使用
- 适合表现：变身、魔法释放、意识混沌、时空扭曲

**提示词**: `spinning shot, 360° orbit, rotating camera, swirling motion, dizzying spin, revolving around subject, circular tracking, whirlwind effect`

---

### 手持拍摄 (Handheld Camera)

**定义**: 模拟手持拍摄的抖动感。

**效果**:
- 真实感、临场感
- 纪录片美学
- 紧张、混乱、危险
- 主观视角增强

**强度分级**:
- **轻微手持**: 轻微呼吸感，自然真实
- **中等手持**: 明显晃动，紧张追踪
- **剧烈手持**: 混乱、逃亡、战斗第一人称

**适用类型**:
- 纪录片风格
- 恐怖片（伪纪录片风格）
- 战争/动作场面
- 主观视角跑动

**提示词**: `handheld camera, shaky cam, documentary style, natural camera shake, unstable footage, found footage aesthetic, immersive wobble, raw handheld feel`

---

### 航拍/无人机拍摄 (Aerial Shot / Drone Shot)

**定义**: 从空中俯拍或飞越场景。

**效果**:
- 宏大、壮观、史诗感
- 上帝视角（全知视角）
- 展示地理格局和环境关系
- 自由翱翔的感觉

**航拍类型**:
- **俯视 (Top-down/Aerial View)**: 正上方或斜上方俯拍
- **鸟瞰 (Bird's Eye)**: 高角度几乎垂直向下
- **FPV穿越 (FPV Flythrough)**: 第一人称高速飞越
- **轨道航拍 (Orbit Aerial)**: 空中环绕某物
- **拉升/俯冲 (Drone Rise/Dive)**: 垂直方向的运动

**提示词**: `aerial shot, drone view, bird's eye view, overhead shot, flying above, drone footage, FPV drone flight, sweeping aerial, god's eye view, satellite perspective`

---

### 变焦镜头 (Zoom) - 特殊说明

**注意**: 变焦（光学放大）和推镜头（物理移动）是不同的！

**推近变焦 (Zoom In)**:
- 快速推近 = 冲击力、震惊（《惊魂记》浴室戏）
- 缓慢变焦 = 注意力集中

**拉远变焦 (Zoom Out)**:
- 信息揭示

**希区柯克变焦 (Dolly Zoom / Vertigo Effect)**:
- 同时推拉（相机后退+变焦推近）
- 背景变形但主体大小不变
- 表现眩晕、时空扭曲、精神异常
- 也称 "Vertigo effect"

**提示词**: `zoom in, zoom out, rapid zoom, Hitchcock zoom, dolly zoom, Vertigo effect, focal length change, telephoto compression`

---

## 拍摄角度详解

### 平视角度 (Eye Level)

**定义**: 相机高度与人物视线齐平（约1.5-1.7米）。

**心理效果**:
- 平等、客观、中立
- 最自然、最常用的角度
- 观众与角色平等交流

**使用场景**:
- 大多数日常场景
- 对话场景（双方平等）
- 纪录片采访
- 新闻报道

**提示词**: `eye level, neutral angle, straight on, natural viewpoint, standard height, human eye perspective`

---

### 仰角拍摄 (Low Angle)

**定义**: 相机从低于主体的位置向上拍摄。

**心理效果**:
- 主体显得高大、威严、强大
- 观众处于弱势/仰望位置
- 英雄、权威、威胁的表现

**程度差异**:
- **轻微仰角**: 稍显高大（英雄主角）
- **中度仰角**: 明显高大（领导、强者）
- **极端仰角/虫视 (Worm's Eye)**: 非常庞大、压迫感（巨人、怪物、摩天大楼）

**使用场景**:
- 英雄登场
- 表现反派威胁
- 拍摄建筑/雕像
- 表现儿童的视角（成人世界）

**提示词**: `low angle, looking up, worm's eye view, heroic angle, imposing perspective, towering figure, beneath the subject, upward gaze`

---

### 俯角拍摄 (High Angle)

**定义**: 相机从高于主体的位置向下拍摄。

**心理效果**:
- 主体显得渺小、脆弱、无力
- 观众处于优势/掌控位置
- 可怜、孤立、易受伤的感觉

**程度差异**:
- **轻微俯角**: 稍显弱势
- **中度俯角**: 明显渺小
- **极端俯角/鸟瞰 (Bird's Eye)**: 几乎垂直向下，主体成为图案的一部分

**使用场景**:
- 表现角色的无助/脆弱
- 展示尸体/失败者
- 上帝视角俯瞰
- 表现孩子的视角（从楼上往下看）

**提示词**: `high angle, looking down, bird's eye view, overhead shot, dominating perspective, vulnerable figure, above the subject, diminished stature`

---

### 倾斜角度 (Dutch Angle / Canted Angle)

**定义**: 相机故意倾斜，画面地平线不水平。

**心理效果**:
- 不安、紧张、失衡
- 某种事情不对劲
- 精神错乱、迷失方向
- 动态、非稳定

**倾斜角度参考**:
- **轻度 (5-10°)**: 微妙的不安
- **中度 (10-25°)**: 明显的不稳定、紧张
- **重度 (25-45°)**: 严重失衡、疯狂、动作场景

**使用场景**:
- 恐怖片、惊悚片
- 角色的精神崩溃
- 梦境/幻觉场景
- 动作片的动态镜头

**提示词**: `Dutch angle, canted frame, tilted camera, off-kilter, disoriented angle, uneasy perspective, slanted horizon, tilted composition`

---

### 过肩镜头 (Over-the-Shoulder Shot / OTS)

**定义**: 从一个人的肩膀后方拍摄另一个人，肩膀占据画面前景一部分。

**作用**:
- 对话场景的标准镜头
- 建立空间关系（两人相对）
- 代入感（观众"站在"说话者身后）
- 可以切换正反打（180°规则）

**变体**:
- ** clean OTS**: 肩膀干净清晰，不过曝
- ** dirty OTS**: 肩膀略微失焦，更有层次

**提示词**: `over-the-shoulder shot, OTS, behind shoulder view, conversation framing, two-shot setup, reverse angle potential`

---

### 主观视角 (Point-of-View Shot / POV)

**定义**: 相机代替角色的眼睛，观众看到角色看到的。

**效果**:
- 极强的代入感和沉浸感
- 限制信息（只能看到角色看到的）
- 适合恐怖片（不知道背后有什么）
- 第一人称体验

**类型**:
- **第一人称POV**: 完全替代角色眼睛（射击游戏视角）
- **主观反应镜头**: 看到角色看到的东西后切到角色反应
- **POV手持**: 带着手持抖动的主观视角（更真实）

**提示词**: `point-of-view shot, POV, first-person perspective, through the eyes, subjective camera, immersion shot, character's viewpoint, what the character sees`

---

## 经典镜头组合模板

### 模板1: 三镜头法则 (Three-Shot Rule)

用于对话场景的经典剪辑模式：

```
镜头A: A说话的中景（或中近景）
镜头B: B听话的反应（过肩或正面）
镜头C: B回答的中景
（可选）镜头D: A听话的反应

即梦实现方式：分别生成三个镜头再拼接
```

### 模板2: 建立-细节-重建 (Establishing-Detail-Re-establish)

```
镜头1: 远景建立场景（我在哪里？）
镜头2: 推进/切到主体（谁在这里？）
镜头3: 特写关键细节（什么重要？）
镜头4: 拉回或切回全景（回到整体语境）
```

### 模板3: 情绪递进序列

```
镜头1: 远景 - 环境铺垫（冷静/客观）
镜头2: 全景 - 人物入场（开始关注）
镜头3: 中景 - 开始行动/对话（参与其中）
镜头4: 近景 - 情绪显现（情感连接）
镜头5: 特写 - 情绪高潮/关键细节（最大冲击）
镜头6: （可选）拉远 - 余韵/结束（回味）
```

### 模板4: 悬念揭示序列

```
镜头1: 神秘的全景（有些不对劲...）
镜头2: 移动摇镜（寻找源头...）
镜头3: 发现的特写！（是什么？！）
镜头4: 反应镜头（角色的恐惧/震惊）
```
