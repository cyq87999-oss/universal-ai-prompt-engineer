## 项目概述
- **名称**: 短视频自动生成工作流
- **功能**: 根据用户提供的视频主题，自动完成剧本创作、图片生成、视频生成和视频剪辑，最终输出一条完整短视频

### 节点清单
| 节点名 | 文件位置 | 类型 | 功能描述 | 分支逻辑 | 配置文件 |
|-------|---------|------|---------|---------|---------|
| script_writing | `nodes/script_writing_node.py` | agent | 使用豆包大模型根据主题创作分场景剧本 | - | `config/script_writing_llm_cfg.json` |
| batch_image_gen | `nodes/batch_image_gen_node.py` | looparray | 批量生成每个场景的图片 | - | - |
| batch_video_gen | `nodes/batch_video_gen_node.py` | looparray | 将每张图片转换为短视频片段（即梦） | - | - |
| video_edit | `nodes/video_edit_node.py` | task | 拼接视频片段、添加转场和字幕 | - | - |

**类型说明**: task(task节点) / agent(大模型) / condition(条件分支) / looparray(列表循环) / loopcond(条件循环)

## 子图清单
| 子图名 | 文件位置 | 功能描述 | 被调用节点 |
|-------|---------|------|---------|-----------|
| image_gen_loop | `graphs/loop_graph.py` | 单次图片生成逻辑 | batch_image_gen（函数内调用） |

## 技能使用
- 节点`script_writing`使用大语言模型技能（doubao-seed-2-0-pro-260215）
- 节点`batch_image_gen`使用图片生成技能（doubao-seedream-5-0-260128）
- 节点`batch_video_gen`使用视频生成技能（doubao-seedance-1-5-pro-251215）
- 节点`video_edit`使用视频编辑技能