# ⑤ 人物服装 (Character Costume) - 完整数据

## 服装风格大类详解

### 1. 现代休闲 (Modern Casual)

**核心特征**: 舒适、日常、无拘束，反映当代生活方式。

**中文关键词库**:
```
基础单品:
  T恤: 白T恤、印花T恤、oversize T恤、复古T恤
  下装: 牛仔裤(直筒/紧身/阔腿/破洞)、休闲裤、短裤、短裙
  外套: 卫衣、连帽衫(hoodie)、棒球夹克、牛仔外套
  鞋履: 运动鞋(sneakers)、帆布鞋、拖鞋、靴子

风格细分:
  - 街头风(streetwear): oversize、球鞋、棒球帽、项链
  - 运动风(athleisure): 瑜伽裤、运动bra、机能风外套
  - 极简风(minimalist casual): 纯色基础款、剪裁利落、质感面料
  - 复古风(vintage): 古着、高腰牛仔裤、条纹衫、复古配色

典型穿搭描述:
  "身穿白色Oversize T恤配浅蓝色直筒牛仔裤，脚踩白色板鞋，随性自然"
  "黑色连帽卫衣+灰色运动束脚裤，街头潮流感十足"
  "浅色牛仔外套内搭白色吊带裙，清新甜美"
```

**英文关键词**:
```
casual wear, t-shirt and jeans, hoodie, sneakers, streetwear, athleisure, relaxed fit, everyday clothes, comfortable fashion, urban casual, minimalist basics, vintage denim
```

---

### 2. 正式礼服 (Formal Wear / Evening Wear)

**核心特征**: 庄重、优雅、精致，适用于重要场合。

#### 男士正装
| 单品 | 中文 | 英文 | 细节变体 |
|------|------|------|----------|
| 西装 | 西装套装、三件套 | suit, three-piece tuxedo | 黑色/深蓝/深灰/格纹 |
| 衬衫 | 正装衬衫、法式袖扣 | dress shirt, formal shirt | 白色/淡蓝/粉色 |
| 领带/领结 | 丝质领带、蝴蝶领结 | silk tie, bow tie | 波点/条纹/纯色 |
| 皮鞋 |牛津鞋、德比鞋 | Oxford shoes, Derby shoes | 黑色/棕色抛光 |
| 配饰 | 袖扣、胸针、手表 | cufflinks, lapel pin, wristwatch | 金/银/宝石 |

#### 女士礼服
| 类别 | 描述 | 英文关键词 |
|------|------|-----------|
| 晚礼服 | 长款拖地礼服、露背、抹胸 | evening gown, floor-length gown, backless dress, strapless gown |
| 小黑裙 | 经典黑色及膝裙 | little black dress, LBD, cocktail dress |
| 婚纱 | 白色婚纱、头纱、拖尾 | wedding dress, bridal gown, veil, train |
| 旗袍 | 中式晚礼服、修身开叉 | qipao, cheongsam, Chinese evening dress |
| 套装裙 | 上衣+半身裙的正式套装 | skirt suit, tailored ensemble |

**提示词模板**:
```
男士: "身着深蓝色三件套西装，搭配白色法式叠袖衬衫和深红色丝质领带，黑色牛津鞋抛光锃亮"
女士: "身穿一袭香槟金色露背晚礼服，裙摆曳地，珍珠项链点缀颈间，手持小巧手包"
```

---

### 3. 传统服饰 (Traditional Costume)

#### 中华传统服饰
| 服饰类型 | 特征 | 适用场景 |
|----------|------|----------|
| **汉服** | 交领右衽、宽袍大袖、系带 | 古风日常、雅集、摄影 |
| - 襦裙 | 上襦下裙、齐胸/齐腰 | 唐风、少女感 |
| - 曲裾/直裾 | 深衣制式、庄重 | 秦汉风、正式古风 |
| - 明制袄裙 | 立领对襟、马面裙 | 明清风、端庄大气 |
| **旗袍/长衫** | 修身立领、盘扣、开叉 | 民国风、优雅女性 |
| **少数民族服饰** | 各民族特色（藏/蒙/苗/彝等） | 民族风情、地域特色 |
| **戏曲服** | 京昆越剧戏服、水袖、头面 | 戏曲表演、国粹元素 |

**汉服详细关键词**:
```
形制: 交领、右衽、宽袖、窄袖、大襟、对襟、立领
纹样: 刺绣、云纹、回纹、龙凤、花卉、几何纹样
颜色: 
  - 传统五色: 青、赤、黄、白、黑
  - 雅致色: 月白、天青、藕荷、黛绿、胭脂
材质:丝绸、麻、棉、绫罗绸缎
配饰: 发簪、步摇、玉佩、香囊、团扇、油纸伞
```

#### 世界其他传统服饰
| 文化 | 服饰名称 | 特征 |
|------|----------|------|
| 日本 | 和服(Kimono)/浴衣(Yukata) | 宽袖长袍、宽腰带(obi)、木屐 |
| 韩国 | 韩服(Hanbok) | 短上衣+高腰长裙、鲜艳色彩 |
| 印度 | 纱丽(Sari)/杜帕塔(Dupatta) | 缠裹式长布、刺绣镶边 |
| 越南 | 奥黛(Ao Dai) | 高开叉长裙、同料外搭 |
| 苏格兰 | 格子呢裙(Kilt) | 格纹、毛呢、苏格兰帽 |
| 阿拉伯 | 长袍(Thobe/Dishdasha) | 白色长袍、头巾(Keffiyeh) |
| 欧洲（历史） | 蕾丝长裙、宫廷礼服、骑士盔甲 | 不同时代差异大 |

---

### 4. 科幻装备 (Sci-Fi Gear)

**核心特征**: 未来科技感、非常规材料、功能性设计。

#### 子类别

**机甲/动力装甲 (Mecha / Powered Armor)**
```
特征: 金属外壳、发光部件、关节机械结构、厚重感
关键词: mech suit, powered armor, exoskeleton, metal plating, glowing circuits, mechanical joints, battle robot suit
参考: 《钢铁侠》《环太平洋》《高达》
细节: 胸炉反应堆、头盔HUD显示、推进器喷射口
```

**宇航装备 (Space Suit)**
```
特征: 白色/橙色厚实防护服、圆形头盔、生命维持系统
关键词: astronaut suit, space gear, EVA suit, helmet visor, NASA-style spacesuit, futuristic astronaut
细节: 反光面罩、国旗补丁、工具 tether线
```

**未来战衣 (Future Combat Suit)**
```
特征: 紧身但功能性、战术模块、轻量化装甲
关键词: futuristic combat suit, tactical gear, light armor, nanotech suit, stealth operative outfit
细节: 夜视目镜、多功能腰带、手臂终端
```

**赛博朋克义体 (Cybernetic Augmentations)**
```
特征: 机械义肢、可见线路、发光植入物、人机混合
关键词: cybernetic arm, robotic leg, neural implant, glowing augmentations, chrome body parts, biomechanical fusion
细节: 机械手臂、发光义眼、脊椎接口、金属骨骼
参考: 《攻壳机动队》《赛博朋克2077》《阿丽塔》
```

---

### 5. 奇幻服装 (Fantasy Costume)

**核心特征**: 超越现实、魔法属性、高度装饰性。

#### 角色原型服装

**法师/巫师 (Mage / Wizard)**
```
特征: 长袍(wizard robe)、尖顶帽(wizard hat)、星月图案、神秘符文
关键词: wizard robe, pointed hat, arcane symbols, mystical garment, star-embroidered cloak, flowing magic robes
配色: 深蓝/紫色/星空黑 + 金银色符文
道具: 法术书(grimoire)、法杖(staff)、水晶球
细节: 宽大的袖子可以隐藏手势、兜帽下的阴影遮住面部
```

**精灵族 (Elf)**
```
特征: 优雅轻盈、自然材质（树叶/皮革）、精致工艺
Keywords: elven garb, leaf-woven armor, elegant tunic, nature-inspired clothing, ethereal fabric, silver embroidery
配色: 绿/银/白/金（森林精灵）、白/蓝（高等精灵）
细节: 尖耳朵露出、披风如翅膀般飘逸、腰间佩细剑
```

**战士/骑士 (Warrior / Knight)**
```
特征: 盔甲(knight armor)、披风(cloak/tabard)、武器装备
Keywords: plate armor, chainmail, knight's surcoat, heraldic cape, sword belt, armored boots
配色: 金属银/钢 + 家族徽章颜色
细节: 护肩(spaulders)、护手(gauntlets)、盾牌纹章
```

**公主/贵族 (Princess / Noble)**
```
特征: 华丽礼服长裙、皇冠/冕冠、珠宝首饰
Keywords: princess gown, royal dress, tiara, velvet cloak, embroidered ballgown, jeweled accessories
配色: 粉/金/白（童话）、红/紫/金（皇室）
细节: 长长的头纱、精致的刺绣、多层裙撑
```

**刺客/盗贼 (Assassin / Rogue)**
```
特征: 深色紧身衣、兜帽、面具/面罩、实用腰带
Keywords: assassin's hood, dark leather armor, shadowy cloak, masked face, utility belt, hidden blades
配色: 黑/深灰/暗红 + 皮棕色
细节: 多个口袋和刀鞘、兜帽遮挡面部、轻便软底靴
```

---

### 6. 运动装备 (Sportswear)

**分类与关键词**:

| 运动 | 典型装备 | 关键词 |
|------|----------|--------|
| 跑步 | 紧身运动leggings、跑鞋、运动bra | running outfit, compression wear, running shoes, athletic tank |
| 瑜伽/健身 | 瑜伽裤、运动内衣、防滑袜 | yoga pants, sports bra, leggings, fitness attire, gym wear |
| 篮球 | 球衣(jersey)、篮球鞋、护腕 | basketball jersey, sneakers, wristbands, athletic shorts |
| 足球 | 球服、足球鞋、长袜 | soccer kit, cleats, long socks, team jersey |
| 游泳 | 泳衣/泳裤、泳镜、泳帽 | swimsuit, bikini, swim trunks, goggles, swim cap |
| 网球 |网球裙/短裤、网球鞋 | tennis skirt/dress, tennis shoes, sporty chic |
| 滑板/极限 |宽松T恤、工装裤、滑板鞋 | skate wear, loose fit, cargo pants, Vans-style shoes |
| 武术/格斗 |道服(gi)、拳击短裤、缠手带 | martial arts uniform, gi, boxing shorts, hand wraps |
| 自行车 |骑行服(bib shorts)、头盔、骑行手套 | cycling kit, lycra suit, aerodynamic helmet, cycling gloves |
| 滑雪/滑雪 |滑雪服、雪镜、手套、头盔 | ski suit, snow goggles, insulated jacket, snow gear |

---

### 7. 职业制服 (Professional Uniform)

| 职业 | 制服特征 | 关键词 |
|------|----------|--------|
| 医生 | 白大褂、听诊器、手术服(scrubs) | white lab coat, stethoscope, medical scrubs, doctor's coat |
| 护士 | 护士服、护士帽、舒适鞋子 | nurse uniform, scrubs, nurse cap, clogs |
| 警察 | 制服、警徽、腰带装备、警帽 | police uniform, badge, duty belt, police cap, tactical vest |
| 军人 | 军装、军衔标志、作战装备 | military uniform, camouflage fatigues, combat boots, dog tags |
| 消防员 | 防火服、头盔、氧气瓶 | firefighter gear, fire-resistant suit, oxygen tank, helmet |
| 飞行员 | 飞行服、墨镜、飞行员帽 | flight suit, aviator sunglasses, pilot cap, bomber jacket |
| 厨师 | 双排扣厨师服(chef's coat)、厨师高帽 | chef's whites, toque blanche, apron, checkered pants |
| 机长/空乘 | 机组制服、丝巾、帽子 | pilot uniform, flight attendant uniform, scarf, peaked cap |
| 学生 | 校服（各地不同） | school uniform, sailor fuku (日式), blazer and tie (英式), tracksuit (中式）|
| 快餐店员工 | 制服、围裙、名牌 | fast food uniform, apron, name tag, branded colors |

---

### 8. 破旧/战损服装 (Worn / Battle-Damaged Clothing)

**用途**: 末世、战争、流浪、冒险后等场景。

| 破损类型 | 视觉效果 | 关键词 |
|----------|----------|--------|
| 破烂衣衫 | 破洞、撕裂、褪色 | tattered clothes, torn fabric, rags, frayed edges, worn-out garments |
| 战损盔甲 | 凹陷、划痕、掉漆 | battle-damaged armor, dented plate, scratched metal, chipped paint |
| 血迹污渍 | 血渍、泥土、烟灰 | bloodstained, dirty, soot-covered, mud-splattered, grime |
| 衣不蔽体 | 撕裂严重、勉强遮体 | ragged, barely covering, exposed skin through tears |
| 末日拾荒 | 拼凑的多件衣服、不合身 | scavenged gear, mismatched layers, ill-fitting, post-apocalyptic fashion |
| 海难漂流 | 湿透、盐渍、晒脱色 | soaked, salt-stained, sun-bleached, water-damaged |
| 古代战袍 | 刀痕箭孔、血迹斑斑 | war-torn robe, arrow-pierced, sword-scarred, battlefield-worn |

---

## 材质关键词库

### 柔软材质 (Soft Materials)
| 材质 | 视觉/触觉特征 | 关键词 |
|------|----------------|--------|
| 棉麻 | 天然纹理、透气感、轻微褶皱 | cotton, linen, natural fiber, breathable texture, slight wrinkles |
| 丝绸/缎面 | 光泽顺滑、垂坠感强、反光 | silk, satin, glossy, smooth, lustrous, draping elegantly |
| 天鹅绒 | 绒面、光泽变化、厚重温暖 | velvet, velvety texture, plush, soft sheen, rich pile |
| 针织 | 可见针脚纹理、弹性、保暖 | knit, knitted texture, woolen, cozy weave, ribbed pattern |
| 蕾网 | 透明镂空图案、精致脆弱 | lace, fishnet, delicate pattern, sheer, intricate, fragile |
| 薄纱 | 半透明、飘动轻盈 | chiffon, tulle, gauze, sheer fabric, translucent, ethereal drape |
| 皮草 | 毛茸茸、奢华保暖 | fur, fluffy, plush, luxurious, warm, soft pelts |
| 羊绒 | 极柔软细腻、轻薄保暖 | cashmere, softest wool, fine texture, lightweight warmth |

### 硬挺材质 (Rigid/Hard Materials)
| 材质 | 特征 | 关键词 |
|------|------|--------|
| 牛仔 | 斜纹织法、耐磨、可做旧 | denim, jean fabric, durable, rugged, faded wash, indigo |
| 皮革 | 光泽、有韧性、可定型 | leather, hide, supple grain, smooth surface, structured |
| 金属（装饰用） | 冷光、坚硬、链甲 | metallic, chainmail, armor plates, cold shine, industrial |
| 盔甲 | 金属或硬塑料、防护性 | armor, plate mail, protective shell, rigid structure |
| 塑料/PVC | 人造光泽、可透明 | plastic, PVC, synthetic sheen, glossy artificial |
| 硬挺棉麻（制服类） | 浆洗过、保持形状 | starched, crisp, pressed, formal stiffness |

### 特殊材质 (Special Materials)
| 材质 | 效果 | 使用场景 |
|------|------|----------|
| 乳胶/橡胶 | 紧贴身体、高光、未来感 | 赛博朋克、科幻、前卫时尚 |
| 荧光/反光材料 | 在光线下发亮 | 夜间场景、舞台、安全服 |
| 液态面料 | 如水般流动、贴合曲线 | 未来主义服装、魔法效果 |
| 3D打印材料 | 参数化结构、非传统编织 | 高度科幻、外星服装 |
| 生物有机材料 | 似皮肤/植物、会呼吸 | 外星种族、奇幻生物 |
| 半透明欧根纱 | 若隐若现、层次丰富 | 礼服层叠、仙气效果 |
| 全息投影材质 | 图案可变化、发光 | 科幻、虚拟形象 |

---

## 配饰系统完整库

### 头部配饰 (Head Accessories)
| 类别 | 示例 | 风格联想 |
|------|------|----------|
| **帽子** | 棒球帽、渔夫帽、贝雷帽、礼帽(top hat/bowler/fedora)、针织帽、牛仔帽、安全帽 | 休闲/文艺/正式/工装 |
| **发饰** | 发簪、发卡、发带(headband)、皇冠(tiara/crown)、王冠、花环 | 古风/少女/皇室/自然 |
| **眼镜** | 墨镜(sunglasses)、圆框眼镜、眼镜链、单片眼镜、护目镜 | 酷/文艺/学术/蒸汽朋克/赛博 |
| **耳饰** | 耳环(earrings)、耳钉(studs)、耳坠(drops)、耳廓夹 | 各种风格 |
| **面饰** | 面具(mask)、面纱(veil)、眼罩(eyepatch)、妆容(makeup) | 假面舞会/婚礼/海盗/哥特 |
| **头巾/头套** | 丝巾、穆斯林头巾(hijab)、绷带、兜帽(hood) | 复古/宗教/受伤/暗黑 |

### 颈部配饰 (Neck Accessories)
| 配饰 | 关键词 | 风格 |
|------|--------|------|
| 项链 (necklace) | 金链/银链/宝石项链/chocker/tassel necklace | 各种风格 |
| 围巾 (scarf) | 丝绸围巾、羊毛围巾、长围巾 | 优雅/保暖/文艺 |
| 领带 (tie) | 丝质领带、针织领、领结(bow tie) | 正式/学院 |
| 披肩/斗篷 (cape/shawl) | 丝绒披肩、皮草围脖、长斗篷 | 皇室/奇幻/时尚 |

### 手部配饰 (Hand Accessories)
| 配饰 | 关键词 | 说明 |
|------|--------|------|
| 手套 (gloves) | 皮革手套、蕾丝手套、长肘手套、工作手套 | 正式/优雅/劳保 |
| 戒指 (ring) | 钻戒、印章戒指(signet ring)、多个戒指 | 订婚/家族/波西米亚 |
| 手镯/手链 (bracelet) | 金手镯、手串(beads bracelet)、智能手表 | 传统/灵性/科技 |
| 护腕/臂环 (bracer/armband) | 皮革护腕、金属臂环、布质腕带 | 运动/战斗/时尚 |
| 指甲装饰 (nail art) | 法式美甲、彩色指甲、延长甲 | 时尚/角色性格暗示 |

### 身体配饰 (Body Accessories)
| 配饰 | 说明 |
|------|------|
| 腰带 (belt/sash) | 皮带、宽腰带、织物腰封、链条腰带 |
| 背包/袋子 (bag) | 双肩包、手提包(tote)、挎包、腰包、背包(backpack) |
| 披风 (cloak/cape) | 长披风、短斗篷、带兜帽披风 |
| 翅膀 (wings) | 天使翅膀、恶魔翅膀、机械翅膀、光翼 |
| 尾巴 (tail) | 动物尾巴、恶魔尾巴、机械尾 |
| 纹身 (tattoo) | 臂纹、背部纹身、面部纹身 |
| 穿孔 (piercing) | 耳扩、唇钉、眉环、鼻环 |

---

## 服装色彩搭配指南

### 经典配色方案
| 方案 | 色彩组合 | 风格感受 |
|------|----------|----------|
| 单色搭配 | 同一色相不同明度 | 统一、高级、极简 |
| 近似色搭配 | 色轮相邻色 | 和谐、自然、柔和 |
| 对比色搭配 | 互补色（如蓝+橙）| 强烈、活力、醒目 |
| 三角搭配 | 色轮等距三色 | 丰富、平衡、有趣 |
| 无彩色+点缀 | 黑白灰+一个亮色 | 干净、焦点明确 |
| 大地色系 | 棕/米/卡其/橄榄 | 温暖、自然、低调 |
| 莫兰迪色 | 灰调低饱和色 | 文艺、温柔、高级 |

### 场景-服装配色协调
| 场景背景色 | 推荐服装色 | 避免颜色 |
|-----------|-----------|---------|
| 蓝/青色背景（海/天）| 白、橙、黄、红 | 深蓝（融入背景）|
| 绿色背景（森林/草地）| 白、粉、黄、红 | 绿色（ camouflage ）|
| 暖色调背景（夕阳/沙漠）| 蓝、白、冷色调 | 红/橙（过于接近）|
| 深色/暗背景 | 白、亮色、浅色 | 深色（消失在背景中）|
| 杂乱背景 | 单色纯色服装 | 花哨图案（更加混乱）|
