# ⑧ 细节装饰 (Details & Decoration) - 完整数据

## 道具物品完整库

### 1. 日常物品 (Everyday Objects)

#### 书写与学习
| 物品 | 描述 | 使用场景 | 关键词 |
|------|------|----------|--------|
| **书籍** | 堆叠的书、打开的书、图书馆藏书 | 书房、学习、知识分子 | books, stacked books, open book, library, pages, hardcover, paperback |
| **文具** | 笔、笔记本、墨水瓶、砚台 | 写作、办公、古风书房 | pen, fountain pen, notebook, inkwell, inkstone, writing tools |
| **电脑/平板** | 笔记本电脑、平板、键盘敲击 | 现代办公、程序员、写作 | laptop, tablet, keyboard typing, screen glow, modern workspace |
| **眼镜** | 近视镜、老花镜、单片眼镜 | 知识分子、复古、绅士 | glasses, spectacles, eyewear, monocle, reading glasses |

#### 居家生活
| 物品 | 描述 | 关键词 |
|------|------|--------|
| **咖啡杯/茶具** | 马克杯、咖啡壶、中式茶具 | coffee mug, teacup, teapot, porcelain set, steaming beverage |
| **手机** | 智能手机（各种姿势）| smartphone, mobile phone, screen lit up, texting, calling |
| **钥匙** | 一串钥匙、单独的钥匙 | keys, keychain, key in lock, door key |
| **雨伞** | 折叠伞、长柄伞、湿漉漉的伞 | umbrella, folded umbrella, dripping wet umbrella, parasol |
| **枕头/被子** | 枕头、被子、凌乱的床 | pillow, duvet, messy bed, rumpled sheets, cozy bedding |
| **闹钟/时钟** | 闹钟响、老式时钟 | alarm clock ringing, antique clock, wall clock, time piece |
| **镜子** | 全身镜、化妆镜、破碎的镜子 | mirror, full-length mirror, vanity mirror, cracked mirror, reflection |
| **蜡烛** | 燃烧的蜡烛、蜡烛台 | burning candle, candle holder, candelabra, flickering flame, wax dripping |
| **花瓶/鲜花** | 花瓶插花、散落的花瓣 | vase with flowers, flower arrangement, scattered petals, fresh bouquet |

#### 食物饮品
| 类别 | 物品 | 关键词 |
|------|------|--------|
| **甜点** | 蛋糕、马卡龙、甜甜圈、蛋糕切片 | cake, macaron, donut, slice of cake, dessert, pastry, candles on cake |
| **水果** | 苹果香蕉葡萄、切开的西瓜、水果篮 | fruits, apple, banana, grapes, watermelon slice, fruit basket |
| **饮品** | 红酒杯、啤酒、鸡尾酒、牛奶、果汁 | wine glass, beer mug, cocktail glass, milk bottle, juice glass |
| **正餐** | 盘装料理、筷子餐具、西餐盘 | plated dish, chopsticks, western dinner plate, gourmet food, steaming meal |
| **零食** | 爆米花、薯片、糖果罐 | popcorn, potato chips, candy jar, snack food |

---

### 2. 武器兵器 (Weapons & Arms)

#### 冷兵器
| 武器 | 文化背景 | 关键词 |
|------|----------|--------|
| **剑** | 通用（西方骑士剑/东方长剑/日本武士刀）| sword, blade, saber, katana (Japanese), jian (Chinese), Excalibur, gleaming blade |
| **刀** | 东方（中国刀/日本刀/中东弯刀）| dao (Chinese saber), scimitar, cutlass, knife, dagger, blade |
| **枪/矛** | 骑兵武器、长柄 | spear, lance, halberd, polearm, pike, javelin |
| **弓箭** | 猎人/游侠/士兵 | bow and arrows, quiver, archer, nocked arrow, bowstring drawn |
| **法杖/魔杖** | 奇幻/魔法 | magic staff, wizard wand, scepter, rod of power, enchanted staff |
| **扇子（武器）** | 武侠/铁扇 | iron fan, fighting fan, concealed weapon, Tessen (Japanese) |
| **暗器** | 飞镖/毒针/袖箭 | throwing dart, hidden blade, poison needle, shuriken (ninja star) |

#### 热兵器/现代武器
| 武器 | 类型 | 关键词 |
|------|------|--------|
| **手枪** | 半自动、左轮 | handgun, pistol, revolver, sidearm, gun drawn |
| **步枪/冲锋枪** | 军用/警用 | rifle, assault rifle, machine gun, submachine gun, weapon at ready |
| **狙击枪** | 远程精确射击 | sniper rifle, scope, long-range weapon, marksman |
| **霰弹枪/霰弹枪** | 近战火力 | shotgun, double-barrel, pump-action, sawed-off |
| **科幻武器** | 能量武器、激光枪 | laser pistol, plasma rifle, energy weapon, futuristic gun, blaster |
| **爆炸物** | 手雷、炸药 C4 | grenade, explosive, C4, detonator, timed bomb |

---

### 3. 交通工具 (Vehicles)

#### 陆地交通工具
| 工具 | 时代/风格 | 关键词 |
|------|-----------|--------|
| **汽车（现代）** | 轿车/SUV/跑车/老爷车 | car, sedan, sports car, SUV, vintage automobile, sleek vehicle, headlights on |
| **摩托车** | 街车/越野/哈雷 | motorcycle, motorbike, Harley Davidson, racing bike, helmet |
| **自行车** | 公路车/山地车/复古单车 | bicycle, bike, road bike, vintage bicycle, cycling |
| **马车/马车** | 历史场景 | horse-drawn carriage, coach and four, stagecoach, carriage |
| **坦克/装甲车** | 军事 | tank, armored vehicle, military convoy, APC |
| **未来陆地载具** | 飞行汽车、磁悬浮、反重力车 | flying car, hover vehicle, anti-gravity craft, futuristic ground transport |

#### 水上交通工具
| 工具 | 关键词 |
|------|--------|
| **帆船** | sailing ship, sailboat, yacht, mast and sails, nautical vessel |
| **现代船只** | motorboat, speedboat, cruise ship, fishing boat, submarine |
| **独木舟/皮划艇** | canoe, kayak, paddle boat, small rowboat |
| **海盗船** | pirate ship, galleon, Jolly Roger flag, wooden ship |
| **东方船只** | junk ship (中国帆船), dragon boat (龙舟), wooden fishing boat |

#### 空中交通工具
| 工具 | 关键词 |
|------|--------|
| **客机** | airplane, airliner, jet plane, boarding bridge, airport tarmac |
| **直升机** | helicopter, rotor blades spinning, chopper, hovering |
| **私人飞机/喷气机** | private jet, jetsetter, luxury aircraft, propeller plane |
| **战斗机** | fighter jet, military aircraft, afterburners, aerial combat |
| **未来飞行器** | spaceship, spacecraft, UFO, flying saucer, shuttle, rocket |
| **奇幻飞行载具** | dragon mount, magic carpet, floating island, airship (飞艇)|

---

### 4. 乐器音乐 (Musical Instruments)

#### 西洋古典乐器
| 乐器 | 分类 | 关键词 |
|------|------|--------|
| **钢琴** | 键盘/打击乐 | piano, grand piano, upright piano, hands on keys, ivory keys |
| **小提琴/大提琴** | 弦乐器 | violin, cello, strings, violin bow, orchestra instrument |
| **吉他** | 弹拨乐器 | guitar, acoustic guitar, electric guitar, strumming, pick |
| **萨克斯** | 管乐器 | saxophone, brass instrument, jazz instrument |
| **长笛/单簧管** | 木管乐器 | flute, clarinet, woodwind, wind instrument |
| **架子鼓** | 打击乐器 | drum set, drums, drumsticks, cymbals, percussion |
| **管风琴** | 键盘/气鸣 | pipe organ, church organ, grand pipes, sacred music |
| **竖琴** | 弹拨乐器 | harp, angelic instrument, strings, ethereal sound |

#### 中国传统乐器
| 乐器 | 分类 | 关键词 |
|------|------|--------|
| **古琴/古筝** | 弹拨弦乐 | guqin (古琴), guzheng (古筝), Chinese zither, traditional strings |
| **二胡** | 拉弦乐器 | erhu (二胡), Chinese fiddle, two-stringed fiddle, bowed |
| **笛子/箫** | 吹管乐器 | dizi (笛子), xiao (箫), Chinese flute, bamboo wind instrument |
| **琵琶** | 弹拨乐器 | pipa (琵琶), Chinese lute, plucked strings, pear-shaped body |
| **鼓** | 打击乐器 | Chinese drum, war drum, ceremonial drum, percussion |
| **唢呐** | 吹管乐器 | suona (唢呐), Chinese oboe, loud reed instrument |

#### 现代流行乐器
| 乐器 | 关键词 |
|------|--------|
| **电吉他** | electric guitar, amplifier, distortion pedal, rock instrument |
| **合成器/键盘** | synthesizer, keyboard, electronic music instrument, MIDI controller |
| **DJ设备** | DJ turntables, mixer, vinyl records, electronic music setup |
| **麦克风** | microphone, vocal mic, recording studio, stage performance |

---

### 5. 魔法/奇幻物品 (Magical & Fantasy Items)

| 物品 | 描述 | 关键词 |
|------|------|--------|
| **魔法杖** | 施法媒介、顶端嵌有宝石 | magic staff, wizard's wand, enchanted rod, crystal-tipped staff |
| **水晶球** | 预言、占卜、展示影像 | crystal ball, scrying orb, fortune-telling sphere, mystical globe |
| **魔法书/咒典** | 记载咒语的古籍 | spellbook, grimoire, ancient tome of magic, runic text, glowing pages |
| **药水/药剂** | 各种效果的液体药剂 | potion bottle, elixir flask, vial of liquid, bubbling concoction |
| **魔法阵** | 地面绘制的法阵 | magic circle, summoning circle, rune array, glowing sigil on ground |
| **幸运符/护身符** | 带来好运或保护的物品 | talisman, amulet, lucky charm, protective pendant, enchanted jewelry |
| **地图（魔法）** | 显示实时位置的地图 | magical map, moving parchment, treasure map, Marauder's Map style |
| **飞行扫帚** | 飞行载具 | flying broomstick, witch's broom, soaring handle, Quidditch-style |
| **隐形斗篷** | 穿上后隐形的斗篷 | invisibility cloak, transparent garment, vanishing fabric |
| **精灵瓶/灵魂容器** | 封印精灵/灵魂的容器 | spirit jar, soul container, genie bottle, trapped entity |

---

### 6. 科技设备 (Tech & Gadgets)

| 设备 | 年代/类型 | 关键词 |
|------|-----------|--------|
| **智能手机** | 当代 | smartphone, touchscreen, modern gadget, apps on screen, selfie |
| **笔记本电脑** | 当代 | laptop computer, open lid, keyboard glowing, code on screen |
| **平板/电子阅读器** | 当代 | tablet device, e-reader, digital reading, touchscreen display |
| **VR/AR头显** | 近未来 | VR headset, AR glasses, virtual reality visor, holographic display |
| **机器人** | 各种形态 | robot, humanoid robot, droid, mechanical assistant, AI entity |
| **无人机** | 当代 | drone, quadcopter, UAV, flying robot, aerial camera |
| **全息投影仪** | 未来 | holographic projector, 3D display unit, floating image emitter |
| **智能手表** | 当代 | smartwatch, wearable tech, wrist computer, fitness tracker |
| **耳机/耳麦** | 当代 | headphones, earbuds, gaming headset, noise-canceling earphones |
| **复古科技** | 80-90年代 | floppy disk, cassette tape, VCR, CRT monitor, rotary phone, typewriter |

---

## 纹理材质 (Textures & Materials)

### 自然纹理
| 纹理类型 | 视觉特征 | 典型载体 | 描述关键词 |
|----------|----------|----------|------------|
| **木质纹理** | 年轮、木纹、结节 | 家具、地板、船、乐器 | wood grain, timber texture, tree rings, knots in wood, natural grain |
| **石材纹理** | 颗粒感、层理、裂纹 | 建筑墙面、雕像、碑刻 | stone texture, granite, marble veining, rough stonework, masonry |
| **土壤/沙粒** | 细小颗粒、松散 | 地面、沙漠、战场 | soil texture, sandy surface, dirt, grit, granular material |
| **树皮纹理** | 粗糙纵向裂痕 | 树干、原木小屋 | bark texture, tree skin, rugged wooden surface, forest texture |
| **叶子纹理** | 叶脉网络 | 植物、装饰 | leaf vein pattern, botanical texture, plant details, foliage texture |
| **动物皮毛** | 皮毛走向、花纹 | 服装、家具、拟态 | fur texture, animal hide, leather grain, scales pattern, feathers |
| **水纹/波纹** | 流动的线条 | 水面、倒影 | water ripples, wave pattern, liquid surface, flowing lines |

### 人工纹理
| 纹理类型 | 视觉特征 | 典型载体 | 描述关键词 |
|----------|----------|----------|------------|
| **光滑金属** | 反光、冷硬 | 金属制品、武器、科技 | polished metal, brushed steel, chrome surface, reflective alloy |
| **锈蚀金属** | 斑驳、剥落、橙褐色 | 旧机器、废土、船舶 | rusted metal, corroded iron, oxidized surface, weathered steel, patina |
| **玻璃/陶瓷** | 光滑、脆性、透明或不透明 | 窗户、器皿、屏幕 | glass texture, ceramic glaze, porcelain smoothness, crystalline |
| **织物纹理** | 编织纹路 | 服装、窗帘、沙发 | woven fabric, textile texture, cloth weave, tweed, corduroy, denim |
| **纸张纹理** | 纤维感、可书写 | 书籍、书信、卷轴 | paper texture, parchment, papyrus, fiber texture, aged paper |
| **涂料/墙面** | 可能光滑/粗糙/剥落 | 建筑内墙 | painted wall, plaster texture, peeling paint, wallpaper pattern |
| **混凝土** | 粗糙、颗粒感、灰色 | 现代建筑、城市 | concrete texture, brutalist surface, cement finish, aggregate exposed |

### 特殊/异质纹理
| 纹理类型 | 描述 | 使用场景 |
|----------|------|----------|
| **液态/流动** | 水、油、熔岩、血液的流动感 | 水面、伤口、火山、科幻 |
| **发光/自发光** | 霓虹、火焰、屏幕、魔法、生物发光 | 赛博朋克、夜晚、奇幻 |
| **半透明** | 薄纱、冰、磨砂玻璃、凝胶 | 服装、装饰、科幻 |
| **晶体/结晶** | 几何规则、折射、闪光 | 珠宝、魔法、科幻 |
| **有机/生物** | 皮肤、肌肉、细胞、血管 | 医疗、恐怖、科幻 |
| **像素化/数字** | 马赛克、故障、低分辨率 | 数字艺术、故障美学、复古游戏 |

---

## 特殊视觉效果 (Special Visual Effects)

### 粒子效果 (Particle Effects)
| 效果 | 描述 | 使用场景 | 关键词 |
|------|------|----------|--------|
| **火花/火星** | 金属碰撞或燃烧产生的小火星 | 打铁、篝火、焊接、战斗 | sparks, flying embers, spark shower, welding sparks, fiery particles |
| **灰尘/尘埃** | 空气中漂浮的微小颗粒 | 废弃场所、阳光束、沙漠、旧房间 | dust particles, floating dust, dancing motes, airborne particles, dusty atmosphere |
| **花瓣/落叶** | 飘落的花瓣或树叶 | 春秋场景、浪漫、伤感 | falling petals, drifting blossom, autumn leaves falling, petal shower, swirling leaves |
| **雪花** | 飘落的雪花 | 冬季场景、安静、纯洁 | falling snow, snowflakes drifting, winter particles, gently descending snow |
| **萤火虫** | 发光的昆虫 | 夏夜、乡村、奇幻、童年 | fireflies, glowing insects, lightning bugs, bioluminescent beetles, summer night magic |
| **灰烬/余烬** | 燃烧后的残余飘散 | 篝火后、火灾后、火山 | falling ash, embers drifting, smoke particles, post-fire remnants |
| **魔法粒子** | 发光的魔法粉尘 | 施法、变身、魔法场景 | magic particles, sparkling dust, enchantment particles, magical aura shimmer, pixie dust |
| **泡泡** | 肥皂泡 | 童年、派对、梦幻 | soap bubbles, iridescent bubbles, floating spheres, childhood whimsy |
| **雨水滴** | 空中的雨滴 | 下雨天、忧郁、浪漫 | raindrops, falling rain, droplets in air, rainfall particles, stormy atmosphere |
| **星星碎片** | 发光的星形粒子 | 许愿、魔法、梦境 | star fragments, glittering stardust, celestial particles, wishing stars |
| **花粉/孢子** | 空气中的花粉 | 春天、森林、过敏（也可以是唯美的）| pollen grains, spores in air, golden dust floating, spring allergy visualization |

---

### 气氛效果 (Atmospheric Effects)

| 效果 | 描述 | 视觉特征 | 关键词 |
|------|------|----------|--------|
| **雾气/薄雾** | 贴近地面的云/水汽 | 降低能见度、柔化景物、增加深度 | fog, mist, haze, ground-level clouds, low visibility, ethereal atmosphere, foggy morning |
| **烟雾/烟** | 燃烧或其他原因产生的烟 | 灰色/有色、上升或弥漫、可能呛人 | smoke, smoky atmosphere, cigarette smoke, chimney smoke, battlefield smoke, noir ambience |
| **蒸汽/水蒸气** | 热水或热源产生的蒸汽 | 白色、向上飘散、扭曲光线 | steam, vapor, water vapor, rising steam, hot spring mist, bathroom mirror fog |
| **沙尘暴** | 强风卷起的大量沙尘 | 黄/橙色、降低 visibility 、充满空气 | sandstorm, dust storm, blowing sand, desert tempest, gritty atmosphere, obscured vision |
| **魔法迷雾** | 奇幻来源的不明雾气 | 可能发光、可能有颜色、不自然 | magical fog, enchanted mist, otherworldly haze, mystic vapors, supernatural atmosphere |
| **水下浑浊** | 水中的悬浮颗粒 | 蓝绿色调、光线散射 | murky water, underwater particles, turbid depth, suspended sediment |
| **时空裂缝** | 科幻/奇幻的空间扭曲 | 光线弯曲、色彩异常、不稳定 | dimensional rift, spacetime tear, reality fracture, portal effect, glitched reality |

---

### 能量效果 (Energy Effects)

| 效果 | 描述 | 典型应用 | 关键词 |
|------|------|----------|--------|
| **闪电/雷电** | 大气放电现象 | 风暴、超能力、神罚 | lightning bolt, electrical discharge, thunderbolt, storm lightning, chain lightning, magical lightning |
| **能量波/冲击波** | 从中心向外扩散的能量环/球 | 爆炸、技能释放、冲击 | energy wave, shockwave, force blast, impact ring, expanding energy sphere, concussive blast |
| **魔法阵/法阵** | 地面上的发光符文阵列 | 召唤、传送、封印 | magic circle, rune array, summoning circle, glowing sigil, pentagram, arcane pattern on ground |
| **电流/电弧** | 导体间的电流跳跃 | 电击、科技设备、超能力 | electric arc, current jumping, arcing electricity, Tesla coil effect, electrical discharge |
| **激光束** | 直线的强光束 | 科幻武器、测量、切割 | laser beam, coherent light ray, focused energy beam, sci-fi targeting laser |
| **等离子/离子化** | 高能量物质状态 | 引擎、武器、护盾 | plasma, ionized gas, energy core, plasma blade, shield effect |
| **灵魂/精神显现** | 半透明的幽灵/灵体 | 死亡、魔法、回忆 | ghostly apparition, spectral form, spirit manifestation, translucent figure, ectoplasm |
| **传送门/虫洞** | 空间折叠的圆形通道 | 瞬间移动、星际旅行 | portal, wormhole, stargate, dimensional doorway, swirling vortex, event horizon |
| **护盾/屏障** | 保护性的能量墙 | 防御、安全区 | energy shield, protective barrier, force field, magical ward, defensive dome |

---

### 时间效果 (Time-Based Effects)

| 效果 | 描述 | 实现方式 | 关键词 |
|------|------|----------|--------|
| **慢动作 (Slow Motion)** | 动作被放慢，可以看到细节 | 摄影高速拍摄后正常播放 | slow motion, bullet time, slowed action, time dilated, graceful deceleration, matrix-style pause |
| **快进/延时 (Time-lapse)** | 时间加速，看到长期变化 | 间隔拍照后快速播放 | time-lapse, accelerated time, time rushing, hours passing in seconds, rapid cycle |
| **时间静止 (Frozen Time)** | 除主体外一切都停止 | 超能力、关键时刻 | frozen time, stillness, time stopped, suspended moment, everything frozen except subject |
| **残影/多重曝光 (Motion Blur/Trail)** | 运动物体的轨迹残留 | 长曝光或后期 | motion blur, speed trail, multiple exposure, ghosting trail, velocity streaks, afterimage |
| **闪烁/频闪 (Strobe/Echo)** | 画面周期性出现/消失 | 时间循环、信号干扰、魔法 | strobing effect, temporal echo, flickering presence, time loop visual, glitching in and out |
| **老化/腐朽加速** | 看着事物快速老化 | 魔法诅咒、时间攻击 | rapid aging, withering before eyes, decay accelerating, time corrosion effect |
| **回溯/倒带** | 事情倒退发生 | 时间操控、悔恨 | rewinding time, reverse motion, undoing events, going backwards, time regression |

---

### 变形与扭曲效果 (Distortion Effects)

| 效果 | 描述 | 使用场景 | 关键词 |
|------|------|----------|--------|
| **液化扭曲 (Liquid Distortion)** | 画面像液体一样变形流动 | 梦境、超现实、变身、融化 | liquid distortion, melting effect, Salvador Dali style, surreal warping, fluid transformation |
| **故障艺术 (Glitch Effect)** | 数字信号错误导致的图像破坏 | 赛博朋克、数字世界、系统崩溃 | glitch art, digital corruption, signal interference, VHS distortion, pixel sorting, data moshing |
| **像素化 (Pixelation)** | 图像变成明显的方块像素 | 复古游戏、数字矩阵、低分辨率 | pixelated, 8-bit style, retro game aesthetic, pixel art, mosaic effect, digital decomposition |
| **镜像/反射扭曲** | 反射面不平导致的扭曲镜像 | 水中倒影、哈哈镜、曲面镜 | distorted reflection, warped mirror image, funhouse reflection, rippling reflection |
| **拉伸/挤压** | 画面被拉长或压缩 | 卡通夸张、噩梦、外星视角 | stretched, squashed, anamorphic distortion, caricature proportion, alien perspective |
| **玻璃/折射扭曲** | 通过不规则玻璃看到的景象 | 雨天窗户、冰块、水晶、眼镜 | refraction through glass, distorted view through medium, prism effect, lens distortion |
| **漩涡/螺旋** | 画面向某个点旋转吸入 | 时空黑洞、下水道、催眠 | spiral vortex, swirling drain effect, whirlpool distortion, hypnotic spiral, pulling into center |

---

### 过渡效果 (Transition Effects) [用于分镜]

| 效果 | 描述 | 情感/用途 | 关键词 |
|------|------|-----------|--------|
| **淡入淡出 (Fade In/Out)** | 画面逐渐出现/消失为黑/白 | 开始/结束、时间流逝、温柔过渡 | fade to black, fade in from white, gradual transition, dissolve |
| **切镜头 (Cut)** | 瞬间切换，无过渡 | 节奏快、动作场景、突然改变 | hard cut, abrupt switch, jump cut, instant transition |
| **擦除 (Wipe)** | 新画面从一侧推开旧画面 | 地图展开、揭示、 comic 风格 | wipe transition, screen wipe, iris wipe, diagonal wipe |
| **叠化 (Dissolve/Crossfade)** | 两画面重叠过渡 | 时间流逝、回忆、柔和连接 | crossfade, superimpose, blend transition, dissolve between scenes |
| **模糊转场 (Motion Blur Wipe)** | 运动模糊导致画面替换 | 高速运动穿越、快速移动 | motion blur transition, whip pan, blur swap, speed transition |
| **匹配剪辑 (Match Cut)** | 相似形状/动作的两个画面连接 | 巧妙转场、隐喻关联 | match cut, graphic match, matching shape transition, thematic link |
| **光晕过渡 (Flash/Glow)** | 强光充满画面然后消退 | 觉醒、发现、顿悟 | flash of light, white out, glow transition, revelation moment, blinding flash transition |

---

## 氛围细节增强元素

### 天气元素 (Weather Elements)

| 天气 | 视觉效果 | 情绪联想 | 关键词 |
|------|----------|----------|--------|
| **晴天/晴朗** | 明亮、蓝天、白云、强烈阴影 | 积极、明朗、希望、活力 | sunny day, clear sky, bright sunlight, blue skies, fluffy clouds, radiant weather |
| **多云/阴天** | 柔和光线、灰色天空、无硬阴影 | 平淡、平静、可能转向其他情绪 | cloudy day, overcast sky, grey clouds, diffused lighting, gloomy atmosphere |
| **下雨/雨中** | 雨丝/雨滴、湿润表面、灰暗天空 | 忧伤、清洗、浪漫（看情境）| raining, raindrops, wet surfaces, rainy day, downpour, drizzle, rain-streaked window |
| **下雪/雪中** | 飘落的雪花、白色覆盖、寂静 | 纯洁、静谧、寒冷、童话 | snowing, falling snow, snowflakes, blanketed in white, winter precipitation, silent snowfall |
| **大风/风暴** | 物品吹动、头发衣物飘飞、树木弯曲 | 混乱、力量、自由、威胁（取决于程度）| strong wind, stormy, howling wind, blowing debris, hair and clothes whipping, bent trees |
| **雷电/暴风雨** | 闪电、暴雨、乌云 | 恐惧、震撼、戏剧性、力量 | thunderstorm, lightning strike, stormy clouds, heavy rain, turbulent weather |
| **雾/浓雾** | 低能见度、白色/灰色笼罩、轮廓模糊 | 神秘、迷失、悬疑、不安 | fog, dense fog, thick mist, low visibility, obscured landscape, eerie atmosphere |
| **霜冻/冰霜** | 白色结晶覆盖表面、呼吸可见 | 寒冷、清晨、冬天、脆弱 | frost, ice crystals, frozen surface, frosty morning, visible breath, biting cold |
| **彩虹** | 弧形七色光谱、雨后出现 | 希望、奇迹、喜悦、承诺 | rainbow, prismatic arc, spectrum of colors, after the rain, hopeful symbol |
| **霞光/火烧云** | 红橙色天空（日出/日落时）| 壮丽、温暖、转瞬即逝 | fiery sky, sunset glow, sunrise colors, dramatic clouds, burning horizon |

---

### 动物元素 (Animal Elements)

| 类别 | 动物 | 添加的作用 | 关键词 |
|------|------|-----------|--------|
| **鸟类** | 飞鸟、鸽子、海鸥、乌鸦、孔雀、鹤、鹦鹉 | 增加生命感、提供尺度参照、象征意义 | birds flying, flock of birds, seagulls, crow perched, peacock displaying, crane standing, parrot on shoulder |
| **蝴蝶/昆虫** | 蝴蝶、蜜蜂、蜻蜓、瓢虫 | 唯美、自然、春天、灵动 | butterfly landing, bees buzzing, dragonfly hovering, ladybug on leaf, pollinating insects |
| **家养宠物** | 猫、狗、兔子、仓鼠 | 温暖、陪伴、生活气息、可爱 | cat curled up, dog sitting, rabbit nibbling, hamster in cage, domestic pets |
| **野生动物** | 鹿、狐狸、狼、熊、狮子、鹰 | 荒野、力量、自由、危险 | deer in forest, fox stalking, wolf howling, bear fishing, lion resting, eagle soaring |
| **水中生物** | 鱼、海豚、鲸鱼、水母 | 水下场景必需、神秘、美丽 | fish swimming, dolphin jumping, whale breaching, jellyfish glowing, underwater life |
| **马匹** | 马、骏马、野马 | 自由、力量、历史、浪漫 | horse galloping, majestic steed, wild mustang, horseback riding |
| **幻想生物** | 独角兽、凤凰、龙、天马、 Griffin | 奇幻世界、神话、魔法 | unicorn, phoenix rising, dragon soaring, Pegasus flying, mythical creature |

**添加动物的技巧**:
- **尺度参照**: 动物可以帮助判断场景大小（一只鸟让天空更大，一只蚂蚁让人显得巨人）
- **动态注入**: 静态场景中加入运动的动物立刻"活"了
- **象征叙事**: 乌鸦=不祥/智慧，白鸽=和平/信使，蝴蝶=灵魂/转变
- **框架填充**: 空旷的画面角落放一只小动物，填补构图

---

### 文字元素 (Text & Typography Elements)

| 类型 | 描述 | 使用场景 | 关键词 |
|------|------|----------|--------|
| **招牌/广告牌** | 建筑上的商业标识 | 城市场景、时代背景、地点信息 | storefront sign, neon billboard, shop signage, commercial logo, advertising board |
| **标语/海报** | 墙上的宣传文字 | 政治、战争、反乌托邦、校园 | propaganda poster, wall slogan, protest sign, motivational quote, wanted poster |
| **书籍/文件** | 打开的书、信件、报纸 | 故事线索、信息传达、时代 | open book with text, handwritten letter, newspaper headline, document with words |
| **电子屏幕文字** | 手机/电脑/LED显示屏的文字 | 现代场景、信息时代、具体消息 | text message on phone, computer code, LED ticker, digital display words |
| ** graffiti ** | 墙面涂鸦 | 街头、叛逆、亚文化、都市 | graffiti on wall, street art, spray-painted tag, urban vandalism |
| **中式文字元素** | 书法、对联、诗词、印章 | 中国文化场景、增加文化底蕴 | Chinese calligraphy, poetic inscription, red seal stamp, couplet scrolls, brush-written characters |
| **霓虹文字** | 发光的管状文字 | 赛博朋克、夜店、复古美式 | neon sign, glowing tube letters, fluorescent typography, night club signage |
| **天空文字** | 云形成的文字或飞机拉烟文字 | 超现实、告白、上帝信息 | skywriting, clouds forming words, message in the sky, contrail text |

**注意事项**:
- AI生成的文字通常是乱码（伪文字），如果需要正确文字需后期添加
- 但"有文字存在"这个视觉元素是可以生成的
- 可以在提示词中注明"text is illegible/gibberish"降低期望

---

### 倒影与前景遮挡元素

#### 倒影元素 (Reflection Elements)
| 类型 | 描述 | 效果 |
|------|------|------|
| **水面倒影** | 水面（平静/波动）映射上方景象 | 增加对称美（平静水面）/ 抽象美（波动水面）|
| **镜面反射** | 镜子中的影像 | 可以展示角色的另一面/背后的东西/不同的自己 |
| **眼睛反光 (Catchlight)** | 眼睛角膜中的光源反光点 | 让眼睛有神、增加生动感（"眼中的星辰"）|
| **湿地面反射** | 雨后地面的积水反射城市灯光 | 赛博朋克/城市夜景的经典元素 |
| **玻璃反射** | 窗户玻璃上的内外重叠影像 | 增加层次、观察者视角 |
| **金属高光** | 抛光金属表面的光源反射 | 表现材质、增加真实感 |

#### 前景遮挡 (Foreground Framing/Occlusion)
| 遮挡物 | 效果 | 使用技巧 |
|--------|------|----------|
| **树枝** | 画面上方/侧面的枝叶 | 自然框架、窥视感、增加深度（必须虚化前景！）|
| **门框/窗框** | 建筑开口形成的框架 | 经典构图、画中画、观察视角 |
| **帘幕/纱帘** | 半透明的布料遮挡 | 朦胧美、亲密感、窥视欲 |
| **人群虚影** | 前景的人群（失焦）| 纪实感、主体在人群中、事件现场感 |
| **栏杆/栅栏** | 横向的栏杆线条 | 囚禁/保护（看情境）、增加层次 |
| **草叶/麦穗** | 下方的植物遮挡 | 低角度拍摄、置身其中的感觉 |
| **手指遮挡（主观）** | 手指在镜头前 | 第一人称视角的证据、发现/偷看的暗示 |

**前景遮挡的核心原则**:
- 前景必须**失焦/虚化**（否则抢夺主体注意力）
- 用于引导视线而非阻挡视线
- 增加画面的**纵深感**和**层次**
- 创造"窥视"或"偶然发现"的真实感
