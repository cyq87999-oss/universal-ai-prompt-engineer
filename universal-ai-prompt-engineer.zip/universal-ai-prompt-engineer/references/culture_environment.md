# ⑦ 文化与环境 (Culture & Environment) 【v4.0新增】

## 文化元素体系

### 1. 中华文化 (Chinese Culture)

#### 核心符号与元素
| 元素类别 | 代表元素 | 详细描述 | 英文关键词 |
|----------|----------|----------|------------|
| **神兽图腾** | 龙 | 角似鹿、头似驼、眼似兔、项似蛇、腹似蜃、鳞似鲤、爪似鹰、掌似虎 | Chinese dragon, loong, serpentine dragon, auspicious beast |
|  | 凤凰 | 五彩羽毛、优雅高贵、百鸟之王 | Chinese phoenix, fenghuang, vermilion bird, elegant bird |
|  | 麒麟 | 仁兽、送子、祥瑞 | qilin, Chinese unicorn, auspicious creature |
|  | 貔貅 | 招财、只进不出 | pixiu, wealth-attracting beast |
| **祥瑞图案** | 祥云 | 卷曲的云纹象征吉祥 | auspicious clouds, ruyi clouds, cloud patterns, xiangyun |
|  | 如意 | 灵芝形、事事如意 | ruyi scepter, as-you-wish symbol |
|  | 八卦 | 阴阳五行、道教符号 | bagua, eight trigrams, yin-yang symbol, Taoist emblem |
|  | 太极 | 阴阳鱼、平衡之道 | taiji symbol, yin-yang diagram, Taoist Tai Chi |
| **文字书法** | 书法 | 毛笔字、各字体 | Chinese calligraphy, brush writing, ink characters |
|  | 印章 | 红色方章、姓名印 | Chinese seal, red chop stamp, name seal |
|  | 对联 | 春联、门联 | spring couplets, antithetical couplets, door scrolls |
| **传统物件** | 红灯笼 | 圆形、红色、节日必备 | red lantern, Chinese lantern, festive lamp |
|  | 中国结 | 红色绳结、装饰 | Chinese knot, decorative knotting, lucky knot |
|  | 爆竹/烟花 | 节庆燃放 | firecrackers, fireworks, celebratory explosions |
|  | 扇子 | 折扇/团扇 | folding fan, round fan, paper fan, decorative fan |
|  | 油纸伞 | 传统雨具/道具 | oil-paper umbrella, traditional parasol, oiled paper umbrella |
|  | 香炉 | 燃香、祭祀/禅意 | incense burner, censer, aromatic vessel |
|  | 铜钱/元宝 | 财富象征 | ancient Chinese coins, gold ingots, sycee, wealth symbols |
| **纹样图案** | 回纹 | 连续的回字形纹样 | meander pattern, key pattern, fretwork |
|  | 云纹 | 云朵变形图案 | cloud motif, cloud pattern, auspicious cloud design |
|  | 水纹 | 流水的波浪图案 | wave pattern, water motif, flowing design |
|  | 窗花 | 剪纸窗花 | paper-cut window decoration, folk paper cutting |
|  | 青花纹 | 青白瓷器纹样 | blue and white porcelain pattern, china pattern |

#### 中华文化色彩体系
| 色彩 | 名称 | 含义 | 使用场景 |
|------|------|------|----------|
| 中国红 | Zhu Red (#DE2910) | 吉祥、喜庆、权威 | 婚礼、春节、皇宫、印章 |
| 琉璃黄 | Glaze Yellow (#ED9000) | 皇家尊贵 | 皇帝龙袍、宫殿屋顶 |
| 青花蓝 | Porcelain Blue (#177CB0) | 典雅、素净 | 青花瓷器、文人服饰 |
| 翡翠绿 | Jade Green (#00A86B) | 高贵、生命、平安 | 玉器、贵族饰品 |
| 藕荷粉 | Lotus Pink (#E8998C) | 温婉、柔美 | 仕女绘画、女装 |
| 墨色/玄黑 | Ink Black (#1C1C1C) | 庄重、肃穆、水墨 | 水墨画、书法、丧葬 |
| 月白 | Moon White (#D6ECF0) | 清雅、纯净 | 文人服饰、瓷器 |
| 黛绿 | Dai Green (#3B5249) | 沉静、古典 | 山水画、仕女眉毛 |

#### 中华文化场景预设
| 场景名 | 组合元素 | 适用主题 |
|--------|----------|----------|
| **宫廷大殿** | 龙椅、金銮殿、红墙黄瓦、蟒袍官服、太监宫女、焚香 | 古装剧、权谋、历史 |
| **江南水乡** | 乌篷船、石拱桥、青瓦白墙、小桥流水、油纸伞、旗袍女子 | 爱情、诗意、慢生活 |
| **竹林深处** | 翠竹林、茅草屋、古琴、白衣侠客、落花、溪流 | 仙侠、隐居、武侠 |
| **塞外边关** | 长城烽火台、大漠孤烟、铁骑、战旗、落日 | 战争、史诗、悲壮 |
| **仙境蓬莱** | 云海仙山、瑶池、仙鹤、祥云、仙人、琼楼玉宇 | 神话、修真、超脱 |
| **古镇集市** | 青石板路、酒旗、叫卖小贩、灯笼高挂、人来人往 | 日常生活、热闹、烟火气 |
| **书院私塾** | 木质桌椅、笔墨纸砚、竹简、汉服书生、屏风 | 文人、求学、古代教育 |
| **中秋赏月** | 满月、桂花树、月饼、茶具、庭院、一家人 | 团圆、亲情、传统节日 |

---

### 2. 日式文化 (Japanese Culture)

#### 核心元素
| 元素 | 描述 | 英文关键词 |
|------|------|-----------|
| **樱花** | 樱花树、飘落的樱花瓣、樱花祭 | cherry blossom, sakura, falling petals, hanami |
| **鸟居** | 神社大门、朱红色鸟居门 | torii gate, Shinto shrine entrance, vermillion gate |
| **榻榻米/障子** | 传统日式房间、纸拉门、草席地板 | tatami mats, shoji screens, paper sliding doors, traditional Japanese room |
| **茶道** | 茶室、茶具、茶道仪式 | tea ceremony, chado, tea room, matcha preparation, zen tea ritual |
| **武士/忍者** | 日本刀( katana )、武士盔甲、忍装束 | samurai warrior, katana sword, ninja, shuriken, feudal Japan |
| **浮世绘** | 日本版画风格、波浪/富士山 | ukiyo-e, woodblock print style, The Great Wave, Mount Fuji |
| **居酒屋** | 日式小酒馆、灯笼、吧台 | izakaya, Japanese pub, paper lanterns, sake bar |
| **神社/寺庙** | 伏见稻荷大社千本鸟居、京都金阁寺 | Fushimi Inari shrine, Kinkaku-ji temple, Buddhist temple, Shinto shrine |
| **和服/浴衣** | 传统日本服装、宽腰带( obi ) | kimono, yukata, summer kimono, wide obi sash, geta sandals |
| **枯山水** | 日式庭园、白沙、岩石 arrangement | karesansui, Zen rock garden, dry landscape garden, meditation garden |
| **温泉** | 温泉旅馆( ryokan )、露天浴场 | onsen, hot spring resort, rotenburo outdoor bath, steam rising |
| **妖怪** | 日本神话生物（河童/天狗/鬼/狐狸精）| yokai, kappa, tengu, oni, kitsune, Japanese folklore creature |
| **动漫元素** | 二次元相关、秋叶原、女仆咖啡厅 | Akihabara, anime culture, maid cafe, otaku elements |

---

### 3. 欧洲文化 (European Culture)

#### 古希腊罗马
| 元素 | 关键词 |
|------|--------|
| 建筑 | 希腊神殿（帕特农神庙）、多立克/爱奥尼/科林斯柱式、罗马斗兽场、万神殿、凯旋门 |
| 雕塑 | 大理石雕塑、维纳斯像、掷铁饼者、思想者 |
| 神话 | 奥林匹斯诸神（宙斯/雅典娜/阿波罗）、神话生物（美杜莎/牛头怪）|
| 哲学 | 柏拉图/亚里士多德、哲学思辨的氛围 |
| 文艺复兴 | 达芬奇《蒙娜丽莎》/《最后的晚餐》、米开朗基罗《大卫》、西斯廷教堂天顶画 |

#### 中世纪欧洲
| 元素 | 关键词 |
|------|--------|
| 哥特式教堂 | 尖拱、飞扶壁、彩色玻璃窗(stained glass)、玫瑰窗、石像鬼(gargoyle) |
| 城堡 | 石砌城堡、吊桥(drawbridge)、护城沟、塔楼、城垛、宴会大厅 |
| 骑士 | 板甲(plate armor)、骑士纹章、圣剑、圣杯 quest |
| 贵族 | 贵族礼服、假发(periwig)、歌剧、宫廷舞会(ball) |
| 农村村庄 | 茅草屋顶(thatched roof)、木梁房屋、鹅卵石街道(cobblestone) |

#### 维多利亚时代 (1837-1901)
| 元素 | 关键词 |
|------|--------|
| 建筑 | 维多利亚式房屋（红砖/白色装饰条）、铁桥、火车站大棚 |
| 服饰 | 礼服/礼服、礼帽/top hat、长裙、紧身胸衣(corset)、手杖/阳伞 |
| 氛围 | 伦敦雾气(London fog)、煤气灯(gas lamp)、马车(carriage)、蒸汽火车 |
| 文学 | 福尔摩斯、狄更斯小说世界、吸血鬼传说（德古拉1897出版）|

---

### 4. 中东文化 (Middle Eastern Culture)

| 元素 | 描述 | 关键词 |
|------|------|--------|
| **伊斯兰建筑** | 清真寺(mosque)、巨大穹顶(dome)、宣礼塔(minaret)、伊斯兰几何图案(islamic geometric patterns)、阿拉伯书法(arabic calligraphy) | mosque dome, minaret tower, Islamic architecture, geometric arabesque, Arabic script |
| **波斯元素** | 波斯地毯(Persian carpet)、细密画(miniature painting)、伊甸园式花园(charbagh garden)、蓝色瓷砖 | Persian rug, miniature painting, paradise garden, blue tilework |
| **沙漠环境** | 绿洲(oasis)、棕榈树(palm trees)、骆驼 caravan 、贝因都因帐篷(Bedouin tent)、沙丘 | desert oasis, palm grove, camel caravan, Bedouin camp, sand dunes |
| **香料之路** | 香料市场(souk/bazaar)、香料堆积、异域香气 | spice bazaar, exotic market, aromatic mounds, merchant stalls |
| **一千零一夜** | 阿拉丁神灯、飞毯、阿拉丁、辛巴达航海 | Aladdin's magic lamp, flying carpet, Arabian Nights tales, djinn/genie |

---

### 5. 印度文化 (Indian Culture)

| 元素 | 描述 | 英文关键词 |
|------|------|-----------|
| **泰姬陵** | 白色大理石陵墓、完美对称、倒映水池 | Taj Mahal, white marble mausoleum, perfect symmetry, reflecting pool |
| **印度教** | 湿婆/毗湿奴/梵天、多手神像、莲花座 | Hindu deities, multi-armed gods, lotus position, temple idol |
| **瑜伽** | 瑜伽体式(asana)、冥想、莲花坐 | yoga pose, meditation, lotus position, spiritual practice, namaste |
| **纱丽(Sari)** | 女性传统服饰、缠绕式长布、精美刺绣 | sari, Indian saree, draped garment, embroidered textile |
| **色彩节日** | 胡里节(Holi)彩色粉末、排灯节(Diwali)灯盏 | Holi festival colors, Diwali lamps, colorful powder celebration |
| **香料与食物** | 香料集市、咖喱、塔利(thali)餐盘 | spice market, curry, thali plate, aromatic cuisine |
| **宝莱坞** | 印度歌舞、华丽服装、戏剧性情节 | Bollywood style, dance sequence, extravagant costumes, melodrama |
| **恒河** | 圣河、河边祈祷、 Ghats （阶梯码头）| Ganges river, sacred waters, riverside prayer, Varanasi ghats |
| **大象** | 装饰大象、节日游行、象神 Ganesh | decorated elephant, festival procession, Lord Ganesh |

---

### 6. 未来科技文化 (Future Tech Culture)

**这是21世纪独有的新兴"文化"，代表人类对未来的想象。**

| 元素类别 | 具体表现 | 关键词 |
|----------|----------|--------|
| **全息影像** | 空中悬浮的3D投影、广告牌、通讯界面 | holographic display, floating 3D projection, hologram advertisement, sci-fi interface |
| **人工智能实体** | 人形机器人、AI伴侣、智能助手外形 | humanoid robot, AI companion entity, android, synthetic being |
| **赛博义肢** | 机械手臂/腿、神经接口、义眼 | cybernetic limb, neural interface, robotic prosthetic, bionic eye |
| **虚拟现实** | VR头显、沉浸式空间、数字世界 | VR headset, immersive virtual space, metaverse environment, digital realm |
| **飞行载具** | 飞行汽车(flying car)、悬浮滑板、个人飞行器 | flying car, hoverboard, personal aircraft, anti-gravity vehicle |
| **太空殖民** | 空间站、火星殖民地、月球基地、轨道电梯 | space station, Mars colony, lunar base, space elevator, orbital habitat |
| **基因改造** | 改造人类/动物、新物种、生物发光 | genetic modification, engineered species, bio-luminescence, transhuman |
| **量子科技** | 量子计算机、瞬间传送门、平行宇宙设备 | quantum computer, teleportation portal, parallel universe device |
| **可持续乌托邦** | 垂直农场、生态城市、太阳能一切 | vertical farm, eco-city, solar-powered utopia, green future |
| **末世废土** | 辐射、资源匮乏、生存主义、拾荒 | post-apocalyptic wasteland, radiation, survivalism, scavenging |

---

## 建筑风格详解

### 中国传统建筑
| 风格要素 | 描述 | 关键词 |
|----------|------|--------|
| **屋顶形式** | 庑殿顶（最高级）、歇山顶、攒尖顶、硬山顶、悬山顶 | curved roof, upturned eaves, glazed tile roof, ridge ornaments |
| **色彩规制** | 黄色=皇家、绿色/蓝色=王府、黑色/灰色=民用 | yellow imperial tiles, colored glaze hierarchy |
| **斗拱** | 屋檐下的复杂木质支撑结构 | dougong bracket set, interlocking wooden brackets |
| **飞檐** | 向上翘起的屋檐角 | flying eaves, sweeping roof corners, upturned rooflines |
| **红墙** | 宫殿/寺庙的红色墙体 | red palace walls, vermilion walls, lacquered red |
| **琉璃瓦** | 彩色玻璃质地的屋顶瓦片 | glazed roof tiles, colored ceramic tiles, liuli瓦 |
| **园林** | 江南园林：借景、曲径通幽、叠山理水 | Chinese garden, borrowed scenery, winding path, rockery pond |
| **牌坊/牌楼** | 纪念性/装饰性门式建筑 | memorial archway, paifang, decorative gate, triumphal arch |

### 现代都市建筑
| 类型 | 特征 | 关键词 |
|------|------|--------|
| **摩天大楼** | 玻璃幕墙、钢结构、垂直线条 | skyscraper, glass curtain wall, steel structure, vertical lines, corporate tower |
| ** Brutalism** | 粗犷混凝土、巨大体量、功能至上 | brutalist architecture, raw concrete, massive forms, utilitarian design |
| **参数化设计** | 流动曲线、非线性、Zaha Hadid风格 | parametric design, fluid curves, Zaha Hadid style, organic architecture |
| **绿色建筑** | 垂直绿化、节能、可持续 | green building, vertical garden, eco-friendly, sustainable architecture |
| **居住建筑** | 高层公寓、联排别墅、合院 | high-rise apartment, townhouse, courtyard housing complex |

### 欧式古典建筑
| 风格 | 时期 | 特征 |
|------|------|------|
| **古希腊** | 前800-前31年 | 柱式（多立克/爱奥尼/科林斯）、三角楣 pediment 、神庙 |
| **古罗马** | 前753-476年 | 拱券 arch 、穹顶 dome 、圆形剧场 amphitheater 、输水道 aqueduct |
| **罗马式** | 10-12世纪 | 厚墙、圆拱、小窗、堡垒感 | Romanesque, thick walls, rounded arches, small windows |
| **哥特式** | 12-16世纪 | 尖拱 pointed arch 、飞扶壁 flying buttress 、彩色玻璃、高耸 | Gothic, pointed arches, stained glass, verticality |
| **文艺复兴** | 15-17世纪 | 对称、圆穹顶、希腊罗马元素回归、比例和谐 | Renaissance, symmetry, domes, classical revival, harmonious proportions |
| **巴洛克** | 17-18世纪 | 华丽、动态曲线、戏剧性光影、繁复装饰 | Baroque, ornate, dynamic curves, dramatic lighting, elaborate ornamentation |
| **洛可可** | 18世纪 | 更轻快、粉色/金色、不对称、贝壳装饰 | Rococo, playful, pink and gold, asymmetrical, shell motifs |
| **新古典** | 18世纪末-19世纪 | 回归希腊罗马的简洁庄重 | Neoclassical, return to Greek-Roman simplicity, dignified restraint |

### 日式传统建筑
| 要素 | 描述 | 关键词 |
|------|------|--------|
| **木结构** | 木柱、木梁、榫卯连接 | wooden pillar and beam, mortise and tenon joint, timber frame |
| **纸拉门(Shoji)** | 木框+和纸、透光不透视 | shoji screen, paper sliding door, translucent paper panel |
| **缘外廊(Engawa)** | 建筑外围的木质走廊 | engawa veranda, wooden corridor, transitional space |
| **障子门(Fusuma)** | 可移动的隔断推拉门 | fusuma sliding door, movable partition, painted panel |
| **榻榻米(Tatami)** | 草编垫子的地板 | tatami mat flooring, rush grass covering, traditional flooring |
| **床之间(Tokonoma)** | 和室中的凹间、挂轴+花瓶 | tokonoma alcove, scroll hanging, flower arrangement |
| **枯山水庭园** | 白沙+岩石的冥想庭园 | karesansui, Zen rock garden, raked gravel, meditative landscape |
| **鸟居(Torii)** | 神社的入口标志 | torii gate, shrine entrance, vermillion gateway |
| **五重塔(Gojunoto)** | 五层佛塔 | five-story pagoda, Buddhist pagoda, tiered tower |

### 赛博未来建筑
| 元素 | 描述 |
|------|------|
| **立体城市** | 多层空中道路、建筑堆叠、垂直发展 |
| **巨型建筑** | 占据数个街区的 megastructure 、 arcology |
| **全息广告** | 建筑外墙上的巨大全息投影广告 |
| **霓虹招牌** | 密集的、各种文字的霓虹灯招牌 |
| **贫民窟** | 高楼之间的底层/顶层贫民区、密集杂乱 |
| **管道/电线** | 暴露在外的管道系统和电缆 |
| **空中交通** | 飞行汽车穿梭的空中航道 |
| **穹顶城市** | 巨型穹顶覆盖整个城市（控制气候）|
| **蜂巢/模块化** | 像蜂窝一样重复的建筑单元 |

### 末日废土建筑
| 元素 | 描述 |
|------|------|
| **残垣断壁** | 部分倒塌的建筑、裸露钢筋 |
| **植被覆盖** | 藤蔓爬满墙壁、树木从建筑中长出 |
| **锈蚀** | 金属表面大面积锈蚀、变色 |
| **涂鸦/标语** | 墙上的警告语、帮派标志 |
| **临时搭建** | 废弃材料搭建的避难所 |
| **废弃车辆** | 生锈的汽车残骸堵塞道路 |
| **碎裂玻璃** | 窗户破碎、地面散落玻璃渣 |
| **沙土掩埋** | 部分被风沙掩埋的建筑 |

---

## 自然环境详解

### 山地环境
| 子类型 | 视觉特征 | 典型元素 | 氛围 |
|--------|----------|----------|------|
| **雪山山脉** | 白色主调、尖锐峰顶、蓝天对比 | 雪峰 snow peak 、冰川 glacier 、冰裂缝 crevasse 、登山绳 | 壮美、严酷、纯洁、挑战 |
| **火山地貌** | 黑色/红色岩石、硫磺烟雾、熔岩流 | 火山口 crater 、熔岩流 lava flow 、热泉 hot spring 、火山灰 ash | 危险、原始力量、地狱感 |
| **喀斯特地貌** | 灰白色石灰岩、峰林、地下暗河 | 石林 stone forest 、溶洞 cave 、钟乳石 stalactite 、暗河 underground river | 奇特、幽深、探险 |
| **丹霞地貌** | 红色岩层、波浪状山脊、色彩斑斓 | 红色悬崖 red cliff 、彩色山丘 colorful hills 、峡谷 canyon | 绚丽、地质奇观 |
| **丘陵梯田** | 曲线优美、季节变色 | 梯田 terraced field 、茶园 tea plantation 、油菜花 rapeseed flower | 田园、农耕、和谐 |

### 水域环境
| 子类型 | 视觉特征 | 关键词 | 最佳时段 |
|--------|----------|--------|----------|
| **海洋/海岸** | 无尽水平线、浪花、沙滩 | ocean waves, beach, coastline, horizon, seagulls | 日出/日落（金色海岸）|
| **高山湖泊** | 镜面般水面、倒映山峰 | alpine lake, mirror-like water, mountain reflection, pristine clarity | 清晨（无风时完美倒影）|
| **河流溪流** | 流动感、蜿蜒、两岸风景 | flowing river, stream, meandering watercourse, riverbank | 任意（流动本身就是美）|
| **瀑布** | 垂直水流、水雾、轰鸣声暗示 | waterfall cascade, plunging water, mist spray, rainbow in mist | 阳光照射时（彩虹）|
| **冰川水域** | 蓝色冰、漂浮冰块、极寒 | glacial lake, blue ice, ice floe, frozen landscape | 极昼夏季 |

### 森林环境
| 子类型 | 植被特征 | 光线特点 | 独特元素 |
|--------|----------|----------|----------|
| **热带雨林** | 巨型叶片、藤蔓缠绕、层次极多 | 斑驳光线（穿透层层树叶）、潮湿 | 奇异植物、鸟类、昆虫、迷雾 |
| **温带落叶林** | 四季变化明显、阔叶树 | 春嫩绿/夏浓荫/秋金黄/冬枯枝 | 季节性是最大看点 |
| **针叶林/泰加林** | 常绿松柏、深绿色、笔直树干 | 穿透性较好、冬季积雪 | 松果、松鼠、蘑菇、林间空地 |
| **竹林** | 翠绿修长、随风摇曳、沙沙声 | 筛落的光斑、绿色滤镜感 | 幽静、禅意、熊猫/武侠场景 |
| **魔法森林** | 发光植物、超大尺寸、奇幻色彩 | 自发光（植物本身发光）、萤火虫般 | 仙境、精灵、魔法生物栖息地 |

### 荒漠环境
| 子类型 | 视觉特征 | 氛围 | 注意事项 |
|--------|----------|------|----------|
| **沙质沙漠** | 金黄色沙丘、波浪状纹理、无尽延展 | 孤寂、辽阔、炎热、生存挑战 | 沙漠中的海市蜃楼( mirage )是绝佳元素 |
| **戈壁滩** | 砾石地表、稀疏植被、风蚀地貌 | 荒凉、苍茫、丝绸之路联想 | 风蚀柱/魔鬼城是亮点 |
| **雅丹地貌** | 风蚀形成的土墩/沟槽、诡异造型 | 诡异、外星球感、时间侵蚀 | 特别适合科幻/末世场景 |

### 极地环境
| 子类型 | 元素 | 视觉魅力 |
|--------|------|----------|
| **冰川/冰原** | 蓝色冰洞、冰裂纹、冰川湖 | 冰的蓝色是核心——密度极高的冰吸收红光反射蓝光 |
| **南极/北极** | 冰原、企鹅/北极熊、极光 | 极光(aurora)是最重要的视觉元素 |
| **雪山高峰** | 积雪的山峰、冰岩混合 | 登山者的目标、神圣感 |
| **永冻层** | 地下冰永久冻结、地表苔原 | 苔原、驯鹿、极地特有的生命力 |

---

## 季节与气候系统

### 春季 (Spring) - 万物复苏
**时间**: 2-4月（北半球）/ 8-10月（南半球）

| 要素 | 描述 |
|------|------|
| **色彩** | 嫩绿新芽、粉色花朵、浅蓝天、柔和阳光 |
| **植物** | 樱花（日本）、桃花（中国）、郁金香（荷兰）、油菜花（中国江南）|
| **天气** | 春雨绵绵、春风拂面、偶尔雷阵雨 |
| **光线** | 渐强的阳光、角度渐高、不再寒冷 |
| **独特现象** | 花瓣飘落（极具美感）、蝴蝶苏醒、候鸟归来 |
| **农事** | 播种、农耕开始、生机勃勃 |

**春季关键词**:
```
springtime, vernal season, new growth, budding leaves, blooming flowers, cherry blossoms, gentle spring rain, fresh green, renewal, awakening nature, mild temperature,春天的气息,万物复苏,春暖花开,春雨绵绵,嫩绿,花开满园
```

### 夏季 (Summer) - 炽热繁荣
**时间**: 5-7月 / 11-1月

| 要素 | 描述 |
|------|------|
| **色彩** | 浓绿、鲜艳花朵、湛蓝天空、烈日金白 |
| **植物** | 茂盛至极、树荫浓郁、果实初成 |
| **天气** | 烈日当空、雷暴、蝉鸣蛙叫、偶尔台风/暴雨 |
| **光线** | 强烈直射、硬阴影、长时间日照 |
| **独特现象** | 萤火虫（夏夜）、流星雨（英仙座等）、彩虹（雨后）|
| **活动** | 游泳、海滩、冰淇淋、空调房、夏夜纳凉 |

**夏季关键词**:
```
summer, midsummer, scorching sun, lush greenery, intense heat, thunderstorm, cicada singing, clear blue sky, vibrant life, beach vibes, summer night breezes,夏天,烈日炎炎,骄阳似火,郁郁葱葱,雷雨交加,蝉鸣蛙叫,盛夏,夏夜
```

### 秋季 (Autumn/Fall) - 丰收萧瑟
**时间**: 8-10月 / 2-4月

| 要素 | 描述 |
|------|------|
| **色彩** | 金黄、橙红、褐色、暖色调为主调 |
| **植物** | 红叶（枫叶）、落叶纷飞、果实成熟丰收 |
| **天气** | 秋高气爽、早晚凉爽、偶有秋雨 |
| **光线** | 低角度的金色阳光（黄金时刻变长）、斜射、长影子 |
| **独特现象** | 晨雾（秋季多雾）、迁徙的鸟群、收割后的田野 |
| **情绪** | 诗意、收获的喜悦 vs 萧瑟的凋零（双重性）|

**秋季关键词**:
```
autumn, fall season, golden foliage, autumn leaves turning red, harvest time, falling leaves, crisp air, morning mist, golden hour extended, melancholic beauty, pumpkin patches,秋天,金秋,秋高气爽,层林尽染,落叶纷飞,枫叶红了,丰收的季节,秋风萧瑟
```

### 冬季 (Winter) - 纯净静谧
**时间**: 11-1月 / 5-7月

| 要素 | 描述 |
|------|------|
| **色彩** | 白（雪）、深绿（松柏）、褐色（枯枝）、灰（天空）|
| **植物** | 落叶树的枝干、常绿的松柏、梅花/冬青（少数开花）|
| **天气** | 降雪、冰冻、寒风刺骨、偶尔晴朗干燥 |
| **光线** | 低角度、短暂的日照、苍白的阳光 |
| **独特现象** | 雪花飘落（极其优美的视觉元素）、雾凇（树枝冰晶）、冰封的湖面 |
| **活动** | 围炉取暖、火锅、 holiday 庆祝、滑雪 |
| **情绪** | 寂静、纯净、年末反思、团圆渴望（春节/圣诞）|

**冬季关键词**:
```
winter, wintertime, snowfall, frozen landscape, bare branches, evergreen pines, icicles, frost, short daylight, cozy indoor warmth, silent snow-covered world, breath visible in cold air,冬天,寒冬,大雪纷飞,冰天雪地,银装素裹,梅花傲雪,岁末,冬日暖阳
```
