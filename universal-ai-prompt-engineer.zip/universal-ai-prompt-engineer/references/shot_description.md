# ④ 镜头描述 (Shot Description) - 完整数据

## 主体动作详细库

### 静态姿态 (Static Poses)

#### 站立类
| 姿势 | 描述 | 情绪/含义 | 英文关键词 |
|------|------|-----------|------------|
| 直立站立 | 身体挺拔，双臂自然下垂或叉腰 | 自信、坚定、准备就绪 | standing tall, confident posture, arms crossed, ready stance |
| 倚靠 | 靠在墙壁/栏杆/树上 | 放松、等待、若有所思 | leaning against, casual pose, resting on, propped up |
| 侧身回眸 | 身体转向一侧，头部回转看向镜头 | 优雅、神秘、引人注目 | turning back, over-the-shoulder glance, looking back, alluring pose |
| 双手插兜 | 站立双手插入口袋 | 酷、随性、自信 | hands in pockets, casual stance, nonchalant, cool demeanor |
| 伫立凝望 | 静止站立，目光投向远方 | 思考、憧憬、忧郁 | standing still, gazing into distance, contemplative stance |
| 军姿站立 | 身体笔挺如军人 | 纪律、严肃、专业 | military posture, at attention, rigid stance, formal standing |
| 重心偏移 | 身体重心落在一条腿上 | 放松、时尚、模特感 | weight shift, model pose, contrapposto, relaxed stance |
| 背对镜头 | 背向观众，可能回头或不回 | 神秘、告别、背影故事 | back to camera, from behind, turned away, mysterious silhouette |

#### 坐姿类
| 姿势 | 描述 | 场景 | 英文关键词 |
|------|------|------|------------|
| 正襟危坐 | 端坐，身体挺直 | 正式场合、面试、商务 | sitting upright, proper posture, formal seating, composed |
| 慵懒瘫坐 | 陷进沙发，身体松弛 | 家居、放松、疲惫 | lounging, sinking into couch, relaxed sitting, slouching |
| 盘腿坐 | 双腿盘起，地面或沙发上 | 冥想、瑜伽、随意 | cross-legged, lotus position, sitting casually on floor |
| 跷二郎腿 | 一腿搭在另一腿上 | 自信、随意、思考 | legs crossed, crossed ankles, confident sitting |
| 侧身坐 | 身体侧向一边 | 聆听、观察、等待 | seated sideways, profile sitting, turned to side |
| 边缘坐 | 坐在椅子/床的边缘 | 即将离开、紧张、期待 | sitting on edge, perched, ready to rise |
| 席地而坐 | 直接坐在地上 | 野餐、放松、自然 | sitting on ground, floor sitting, casual picnic pose |

#### 躺卧类
| 姿势 | 场景 | 英文关键词 |
|------|------|------------|
| 仰面躺卧 | 草地上、床上、漂浮水中 | lying on back, supine, stargazing pose, floating |
| 侧卧蜷缩 | 沙发上、床上、胎儿姿势 | curled up, fetal position, cozy sleeping, side-lying |
| 俯卧趴着 | 沙滩、草地、床上 | lying on stomach, prone, sunbathing, relaxing face-down |

---

### 行走运动 (Movement Actions)

#### 行走类
| 动作 | 描述 | 情绪/节奏 | 英文关键词 |
|------|------|-----------|------------|
| 缓步前行 | 慢慢行走，步伐从容 | 悠闲、思考、享受 | walking slowly, leisurely stroll, unhurried pace, meandering |
| 大步流星 | 步幅大、速度快 | 目标明确、急切、自信 | striding purposefully, long strides, determined walk, confident pace |
| 踱步 | 来回走动，通常低头 | 焦虑、思考、犹豫 | pacing back and forth, anxious walking, restless strides |
| 踏步原地 | 原地踏步 | 等待、热身、不耐烦 | marching in place, stepping rhythmically, waiting |
| 蹒跚行走 | 步伐不稳、摇晃 | 受伤、醉酒、年老 | stumbling, unsteady gait, faltering steps, limping |
| 蹑手蹑脚 | 轻轻走路怕发出声音 | 偷偷摸摸、潜行 | tiptoeing, sneaking, stealthy walking, quiet footsteps |
| 欢快蹦跳 | 带跳跃感的步伐 | 开心、孩子气、活力 | skipping, hopping, joyful steps, bouncy walk, carefree |
| 拖沓前行 | 拖着脚走、不情愿 | 疲惫、沮丧、不想走 | dragging feet, trudging, reluctant walking, heavy steps |

#### 奔跑类
| 动作 | 描述 | 英文关键词 |
|------|------|----------|
| 全速冲刺 | 最大速度奔跑 | sprinting, full-speed running, dash, racing |
| 奔向镜头 | 朝观众方向跑来 | running toward camera, charging forward, approaching run |
| 奔离镜头 | 背对观众逃跑 | running away, fleeing, escape, retreating |
| 慢动作奔跑 | 被放慢的跑步动作 | slow-motion running, cinematic sprint, graceful motion |
| 追逐场景 | 两个人互相追赶 | chase sequence, pursuit, cat and mouse, pursuit |
| 跨越障碍 | 跳过/跨过障碍物 | vaulting, hurdling, leaping over obstacle, parkour |
| 跌倒爬起 | 跑动中摔倒再起来 | stumbling and recovering, falling and getting up, determination |

#### 跳跃腾空类
| 动作 | 英文关键词 | 使用场景 |
|------|------------|----------|
| 纵身跳跃 | jumping, leaping, vaulting, springing up | 欢庆、运动、舞蹈 |
| 空中翻跃 | mid-air flip, somersault, backflip, acrobatic leap | 体育、武术、杂技 |
| 自由落体 | free fall, falling through air, gravity takeover | 危险、梦境、失控 |
| 飞翔/悬浮 | flying, soaring, hovering, levitating | 奇幻、超能力、梦想 |
| 起跳瞬间 | takeoff moment, launch, push-off, departure from ground | 动态捕捉、力量展示 |
| 落地瞬间 | landing, impact moment, touchdown, arrival | 结束动作、震撼 |

#### 旋转舞动类
| 动作 | 描述 | 英文关键词 |
|------|------|----------|
| 旋转 | 身体绕中心轴转动 | spinning, twirling, rotating, pirouette, whirling |
| 舞蹈 | 各种舞蹈动作 | dancing, ballet, contemporary dance, expressive movement |
| 挥舞 | 手臂大幅摆动 | waving arms, gesturing wildly, conducting, celebrating |
| 翻滚 | 地面滚动 | rolling, tumbling, somersault, acrobatic roll |

---

### 手势动作 (Hand Gestures)

#### 问候/社交手势
| 手势 | 含义 | 英文关键词 |
|------|------|------------|
| 挥手打招呼 | 你好、再见、引起注意 | waving hello/goodbye, beckoning, greeting gesture |
| 握手 | 问候、达成协议、友好 | shaking hands, handshake, clasping hands |
| 击掌 | 庆祝、合作、鼓励 | high-five, giving high-five, celebratory slap |
| 拥抱 | 亲密、安慰、重逢 | hugging, embracing, warm embrace, holding each other |
| 拱手作揖 | 中式问候、尊敬 | Chinese salute, respectful bow, hands together gesture |
| 合十祈祷 | 祈祷、感谢、请求 | praying hands, namaste, palms together |

#### 表达/指示手势
| 手势 | 含义 | 英文关键词 |
|------|------|------------|
| 伸手指向远方 | 指引、目标、未来 | pointing at distance, indicating direction, gesturing ahead |
| 握拳用力 | 决心、愤怒、力量 | clenched fist, gripping tight, determined fist, power gesture |
| 竖起大拇指 | 赞许、认可、棒 | thumbs up, approval gesture, like sign, positive |
| 比OK手势 | 好的、没问题、完美 | OK sign, circle gesture, perfect signal |
| 比心/手指比心 | 爱、喜欢 | finger heart, love gesture, Korean heart sign |
| 双手张开 | 无奈、展示、拥抱准备 | open palms, shrugging, presenting, welcoming gesture |
| 手捂嘴巴 | 惊讶、忍住不说、窃笑 | covering mouth, gasping, suppressing emotion |
| 摸下巴/脸颊 | 思考、评估 | touching chin, thoughtful gesture, contemplating |
| 双手交叉胸前 | 防御、不同意、冷 | arms crossed, defensive posture, closed-off |

#### 触碰类手势
| 手势 | 描述 | 英文关键词 |
|------|------|----------|
| 伸手触摸 | 触摸某物/某人 | reaching out, touching, making contact, tender touch |
| 轻抚脸颊 | 温柔、自恋、沉思 | caressing cheek, gentle self-touch, introspective |
| 捂住心脏 | 真诚、感动、发誓 | hand on heart, pledging, sincere gesture, touched |
| 擦拭眼泪 | 悲伤、感动 | wiping tears, crying, emotional moment, tearful |
| 握紧某物 | 珍惜、决心、紧张 | gripping something tightly, clutching, holding dear |
| 松开手/放手 | 放下、释然、失去 | letting go, releasing, open palm dropping, surrender |

---

### 面部表情 (Facial Expressions)

#### 正面情绪
| 表情 | 描述 | 英文关键词 |
|------|------|------------|
| 微笑绽放 | 灿烂的笑容，可能露出牙齿 | bright smile, beaming, radiant grin, joyous expression |
| 含蓄微笑 | 轻微嘴角上扬，温柔 | gentle smile, subtle grin, soft smile, knowing smile |
| 开怀大笑 | 张嘴大笑，眼睛眯起 | laughing heartily, belly laugh, unrestrained joy, gleeful |
| 眼神发亮 | 眼睛睁大有神 | sparkling eyes, bright-eyed, twinkling eyes, engaged gaze |
| 欣喜若狂 | 极度开心，可能跳跃 | ecstatic, overjoyed, elated, thrilled expression |
| 满足陶醉 | 闭眼享受，表情安详 | blissful, content, savoring the moment, peaceful enjoyment |
| 俏皮眨眼 | 一只眼睛眨动 | playful wink, mischievous blink, flirty gesture |
| 吐舌头 | 俏皮、调皮 | sticking tongue out, playful, cheeky, teasing |

#### 负面情绪
| 表情 | 描述 | 英文关键词 |
|------|------|------------|
| 泪流满面 | 大量眼泪，可能抽泣 | crying, tears streaming down, sobbing, weeping |
| 默默流泪 | 静静流泪，表情悲伤 | silent tears, sorrowful, tearful, mournful |
| 愤怒咆哮 | 张嘴怒吼，眉头紧锁 | furious, raging, angry shout, enraged expression |
| 愤怒瞪眼 | 怒目而视，咬牙切齿 | glaring angrily, burning gaze, gritting teeth |
| 惊讶张嘴 | 嘴巴张大，眼睛圆睁 | shocked, jaw-dropped, astonished, stunned |
| 恐惧害怕 | 眼神恐惧，可能后退 | terrified, fearful, frightened expression, scared |
| 厌恶嫌弃 | 皱鼻撇嘴 | disgusted, revulsed, grimacing, displeased |
| 沮丧失望 | 垂头丧气，眼神黯淡 | disappointed, dejected, crestfallen, despondent |

#### 中性/复杂情绪
| 表情 | 描述 | 英文关键词 |
|------|------|------------|
| 闭眼享受 | 闭眼，表情安详满足 | eyes closed in bliss, savoring, serene enjoyment |
| 若有所思 | 目光游离，微微皱眉 | pensive, thoughtful, contemplative, lost in thought |
| 一脸茫然 | 表情空洞，不知所以 | blank expression, bewildered, puzzled, confused |
| 面无表情 | 无情绪波动（ poker face ） | expressionless, stoic, poker face, neutral, unreadable |
| 一脸怀疑 | 皱眉、眯眼、嘴角下撇 | skeptical, dubious, suspicious, questioning |
| 傲慢冷漠 | 轻蔑的眼神，高高在上 | arrogant, haughty, disdainful, cold expression |
| 羞涩腼腆 | 脸红、低头、不好意思 | shy, bashful, blushing, timid, coy |
| 坚定决绝 | 紧抿嘴唇，眼神锐利 | determined, resolute, steely gaze, firm expression |

---

### 互动行为 (Interactive Behaviors)

#### 亲密互动
| 行为 | 描述 | 英文关键词 |
|------|------|----------|
| 拥抱 | 两人身体紧贴 | hugging, embracing, warm embrace, holding each other close |
| 亲吻 | 嘴唇接触 | kissing, kissing passionately, tender kiss, lips meeting |
| 牵手 | 手拉手 | holding hands, hand in hand, fingers intertwined |
| 依偎 | 靠在对方肩上 | leaning on shoulder, cuddling, nestling against |
| 额头相抵 | 额头贴在一起，很亲密 | forehead touching, intimate moment, noses almost touching |
| 背抱 | 从后面抱住 | hugging from behind, back hug, embrace from rear |
| 捧脸亲吻 | 双手捧着脸亲吻 | cupping face and kissing, tender face cradling |

#### 对抗/冲突
| 行为 | 描述 | 英文关键词 |
|------|------|----------|
| 争吵对峙 | 面对面激烈对话 | arguing, confrontation, heated exchange, face-to-face conflict |
| 推搡 | 用力推对方 | shoving, pushing aggressively, physical altercation |
| 指责对方 | 手指指向对方 | accusing, pointing finger, blaming, confrontational gesture |
| 转身离去 | 愤怒地背对对方 | turning away in anger, storming off, dramatic exit |
| 冷战对视 | 互不理睬或冷漠对视 | silent treatment, cold stare, tense standoff, giving cold shoulder |

#### 合作/友好
| 行为 | 描述 | 英文关键词 |
|------|------|----------|
| 击掌庆祝 | 互相击掌 | high-fiving, celebratory high-five, team celebration |
| 肩并肩站立 | 并排站立 | standing shoulder to shoulder, side by side, united front |
| 举手击拳 | 一起举拳加油 | raising fists together, team spirit, collective cheer |
| 互相扶持 | 揶扶、帮助 | supporting each other, helping hand, lending shoulder |
| 传递物品 | 交接某物 | handing over, passing something, exchanging items |

---

## 构图焦点技巧详解

### 中心构图 (Center Composition)

**原理**: 将主体放置在画面正中心。

**优点**: 
- 最直接的视觉焦点
- 稳定、庄重、重要
- 适合正式、仪式性场景

**缺点**: 可能呆板、缺乏动感

**使用场景**:
- 肖像照（证件照、皇室肖像）
- 对称建筑
- 仪式场景（婚礼、加冕）
- 需要强调"这是最重要的"

**优化技巧**:
- 利用光线创造层次
- 背景虚化减少呆板
- 主体本身有动态姿态

**提示词**: `centered composition, central framing, symmetrical placement, focal point at center, prominent center positioning`

---

### 三分法则 (Rule of Thirds)

**原理**: 画面用两条横线和两条竖线分成9宫格，主体放在交叉点上（4个"能量点"之一）。

**为什么有效**:
- 符合人眼自然扫视习惯
- 比中心构图更有趣、更动态
- 创造视觉张力

**使用方法**:
- 将眼睛放在上1/3线上
- 将地平线放在上1/3或下1/3线
- 主体放在左侧或右侧的交叉点
- 看的方向留更多空间（"视线空间"规则）

**提示词**: `rule of thirds, third-line placement, off-center composition, intersection point framing, balanced asymmetry`

---

### 框架构图 (Frame within a Frame / Framing)

**原理**: 利用场景中的元素（门框、窗户、拱门、树枝、隧道等）在主体周围形成一个"画框"。

**效果**:
- 增加画面层次感（前景-中景-背景）
- 自动引导视线到主体
- 创造"窥视感"或"发现感"
- 增加故事性和神秘感

**常用"画框"元素**:
- 建筑: 门、窗、拱门、廊柱、桥洞
- 自然: 树枝形成的圆圈、洞穴口、两块岩石之间
- 人造: 镜框、屏幕、取景器
- 光影: 光圈、暗角形成的圆形框架

**提示词**: `framing, frame within a frame, natural frame, architectural frame, doorway framing, window view, tunnel composition, foreground arch`

---

### 对称构图 (Symmetrical Composition)

**原理**: 画面左右（或上下）基本镜像对称。

**效果**:
- 秩序感、稳定感
- 庄严、正式、和谐
- 满足人类对秩序的审美需求
- 可能有压迫感（过度对称）

**使用场景**:
- 建筑（尤其古典/宗教建筑）
- 倒影（水面完美反射）
- 正面肖像
- 仪式场景
- 迷宫、花园等人工设计的场景

**打破对称的方法**（增加趣味）:
- 在对称中加入一个小的不对称元素
- 人物稍微偏离中线
- 一侧有动作发生

**提示词**: `symmetrical composition, mirror symmetry, balanced halves, centered symmetry, formal arrangement, harmonious reflection`

---

### 对角线构图 (Diagonal Composition)

**原理**: 主体或主要线条沿画面对角线方向分布。

**效果**:
- 动态感、运动感
- 张力和不稳定感
- 引导视线从一个角落到另一个
- 比水平和垂直线更有活力

**创造对角线的元素**:
- 实际的对角线: 楼梯、山坡、道路、桥梁
- 暗示的对角线: 人物姿态（倾斜的身体）、光束、视线
- 抽象的对角线: 色块分割、明暗交界线

**使用场景**:
- 动作场景（增强动感）
- 倾斜的建筑（表现危险/奇特）
- 运动/竞赛
- 抽象艺术构图

**提示词**: `diagonal composition, dynamic angle, tilted orientation, corner-to-corner, energetic alignment, action-oriented framing`

---

### 引导线构图 (Leading Lines)

**原理**: 利用场景中的线条元素引导观众视线到主体。

**常见引导线**:
- 自然: 河流、海岸线、山脊、树干排列
- 建筑: 道路、铁路、桥梁、走廊、行列
- 光影: 光束、阴影边缘、透视汇聚线
- 人物: 排列的人群、视线方向

**效果**:
- 增强画面深度感
- 自然引导视觉焦点
- 创造三维空间感
- 增加画面的叙事性

**使用技巧**:
- 线条可以汇聚到主体（一点透视）
- 线条可以从主体向外辐射
- 可以有多组不同方向的引导线

**提示词**: `leading lines, converging lines, perspective lines, depth creation, visual pathway, vanishing point, guiding lines toward subject`

---

### 留白构图 (Negative Space Composition)

**原理**: 主体只占画面一小部分，大面积"空白"（可以是纯色、模糊、黑暗等）。

**效果**:
- 孤独、渺小、隔离感
- 给想象空间
- 极简美学
- 强调主体的重要性（对比）
- 宁静、禅意

**"留白"的形式**:
- 纯色/白色留白
- 模糊背景留白（浅景深）
- 暗色/黑色留白
- 天空/地面留白
- 雾/烟造成的留白

**使用场景**:
- 表现孤独/寂寞
- 极简主义设计
- 文字海报（给标题留空间）
- 表达"未知""无限"
- 禅意、冥想主题

**提示词**: `negative space, minimal subject, expansive emptiness, isolated figure, vast empty space, breathing room, minimalist composition`

---

## 叙事要素构建

### 时间流逝的暗示

**通过光线暗示**:
- 日光的移动（影子长度变化）
- 同一场景不同时间的对比
- 季节变化的暗示（树叶、积雪）

**通过物体状态暗示**:
- 融化的冰
- 枯萎的花
- 墙上的痕迹/裂纹
- 生锈的金属
- 成长的植物

**提示词语句**:
```
time passing indicated by light changes
shadows marking the passage of time
seasonal transition suggested
worn by time, weathered surface
moment frozen in time, timeless quality
```

### 情绪传递的构建

**肢体语言**:
- 开放姿态 vs 收缩姿态
- 朝向（面向=接受，背向=拒绝）
- 身体距离（亲密=近，疏远=远）

**环境烘托**:
- 天气反映内心（下雨=悲伤，晴朗=开朗）
- 空间反映状态（宽敞=自由，狭窄=压抑）
- 光线反映情绪（暖光=希望，冷光=孤独）

**色彩心理学**:
- 暖色=积极、能量、亲近
- 冷色=消极、距离、冷静
- 高饱和=强烈情绪
- 低饱和=平淡/抑郁

**提示词语句**:
```
emotional atmosphere conveyed through body language
mood reflected in environment
color palette expressing inner state
lighting mirroring the character's feelings
poignant stillness speaking volumes
```

### 故事悬念的制造

**信息隐藏**:
- 部分被遮挡的主体
- 门缝/窗帘后的光
- 影子而非本体
- 背影而非正脸

**矛盾元素**:
- 不该出现在此处的物品
- 异常的比例关系
- 不协调的色彩
- 时间错乱

**视线引导**:
- 角色注视画外（观众想知道看什么）
- 多个角色的视线交汇点（空的）
- 指向画面外的手势/箭头

**提示词语句**:
```
intriguing partial view
mysterious silhouette
something hidden just out of frame
gaze directed beyond the frame
unanswered question hanging in the air
narrative tension, story hint
```

### 冲突对立的并置

**视觉对比**:
- 大 vs 小
- 旧 vs 新
- 自然 vs 人工
- 秩序 vs 混乱
- 光 vs 暗
- 生机 vs 死亡

**经典对立意象**:
- 废墟中盛开的鲜花（希望 vs 绝望）
- 儿童在战争废墟中（纯真 vs 残酷）
- 高科技设备在原始自然中（进步 vs 传统）
- 华丽礼服在肮脏环境中（高贵 vs 堕落）

**提示词语句**:
```
powerful juxtaposition of contrasting elements
visual irony and contradiction
harmony of opposites
tension between [element A] and [element B]
symbolic contrast telling a deeper story
```
