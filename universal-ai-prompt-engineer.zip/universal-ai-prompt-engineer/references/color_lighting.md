# ⑥ 色调光效 (Color & Lighting) - 完整数据

## 色调体系详解

### 1. 暖色调 (Warm Color Palette)

**定义**: 以红色、橙色、黄色为主导的色彩系统。

**色彩构成**:
- 核心色: 朱砂红(#FF5733)、橘橙(#FF8C00)、金黄(#FFD700)、蜜桃粉(#FFB6C1)
- 辅助色: 珊瑚色、赭石、土黄、奶油色、玫瑰金
- 中性基底: 米白、象牙白、浅驼

**心理效应与氛围**:
- 积极: 温暖、热情、活力、幸福、亲密、乐观
- 舒适: 安全、放松、怀旧、治愈、家的感觉
- 能量: 行动力、食欲、创造力、社交欲望增强
- 时间感: 黄昏、午后阳光、秋天的感觉

**适用场景**:
- 家庭/室内温馨场景
- 日落/黄昏时刻
- 浪漫约会/爱情故事
- 秋季场景
- 餐饮美食摄影
- 复古怀旧主题
- 婚礼/庆典

**暖色调细分**:
| 变体 | 色彩倾向 | 情绪关键词 |
|------|----------|------------|
| **炽热暖** | 高饱和红橙 | 激情、危险、能量、夏日正午 |
| **柔润暖** | 低饱和桃粉/杏色 | 温柔、浪漫、春日、少女 |
| **大地暖** | 土黄/赭石/棕褐 | 自然、朴实、秋天、乡村 |
| **烛光暖** | 暗调中的暖光源 | 温馨、私密、夜晚、怀旧 |
| **复古暖** | 泛黄的暖色 | 怀旧、老照片、记忆、年代感 |

**即梦提示词示例**:
```
warm color palette, golden hour tones, amber and orange hues, warm sunlight, cozy atmosphere, sunset glow, honey-colored light, inviting warmth
暖色调，金黄色调和，琥珀色与橙色光影，温暖的阳光，舒适的氛围，日落余晖，蜂蜜色的光线，诱人的温暖感
```

---

### 2. 冷色调 (Cool Color Palette)

**定义**: 以蓝色、青色、紫色为主导的色彩系统。

**色彩构成**:
- 核心色: 宝石蓝(#0066CC)、湖蓝(#4AA3DF)、青色(#00CED1)、薰衣草紫(#9370DB)、靛青(#4B0082)
- 辅助色: 薄荷绿、灰蓝、银色、石墨色、午夜蓝
- 中性基底: 白、浅灰、奶白

**心理效应与氛围**:
- 冷静: 平和、理智、专注、沉稳、专业
- 忧郁: 孤独、忧伤、沉思、疏离
- 科技: 现代、数字、未来、清洁
- 神秘: 深邃、未知、梦幻、超现实
- 清新: 干净、清爽、卫生、早晨

**适用场景**:
- 科技/数码产品场景
- 夜景/月光场景
- 医疗/科学环境
- 冬季/冰雪场景
- 忧郁/孤独情绪表达
- 企业/商务专业场景
- 未来/太空题材

**冷色调细分**:
| 变体 | 色彩倾向 | 情绪关键词 |
|------|----------|------------|
| **冰蓝冷** | 高亮蓝色、近白 | 寒冷、冬季、清晨、洁净 |
| **深海冷** | 深蓝/藏青 | 深沉、神秘、广阔、智慧 |
| **电光冷** | 荧光青/霓虹蓝 | 科技、电子、赛博、未来 |
| **暮光冷** | 蓝紫过渡 | 黄昏后的天空、宁静转神秘 |
| **忧郁冷** | 去饱和灰蓝 | 悲伤、孤独、压抑、雨天 |
| **极简冷** | 单一冷色+大量留白 | 设计感、现代、高端 |

**即梦提示词示例**:
```
cool color palette, blue tones, cyan and azure hues, moonlit blues, serene atmosphere, digital coolness, icy freshness, contemplative mood
冷色调，蓝色基调，青色和蔚蓝色调，月光蓝，宁静的氛围，数字化清凉感，冰爽的新鲜感，沉思的情绪
```

---

### 3. 黑白色调 (Monochrome / Black & White)

**定义**: 仅使用从纯黑到纯白的灰阶，无彩色。

**灰阶层次**:
```
纯白 #FFFFFF (Highlight/高光)
├── 极浅灰 #E0E0E0 (Light Gray/浅灰)
├── 浅灰   #C0C0C0
├── 中灰   #808080 (Mid Gray/中灰) ← 18%灰是标准中性灰
├── 深灰   #404040 (Dark Gray/深灰)
├── 极深灰 #202020
└── 纯黑 #000000 (Shadow/暗部)
```

**黑白的美学价值**:
- **永恒性**: 不受时代影响，经典永不过时
- **聚焦本质**: 去除色彩的干扰，关注形式、光影、构图
- **情感强化**: 有时比彩色更有冲击力和戏剧性
- **艺术性**: 摄影/电影艺术的重要表现形式
- **时间感**: 历史、回忆、严肃、仪式感

**黑白的技术处理**:
| 处理方式 | 效果 |
|----------|------|
| **高对比黑白** | 强烈的明暗对比，戏剧性强（希区柯克风格）|
| **低对比黑白** | 灰蒙蒙的、朦胧、雾气感（张艺谋《英雄》部分场景）|
| **分区曝光** | 局部提亮/压暗，增加层次（安塞尔·亚当斯风格）|
| **颗粒感** | 加入胶片颗粒，增加质感和年代感 |
| **漂白效果(Bleach Bypass)** | 保留少量色彩在阴影中，冷峻高级感（《拯救大兵瑞恩》）|

**适用场景**:
- 纪录片风格
- 电影经典场景致敬
- 情绪低沉/严肃的时刻
- 回忆/闪回序列
- 肖像摄影
- 艺术/抽象创作
- 新闻纪实

**即梦提示词示例**:
```
black and white, monochrome, grayscale photography, high contrast B&W, dramatic shadows, film noir aesthetic, timeless elegance, Ansel Adams style, chiaroscuro lighting
黑白摄影，单色调，高对比度黑白，戏剧性的阴影，黑色电影美学，永恒的优雅，安塞尔·亚当斯风格，明暗对照法
```

---

### 4. 复古色调 (Vintage / Retro Color Palette)

**定义**: 模拟老旧照片/胶片的色彩特征，通常伴随低饱和度和偏色。

**复古类型详解**:

#### 70年代复古
- **特征**: 暖黄/棕褐色偏移、低对比、略微褪色
- **关键词**: 70s retro, faded photograph, sepia tint, aged photo, vintage warmth, brownish cast
- **氛围**: 老照片、家庭相册、怀旧

#### 90年代胶片
- **特征**: 柯达Gold系列的感觉、略偏暖、胶片颗粒
- **关键词**: 90s film look, Kodak Gold aesthetic, point-and-shoot camera vibe, nostalgic color, analog feel
- **氛围**: 童年记忆、随手拍、真实生活

#### Lomo/漏光效果
- **特征**: 四周暗角、高饱和局部、意外漏光造成的光斑
- **关键词**: Lomography, light leaks, vignetting, cross-processed colors, toy camera aesthetic
- **氛围**: 实验、年轻、随意、惊喜

#### 宝丽来(Polaroid)风格
- **特征**: 独特的色彩还原、边框、即时成像感
- **关键词**: Polaroid aesthetic, instant film colors, dreamy pastels, soft focus, white borders
- **氛围**: 即兴、珍贵、不可复制

#### 欧洲艺术片色调
- **特征**: 去饱和、偏绿/偏黄、低对比
- **关键词**: European art house film, muted palette, desaturated tones, cinematic nostalgia, Wong Kar-Wai inspired (王家卫风格)
- **氛围**: 忧郁、文艺、诗意

**即梦提示词示例**:
```
vintage color grading, retro aesthetic, faded film look, warm sepia tones, analog photograph, aged patina, nostalgic color shift, 1970s color palette, light leak effects
复古色调，怀旧美学，褪色的胶片感，暖棕褐色调，模拟照片效果，岁月痕迹，怀旧色彩偏移，70年代色彩风格，漏光效果
```

---

### 5. 荧光色调 (Neon / Cyberpunk Color Palette)

**定义**: 高饱和度的荧光/霓虹色彩，通常配合黑暗背景。

**核心色彩**:
- **霓虹粉 (Neon Pink)**: #FF1493 / #FF00FF (Magenta)
- **霓虹青 (Neon Cyan)**: #00FFFF / #00CED1
- **霓虹绿 (Neon Green)**: #39FF14 / #00FF00
- **霓虹紫 (Neon Purple)**: #BF00FF / #8A2BE2
- **霓虹橙 (Neon Orange)**: #FF6600 / #FF4500
- **电光蓝 (Electric Blue)**: #0066FF / #1E90FF

**视觉效果**:
- 黑暗中的强烈光源感
- "光晕"和"辉光"效果
- 高对比度（亮vs极暗）
- 色彩"刺眼"、无法忽视
- 未来感和电子感

**技术实现描述**:
- 发光的灯管/灯带
- 光线在大气中的散射
- 湿润表面的反射
- 透射光（透过烟雾/蒸汽）
- CRT显示器/全息投影的自发光

**适用场景**:
- 赛博朋克/反乌托邦
- 夜店/迪厅/音乐会
- 未来城市夜景
- 电子游戏界面
- 先锋时尚摄影
- 音乐专辑封面
- 广告/品牌视觉

**避免**: 自然场景（除非有意制造超现实冲突）

**即梦提示词示例**:
```
neon color palette, cyberpunk neon, fluorescent pinks and cyans, glowing lights against darkness, electric colors, synthwave aesthetic, vaporwave vibes, high saturation luminescence
荧光色调，赛博朋克霓虹，荧光粉与青色，黑暗中的发光色彩，电子色彩，合成器波美学，蒸汽波氛围，高饱和度发光
```

---

### 6. 莫兰迪色系 (Morandi Color Palette)

**定义**: 意大利画家乔治·莫兰迪(Giorgio Morandi)作品中的色彩特征——每种颜色都掺入一定比例的灰色，形成独特的"高级灰"色系。

**色彩特征**:
- 所有颜色都有"灰调"
- 低饱和度但不暗淡
- 柔和、不刺激眼睛
- 颜色之间和谐统一
- 有一种"雾蒙蒙"的质感

**典型莫兰迪色**:
| 色相 | 莫兰迪版本 | HEX参考 |
|------|-----------|---------|
| 白 | 奶油白/本白 | #F5F5DC |
| 粉 | 灰粉/干枯玫瑰 | #D4A5A5 |
| 蓝 | 灰蓝/雾霾蓝 | #8FA5B5 |
| 绿 | 灰绿/鼠尾草绿 | #A8B5A0 |
| 黄 | 杏仁黄/奶黄 | #E8DCC4 |
| 紫 | 灰紫/芋泥紫 | #B8A5B8 |
| 棕 | 灰棕/奶茶色 | #C4A882 |
| 橙 | 脏橘/陶土色 | #D4A078 |

**心理感受**:
- 高级、优雅、克制
- 安静、平和、治愈
- 文艺、知性、温柔
- 有品味、不俗气
- 时间沉淀的质感

**适用场景**:
- 生活方式/家居
- 文艺女性肖像
- 产品包装设计
- 时尚编辑
- 室内设计展示
- "ins风"/"小红书"美学
- 治愈系内容

**即梦提示词示例**:
```
Morandi color palette, desaturated dusty tones, muted elegance, sophisticated grays, soft pastel greys, understated luxury, Italian aesthetic, calm and refined colors, gentle harmony
莫兰迪色系，去饱和的灰调色彩，柔和的高级感，精致的灰色调，柔和的灰粉灰蓝，低调的奢华，意大利美学，平静而精致的色彩，温柔的和谐
```

---

### 7. 黑暗色调 (Dark Color Palette)

**定义**: 以深色为主、整体亮度偏低、可能仅保留少量亮点色彩的系统。

**色彩构成**:
- 主导色: 黑色(#000000)、深灰(#1A1A1A)、墨色(#0D0D0D)
- 点缀色（如有）: 暗红(#8B0000)、深紫(#4B0082)、暗金(#B8860B)、幽绿(#006400)
- 有限的光源色: 烛光橙、月光蓝、屏幕冷光

**视觉特征**:
- 大面积暗部/黑色区域
- 高反差的小面积亮点
- 可能只有轮廓光/边缘光
- 阴影占主导地位
- "见光不见源"的神秘感

**心理效应**:
- 恐惧/不安（恐怖题材）
- 神秘/未知（悬疑/惊悚）
- 成熟/性感（时尚摄影）
- 压抑/沉重（剧情需要）
- 庄严/神圣（特定宗教/仪式场景）

**黑暗色调细分**:
| 类型 | 特征 | 用途 |
|------|------|------|
| **纯黑主导** | 几乎全黑，仅轮廓可见 | 悬念、恐怖、神秘人物登场 |
| **深色低对比** | 暗但不完全黑，细节可见 | 忧郁、沉重、严肃剧情 |
| **选择性照明** | 大面积黑暗+聚光灯效果 | 舞台、侦探、黑色电影 |
| **暗色+单色点缀** | 深色底+单一色彩强调 | 时尚、先锋、有设计感 |
| **暗色+暖光源** | 深色背景+烛光/壁灯 | 温暖但神秘、私密空间 |

**适用场景**:
- 恐怖/惊悚片
- 黑色电影(film noir)
- 夜景/夜间场景
- 神秘学/魔法
- 哥特/暗黑风格
- 成熟时尚摄影
- 悬疑/推理
- 末世/废土

**注意事项**:
- 过于黑暗可能导致AI生成质量下降（细节丢失）
- 建议: 至少保留一个明确的光源和主体受光面
- 可以用"chiaroscuro"（明暗法）来平衡黑暗

**即梦提示词示例**:
```
dark color palette, low-key lighting, predominantly black, deep shadows, selective illumination, moody darkness, film noir aesthetic, mysterious obscurity, dramatic contrast between light and dark
黑暗色调，低调布光，以黑色为主导，深邃的阴影，选择性照明，情绪化的黑暗，黑色电影美学，神秘的晦暗，光与影之间的戏剧性对比
```

---

## 光源类型详解

### 自然光源 (Natural Light Sources)

#### 日光 (Daylight / Sunlight)
**特性**: 最主要的人造光替代品，全天候变化。

| 时段 | 色温 | 光线质量 | 描述 |
|------|------|----------|------|
| **黄金时刻 (Golden Hour)** | 2000-3000K | 柔和、暖色、方向性 | 日出后/日落前1小时，摄影师最爱 |
| **蓝色时刻 (Blue Hour)** | 9000-12000K | 冷蓝、弥散、微弱 | 日出前/日落后20分钟，天空呈深蓝 |
| **正午日光** | 5500-6000K | 强烈、硬阴影、顶光 | 中午前后，对比强烈 |
| **阴天散射光** | 6500-7500K | 柔和、无方向、均匀 | 云层作为柔光箱 |
| **逆光/轮廓光** | 取决于时间 | 从主体背后照射 | 勾勒边缘、产生光晕 |

**提示词**: `natural sunlight, golden hour lighting, warm directional sunlight, soft overcast light, dappled light through leaves`

---

#### 月光 (Moonlight)
**特性**: 反射太阳光，亮度约为太阳的百万分之一。

**视觉效果**:
- 冷蓝色调（实际月亮反射光偏暖，但人脑感知为冷）
- 柔弱、浪漫、神秘
- 长而 soft 的阴影
- 通常需要长时间曝光才能看清细节（摄影角度）

**月相影响**:
- 满月: 最亮、最圆、适合"明月"意象
- 弦月: 有方向性、更诗意
- 新月: 几乎无光、仅有星光

**提示词**: `moonlight, full moon illumination, silvery glow, cold moonbeams, nocturnal luminescence, romantic moonlight bathing scene`

---

#### 星光与环境光 (Starlight & Ambient)
**特性**: 极其微弱的宇宙光源 + 大气散射光。

**提示词**: `starlight, starry night sky, ambient glow from heavens, cosmic faint light, twinkling stars as sole illumination`

---

### 人造光源 (Artificial Light Sources)

#### 柔光箱/摄影棚灯光 (Softbox / Studio Lighting)
**特性**: 专业摄影用的可控光源，经过扩散变得柔和均匀。
**效果**: 无硬阴影、可控方向、可调节色温和强度
**类型**:
- 主光源(key light): 主要照明
- 补光灯(fill light): 减少阴影
- 轮廓光(rim/hair light): 分离背景
- 背景光(background or kicker): 照亮背景

**提示词**: `studio lighting, softbox illumination, professional setup, diffused even light, controlled studio environment, beauty dish lighting`

---

#### 点光源/聚光灯 (Spotlight / Point Source)
**特性**: 从一个点发出的集中光束，产生明显阴影。

**类型与应用**:
| 类型 | 应用场景 | 效果 |
|------|----------|------|
| 舞台聚光灯 | 舞台、演出 | 戏剧性、聚焦主角 |
| 手电筒 | 探索、恐惧、悬疑 | 移动的光锥、紧张感 |
| 台灯/落地灯 | 室内阅读、私密空间 | 温馨、聚焦、小范围照明 |
| 蜡烛/烛台 | 浪漫、古老、仪式 | 摇曳、温暖、短暂 |
| 壁灯 | 走廊、古典建筑 | 氛围、固定位置 |
| 路灯 | 城市街道、夜晚 | 孤独、安全感的岛屿 |
| 屏幕/显示器光 | 现代生活 | 冷色调、照亮脸部下方 |

**提示词**: `spotlight illumination, focused beam of light, single light source creating drama, spotlight on subject, theatrical lighting, pool of light in darkness`

---

#### 环境光 (Ambient / Environmental Light)
**特性**: 场景中所有间接光照的总和。

| 环境类型 | 特征光效 | 描述 |
|----------|----------|------|
| 城市夜景 | 多种人造光混合 | 霓虹、路灯、窗户光的复杂组合 |
| 室内综合光 | 多光源叠加 | 吊灯+台灯+窗户光的混合 |
| 工业环境 | 功能性照明 | 荧光灯管、警示灯、仪表盘光 |
| 商业空间 | 均匀明亮照明 | 商场、办公室的白亮灯光 |
| 地下/洞穴 | 极少或特殊光源 | 荧光矿物、火把、头灯 |

**提示词**: `ambient city lights, mixed indoor lighting, fluorescent office glow, commercial brightness, subterranean dimness`

---

### 特殊布光技法

#### 轮廓光/边缘光 (Rim Light / Edge Light)
**定义**: 从主体背面（通常是侧后方）打光，在边缘形成亮线。

**作用**:
- 分离主体与暗背景
- 勾勒轮廓、增加立体感
- 营造"神圣""发光"的效果
- 增加画面层次

**变体**:
- **完整轮廓光**: 整个边缘被照亮
- **部分轮廓光**: 只照亮肩膀/头发的一侧
- **轮廓光+背光**: 更强烈的分离效果

**提示词**: `rim lighting, edge light, backlighting silhouette separation, hair light, glowing outline, halo effect, luminous contour`

---

#### 底光/顶光 (Bottom Light / Top Light)
**这两种都是"非正常"布光，用于创造不安感。**

**底光 (Under-lighting / Monster Light)**:
- 从下往上照射
- 使熟悉的面孔变得怪异恐怖
- 常用于恐怖片（鬼怪、反派）
- 也用于营造科技感（屏幕照亮脸的下部）

**顶光 (Top Lighting / Overhead)**:
- 从正上方照射
- 眼窝凹陷、阴影在鼻子下方
- 审讯/高压场景常用
- 正午太阳的自然效果

**提示词**: `under-lighting effect, monstrous illumination from below, unsettling uplight, harsh top-down lighting, interrogation lighting, overhead starkness`

---

#### 分裂光 (Split Lighting)
**定义**: 光源来自侧面90°，一半脸亮一半暗。
**效果**: 戏剧性、神秘、双重性、内心冲突
**常用于**: 黑色电影、反派角色、内心挣扎的场景

**提示词**: `split lighting, half-lit face, dramatic side illumination, chiaroscuro effect, dual-tone face, light and shadow divide`

---

## 光影效果详解

### 体积光 / 丁达尔效应 (Volumetric Lighting / God Rays / Tyndall Effect)

**物理原理**: 光线穿过含有微粒（灰尘、水雾、烟雾）的介质时，光路变得可见。

**视觉效果**:
- 可见的光束/光柱
- 从窗户/缝隙中倾泻而下的"耶稣光"
- 神圣、庄严、超自然的氛围
- 增加画面的深度和空气感

**触发条件**（必须在提示词中说明）:
- 有强光源（通常是侧逆方向的太阳/灯光）
- 有介质（雾、烟、尘、水汽、云、 underwater ）
- 暗背景衬托（否则光束不明显）

**描述词汇**:
```
god rays, volumetric lighting, Tyndall effect, crepuscular rays, light beams visible in air, sunbeams through clouds/mist, divine light shafts, atmospheric scattering, dust motes dancing in light, light streaming through window, cathedral lighting
```

**应用场景**:
- 森林清晨（穿过树梢的晨光）
- 教堂/寺庙（彩色玻璃窗的光束）
- 洞穴入口（光线照入黑暗）
- 水下（从水面射入的阳光）
- 舞台（聚光灯在烟雾中的光柱）
- 神话/宗教场景

---

### 镜头光晕 (Lens Flare)

**定义**: 强光源进入镜头时产生的光学伪影。

**视觉效果**:
- 光源周围的星芒/多边形光斑
- 横跨画面的光条纹
- 朦胧的光雾覆盖画面
- 增加真实感和"现场感"

**类型**:
| 类型 | 外观 | 来源 |
|------|------|------|
| 星芒星状 | 多角星形光芒 | 小光圈拍摄点光源 |
| 环形光晕 | 圆形/多边形光环 | 镜片内部反射 |
| 光 streak | 横贯画面的线条 | 光源在画面边缘 |
| 薄雾光晕 | 整画面轻微泛白 | 强光源造成的眩光 |

**提示词**: `lens flare, anamorphic lens flare, starburst effect, light artifacts, optical flare, cinematic glare, sun flare across frame, bright light source bloom`

**注意**: 不要过度使用；现代观众已习以为常

---

### 暗角 (Vignetting)

**定义**: 画面边缘逐渐变暗、中心相对较亮的效果。

**效果**:
- 自动引导视线到中心
- 增加"取景框"感
- 老镜头/老照片的特征
- 聚焦、亲密、专注

**程度**:
- **轻度暗角**: 微妙、几乎不被注意到但有效
- **中度暗角**: 明显的边缘变暗、Lomo风格
- **重度暗角**: 边缘几乎全黑、隧道视觉、极端聚焦

**提示词**: `vignette, vignetting effect, darkened edges, corner shading, focused center, tunnel vision, Lomo dark corners, subtle edge falloff, intimate framing`

---

### 映射反射 (Reflections)

**类型与描述**:

| 表面 | 反射特征 | 描述词汇 |
|------|----------|----------|
| 水面（平静） | 镜面反射、对称 | mirror-like reflection, perfect water reflection, symmetrical image on water |
| 水面（波动） | 扭曲破碎的倒影 | rippled reflection, distorted image on water surface, abstract watery mirror |
| 湿地面 | 局部斑块状反射 | puddle reflections, wet pavement mirroring city lights, rain-soaked street reflections |
| 冰面/玻璃 | 半透明反射 | ice reflections, glass surface reflecting surroundings, frosted window glow |
| 金属表面 | 锐利清晰的高光 | polished metal reflection, chrome mirror surface, specular highlight |
| 眼睛（眼神光） | 角膜上的微小反光 | catchlight, eye reflection, sparkle in eye, glint of light in gaze |

**提示词**: `reflection on wet ground, mirrored surface, water ripples distorting reflection, gleaming wet streets after rain, eyes with catchlight`

---

### 阴影投射 (Shadow Projection)

**重要原则**: 有光必有影，阴影是三维感的关键。

**阴影的类型**:
| 类型 | 特征 | 使用技巧 |
|------|------|----------|
| 硬阴影 (Hard Shadow) | 边缘锐利、对比强 | 点光源/强直射光（如正午太阳）|
| 软阴影 (Soft Shadow) | 边缘模糊、过渡柔和 | 大光源/散射光（如阴天、柔光箱）|
| 投射阴影 (Cast Shadow) | 物体投在其他面上 | 增加空间关系和真实感 |
| 附着阴影 (Attached Shadow) | 物体自身的暗面 | 塑造立体形态 |
| 长影子 (Long Shadow) | 低角度光产生的延伸阴影 | 黄昏/黎明、戏剧性、时间指示 |

**创意阴影用法**:
- **窗影**: 窗框在地上/墙上投下格子状影子
- **百叶窗影子**: 条纹状阴影扫过物体
- **树叶影子**: 斑驳的光影（特别受欢迎的唯美元素）
- **栏杆影子**: 有节奏的竖条阴影
- **人物的影子**: 可以独立成为构图元素（甚至没有人物本体）

**提示词**: `dramatic long shadows, sharp hard-edged shadows, soft diffused shadows, window shadow patterns, dappled light and shade through leaves, cast shadow stretching across ground, silhouette projection`
