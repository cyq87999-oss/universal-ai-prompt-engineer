# ② 风格艺术 (Art Style) - 完整数据

## 12种核心风格预设详解

### 1. 电影感 (Cinematic/Film)

**核心理念**: 模拟电影摄影的美学标准，追求专业电影级的视觉效果。

**中文关键词库**:
```
基础: 电影质感、电影级、宽银幕、cinematic、film look
胶片特征: 胶片颗粒感(film grain)、胶片划痕(film scratch)、柯达色调(Kodak color)、菲林感
技术术语: anamorphic宽银幕变形、浅景深(shallow DOF)、电影布光(cinematographic lighting)、达芬奇调色(DaVinci color grade)
导演风格参考: 
  - 韦斯·安德森式: 对称构图、糖果色、复古
  - 克里斯托弗·诺兰式: IMAX感、实拍偏好、宏大叙事
  - 王家卫式: 抽帧、暧昧光影、都市孤独
  - 宫崎骏式: 温暖手绘感、自然主义光效
```

**英文关键词**:
```
cinematic, film grain, anamorphic, letterbox, movie still, cinematography, shallow depth of field, bokeh, color grading, Arri Alexa look, IMAX quality, blockbuster visual
```

**最佳搭配**:
- 光效: 伦勃朗光、轮廓光、体积光
- 色调: Teal & Orange（青橙色调，好莱坞最爱）
- 适用: 叙事短片、广告、预告片

---

### 2. 动漫风 (Anime Style)

**核心理念**: 模仿日本动漫/漫画的视觉表现手法。

**中文关键词库**:
```
基础: 二次元、日系动画、anime style、manga aesthetic
线条: 勾线(outline)、赛璐珞染色(cel shading)、干净线稿(clean lines)
眼睛: 大眼睛、星星眼、高光点(anime highlights)
特效: 速度线(speed lines)、冲击波、汗滴、表情符号(deformation symbols)
画风细分:
  - 少年Jump风: 动态姿势、力量线条、戏剧性透视
  - 少女漫画风: 大眼、花卉装饰、闪亮背景
  - 新海诚风: 极致光影、写实背景、情感渲染
  - 京都动画风: 细腻日常、温暖色调、生活化
```

**英文关键词**:
```
anime style, manga art, cel shaded, 2D animation, Japanese animation, Studio Ghibli inspired, anime eyes, vibrant anime colors, anime screenshot, anime key visual
```

**最佳搭配**:
- 人物: 夸张比例、标志性发色、独特服装
- 背景: 可写实可简化，建议精细背景+卡通人物
- 适用: 角色设计、幻想场景、同人创作

---

### 3. 赛博朋克 (Cyberpunk)

**核心理念**: 高科技与低生活的反乌托邦未来美学。

**中文关键词库**:
```
核心: cyberpunk、赛博朋克、高科技低生活(high tech low life)
视觉元素: 
  - 霓虹灯光(neon lights): 粉色/青色/紫色霓虹管、汉字/日文霓虹招牌
  - 湿滑路面(wet pavement): 雨夜、地面反射霓虹光
  - 高密度垂直城市: 飞行汽车、立体交通、全息广告
  - 义体改造(cybernetics): 机械手臂、发光义眼、神经接口
色彩: 青色(cyan) + 品红(magenta) + 深黑，高对比度
参考作品: 《银翼杀手》《攻壳机动队》《赛博朋克2077》
子风格:
  - 日式赛博朋克: 更多日本元素（鸟居、和服、忍者）
  - 工业废土: 更脏乱、锈蚀、废弃工厂感
  - 干净未来派: 白色基调、苹果式极简科技
```

**英文关键词**:
```
cyberpunk, neon lights, futuristic city, neon noir, blade runner aesthetic, dystopian future, holographic advertisements, rain-slicked streets, chrome and rust, cybernetic implants, Tokyo neon, synthwave colors
```

**最佳搭配**:
- 时间: 夜晚（必须）
- 场景: 未来城市贫民窟/霓虹小巷/高科技实验室
- 细节: 汉字招牌、飞行器、全息投影

---

### 4. 水彩画 (Watercolor)

**核心理念**: 模拟水彩颜料的流动、晕染、透明特性。

**中文关键词库**:
```
技法特征:
  - 晕染效果(wash/wetting): 颜色自然扩散、边界模糊
  - 水痕(water blooms): 颜料沉积形成的纹理
  - 湿画法(wet-on-wet): 湿颜料混合、柔和过渡
  - 留白(preserving whites): 纸张本色透出
  - 纸纹可见(paper texture): 水彩纸纹理
色彩特点: 
  - 透明感(transparency)
  - 清新淡雅
  - 颜色可叠加混合
适用主题: 花卉、风景、女性肖像、儿童插画、文学插图
艺术家参考: 
  - 莫奈的水彩系列
  - 中国传统水墨（可结合）
  - 现代清新插画风（如几米绘本）
```

**英文关键词**:
```
watercolor painting, watercolor effect, artistic wash, fluid colors, paper texture, translucent layers, soft edges, aquarelle, painterly, impressionistic watercolor, delicate brushstrokes
```

**最佳搭配**:
- 主体: 花朵、女性、自然风景、动物
- 色调: 柔和粉彩、莫兰迪色
- 细节: 花瓣、蝴蝶、露珠

---

### 5. 油画 (Oil Painting)

**核心理念**: 模拟油画的厚重笔触、丰富色彩层次、经典质感。

**中文关键词库**:
```
技法特征:
  - 厚涂(impasto): 厚重笔触、颜料堆叠、可见纹理
  - 薄涂(glazing): 透明色层叠加、深邃光泽
  - 调色刀(palette knife): 刀触痕迹、粗犷有力
  - 笔触可见(visible brushstrokes): 保留绘画过程痕迹
流派细分:
  - 古典油画(classical fine art): 达芬奇/伦勃朗风格、精细罩染法
  - 印象派(impressionism): 莫奈/雷诺阿、光影捕捉、松散笔触
  - 后印象派(post-impressionism): 梵高、旋转笔触、强烈色彩
  - 现代抽象(modern abstract): 表现主义、抽象色彩
画布效果: 画布纹理(canvas texture)、裂纹(craquelure)、边缘晕染
```

**英文关键词**:
```
oil painting, classical oil, impasto technique, visible brushstrokes, canvas texture, old master style, Rembrandt lighting, chiaroscuro, Baroque painting, museum quality, gallery artwork, thick paint texture
```

**最佳搭配**:
- 主体: 肖像、静物、古典风景
- 光效: 明暗对照法(chiaroscuro)
- 参考: 卢浮宫/大都会博物馆藏画风格

---

### 6. 国潮/中国风 (Chinese Style / Guochao)

**核心理念**: 融合中国传统美学与现代设计语言。

**中文关键词库**:
```
核心元素:
  - 传统色彩: 中国红、琉璃黄、青花蓝、翡翠绿、藕荷粉
  - 纹样图案: 祥云、龙凤、如意纹、回纹、八卦、太极、敦煌飞天
  - 文化符号: 书法文字、印章、水墨意境、工笔画、年画
  - 建筑元素: 飞檐斗拱、红墙黄瓦、园林亭台、牌坊
艺术形式融合:
  - 水墨画(ink wash): 写意、留白、墨分五色
  - 工笔画(gongbi): 精细线条、层层渲染
  - 敦煌壁画(Dunhuang murals): 飞天、藻井、矿物颜料
  - 皮影/剪纸: 民俗艺术、剪影美学
现代演绎:
  - 新中式(neo-Chinese): 传统元素的简约现代表达
  - 国潮街头: 传统+街头文化碰撞
  - 游戏国风: 仙侠/古风游戏美术风格
```

**英文关键词**:
```
Chinese traditional art, oriental aesthetics, ink wash painting, calligraphy style, dragon and phoenix motifs, auspicious clouds, red lanterns, classical Chinese architecture, gongbi detail, Dunhuang inspired, Zen minimalism
```

**最佳搭配**:
- 文化维度: 中华文化全套
- 色调: 红/金/黑/白 或 青/绿/水墨灰
- 细节: 必须包含中国元素（至少2个）

---

### 7. 极简主义 (Minimalist)

**核心理念**: "少即是多"，去除一切不必要元素，突出本质。

**中文关键词库**:
```
原则:
  - 留白(white space/negative space): 大面积空白
  - 简洁几何(simple geometry): 基础形状构成
  - 有限配色(limited palette): 通常1-3种颜色
  - 去装饰(no ornamentation): 无多余装饰
视觉特征:
  - 干净线条(clean lines)
  - 平面感(flat design)
  - 大量负空间
  - 高对比度或极度统一
变体:
  - 日式极简(Japanese minimalism): 侘寂(wabi-sabi)、朴素材质
  - 北欧风(Scandinavian): 温暖中性色、天然材质
  - 现代极简(modern minimalist): 黑白灰+一个亮点色
  - 苹果式(Apple-style): 产品摄影级简洁
```

**英文关键词**:
```
minimalist, minimalism, clean design, simple geometry, white space, negative space, less is more, uncluttered, refined simplicity, modern minimalist, Scandinavian design, zen aesthetic
```

**最佳搭配**:
- 构图: 中心构图 or 极致留白
- 色调: 单色(monochromatic) or 双色
- 细节: 越少越好，每个元素都必须有意义

---

### 8. 超现实主义 (Surrealism)

**核心理念**: 梦境逻辑，将不相关的元素以令人惊讶的方式组合。

**中文关键词库**:
```
核心特征:
  - 梦境般(dreamlike): 似曾相识又超现实
  - 并置(juxtaposition): 不相关事物的意外组合
  - 变形(metamorphosis): 物体的超现实变形
  - 不可能(impossible physics): 违反物理法则
大师参考:
  - 萨尔瓦多·达利(Salvador Dalí): 融化的时钟、长腿大象、荒芜景观
  - 勒内·马格利特(René Magritte): 苹果遮脸、悬浮岩石、日常物品异常化
  - 埃舍尔(M.C. Escher): 不可能的建筑、无限循环楼梯
常见意象:
  - 漂浮的物体
  - 巨大的日常物品
  - 身体与物体的融合
  - 天空中的异象
  - 时间空间的扭曲
```

**英文关键词**:
```
surrealism, surreal, dreamlike, Dalí style, impossible scene, fantastical juxtaposition, mind-bending, subconscious imagery, surrealist art, dreamscape, bizarre combination, paradox visual
```

**最佳搭配**:
- 创意: 打破常规联想
- 细节: 越荒诞越符合超现实定义
- 适用: 艺术创作、概念设计、创意广告

---

### 9. 吉卜力/治愈系 (Studio Ghibli)

**核心理念**: 吉卜力工作室动画电影的温暖、手绘、自然主义美学。

**中文关键词库**:
```
核心特征:
  - 手绘温度(hand-crafted warmth): 非数字完美的手工感
  - 自然崇拜(nature worship): 精致的自然描绘是核心
  - 治愈感(healing/iyashikei): 平静、温暖、让人心安
  - 细节丰富(background art): 背景画极其精美细致
色彩特点:
  - 温暖的大地色系: 草绿、天蓝、泥土棕、云朵白
  - 柔和的光线: 从不刺眼，总是温柔包裹
  - 四季变化: 特别擅长描绘自然的微妙变化
典型场景元素:
  - 草原/田野/麦田
  - 蓝天白云（特定画法的云）
  - 乡村房屋/小木屋
  - 飞行场景（这是吉卜力标志性的）
  - 食物制作（美食场景特别治愈）
参考作品:
  《千与千寻》《龙猫》《哈尔的移动城堡》《起风了》
```

**英文关键词**:
```
Studio Ghibli style, Ghibli aesthetic, Hayao Miyazaki inspired, hand-drawn animation warmth, healing anime, pastoral beauty, lush greenery, soft clouds, whimsical countryside, animated film background art
```

**最佳搭配**:
- 场景: 自然风光、乡村、小镇
- 光效: 温柔日光、云隙光
- 情绪: 温暖、治愈、怀旧

---

### 10. 好莱坞大片 (Hollywood Blockbuster)

**核心理念**: 商业电影的高冲击力、高预算感视觉风格。

**中文关键词库**:
```
特征:
  - 高对比度 HDR 感
  - 戏剧性布光(dramatic lighting)
  - 广角+特写交替的动态剪辑感
  - 大量视觉特效(VFX-heavy)
  -史诗规模(epic scale)
类型细分:
  - 漫威MCU风格: 明亮鲜艳、动作清晰、略带漫画感
  - 诺兰式实拍: IMAX画幅、实拍爆炸、厚重音效暗示
  - 迈克尔·贝: 镜头晃动、爆炸、快切
  - 《沙丘》式: 暗调、广袤、庄严
色彩科学:
  - Teal Orange（青橙色调）占主导
  - 皮肤色调保护（orange-teal分离）
  - 高动态范围
```

**英文关键词**:
```
Hollywood blockbuster, epic cinematic, high-budget film look, VFX-heavy, dramatic scale, action movie aesthetic, Marvel cinematic universe style, IMAX quality, explosive visuals, movie poster composition
```

**最佳搭配**:
- 镜头: 大全景展示规模 + 快速剪辑暗示
- 光效: 戏剧性强对比光
- 适用: 动作、冒险、史诗、超级英雄

---

### 11. 日系清新/小清新 (Japanese Fresh/Aesthetic)

**核心理念**: 日本流行的"治愈系""ins风"摄影美学，柔和、日常、有格调。

**中文关键词库**```
核心特征:
  - 低饱和度 pastel 色调
  - 柔和光线（避免硬阴影）
  - 日常生活美学
  - 胶片相机感（特别是柯达Portra/Fuji胶片感）
常见元素:
  - 日系少女: 清新妆容、自然发型、简单穿搭
  - 生活场景: 咖啡馆、书店、便利店、电车
  - 自然元素: 花朵（尤其实体花）、天空、大海
  - 季节感: 樱花季、夏日祭、红叶、初雪
摄影技巧模拟:
  - 浅景深（背景虚化bokeh）
  - 过曝轻微（high-key lighting）
  - 胶片颗粒
  - 自然抓拍感（非刻意摆拍）
参考: Instagram上的日系摄影师、日杂《POEY》、滨田英明
```

**英文关键词**:
```
Japanese aesthetic, fresh style, soft pastel tones, gentle light, everyday beauty, film photography look, Fujifilm tones, airy and light, youthful serenity, minimalist lifestyle photography
```

**最佳搭配**:
- 主体: 年轻女性、日常生活片段
- 色调: 粉/蓝/米/白 low saturation
- 细节: 自然光线、真实生活场景

---

### 12. 暗黑哥特 (Dark Gothic)

**核心理念**: 黑暗、浪漫、神秘的哥特式美学，融合恐怖与美感。

**中文关键词库**:
```
核心特征:
  - 黑暗基调(dark base): 以黑色、深色为主
  - 浪漫化恐怖(romanticized horror): 恐怖但美丽
  - 宗教/死亡 symbolism: 十字架、玫瑰、乌鸦、墓碑
  - 维多利亚时代影响: 蕾丝、紧身胸衣、烛光
子风格细分:
  - 浪漫哥特(Romantic Gothic): 安妮·莱斯《夜访吸血鬼》、玫瑰与鲜血
  - 维多利亚哥特(Victorian Gothic): 《简爱》《呼啸山庄》氛围
  - 现代哥特(Modern Gothic): 工业金属、暗黑时尚
  - 哥特洛丽塔(Gothic Lolita): 黑色蕾丝、可爱与黑暗的结合
典型元素:
  - 哥特式建筑: 尖拱、彩色玻璃、石像鬼
  - 自然元素: 枯萎玫瑰、满月、蝙蝠、迷雾
  - 服装: 黑色礼服、蕾丝、十字架首饰、苍白肤色
  - 色彩: 黑+深红+深紫+银色
参考作品:
  - 《亚当斯一家》《僵尸新娘》（蒂姆·伯顿）
  - 《睡魔》(The Sandman/尼尔·盖曼)
  - 哥特摇滚视觉
```

**英文关键词**:
```
dark gothic, gothic aesthetic, Victorian horror, romantic darkness, Tim Burton style, dark fantasy, macabre beauty, black lace, crimson accents, moonlit graveyard, gothic cathedral, melancholic elegance
```

**最佳搭配**:
- 光效: 月光、烛光、闪电、轮廓光（避免正常光照）
- 色调: 去饱和冷调 + 点缀深红/深紫
- 细节: 玫瑰（尤其是枯萎的）、乌鸦、十字架、蕾丝

---

## 艺术技法补充库

### 光影处理技法
| 技法 | 中文名 | 英文术语 | 效果描述 |
|------|--------|----------|----------|
| 明暗对照法 | 明暗对照法 | chiaroscuro | 强烈的明暗对比，戏剧性 |
| 轮廓光 | 轮廓光/边缘光 | rim light / edge light | 从背后照亮主体边缘，分离背景 |
| 体积光 | 体积光/丁达尔效应 | god rays / volumetric lighting | 可见光束穿过介质 |
| 伦勃朗光 | 伦勃朗三角光 | Rembrandt lighting | 面部特定三角形光斑 |
| 分裂光 | 分裂光照 | split lighting | 一半脸亮一半暗 |
| 布蝶光 | 蝴蝶光 | butterfly lighting | 颈下产生蝴蝶形阴影 |
| 顶光 | 顶光 | top light / overhead | 从正上方照射，戏剧/不安 |

### 笔触与肌理
| 技法 | 效果 | 适用风格 |
|------|------|----------|
| 厚涂 impasto | 颜料厚重堆叠，3D纹理 | 油画、表现主义 |
| 薄涂 glazing | 透明色层，宝石般光泽 | 古典油画、超写实 |
| 干刷 dry brush | 粗糙、颗粒感、毛发感 | 素描、速写、粗糙质感 |
| 湿画法 wet-on-wet | 颜料在湿润时混合，柔和过渡 | 水彩、丙烯 |
| 点彩 pointillism | 纯色点并列，视觉混色 | 印象派后继 |
| 平涂 flat coloring | 无笔触、均匀填色 | 动漫、矢量、极简 |

### 构图法则
| 法则 | 说明 | 使用建议 |
|------|------|----------|
| 三分法则 rule of thirds | 画面分九宫格，交点放主体 | 最通用、最自然 |
| 黄金分割 golden ratio | 1:1.618 比例 | 经典、和谐、高级感 |
| 对称构图 symmetry | 左右/上下镜像对称 | 庄严、正式、仪式感 |
| 引导线 leading lines | 线条引导视线至主体 | 增强深度、方向感 |
| 框架构图 framing | 用门/窗/树枝框住主体 | 层次、窥视感、聚焦 |
| 对角线 diagonal | 主体沿对角线分布 | 动态、张力、不稳定感 |
| 三角形 composition | 主体形成三角形布局 | 稳定、平衡、力量感 |

### 色彩理论应用
| 配色方案 | 说明 | 情感效果 |
|----------|------|----------|
| 补色 complementary | 色轮对面色（如蓝+橙） | 最大对比、醒目、活力 |
| 类比色 analogous | 色轮相邻色（如蓝+青+绿） | 和谐、自然、舒适 |
| 单色 monochromatic | 同一色相不同明度/饱和度 | 统一、简洁、专注 |
| 分裂互补 split-complementary | 一色+其对面的两个邻居 | 有对比但不失和谐 |
| 三等分 triadic | 色轮上等距三色 | 平衡、丰富、活泼 |
| 双色互补 tetradic/complementary | 两对补色 | 复杂、丰富、需谨慎使用 |
