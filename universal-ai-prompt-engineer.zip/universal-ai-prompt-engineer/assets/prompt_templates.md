# 即梦提示词生成模板集合

## 模板1: 标准图像生成提示词

### 中文模板
```
[风格修饰], [主体描述（人物/物体）], [动作/姿态/表情], [服装/外观特征], [场景/环境], [时间/天气], [光线效果], [色调氛围], [镜头语言], [细节装饰]
```

### 英文模板
```
[Style Modifier], [Subject Description (Person/Object)], [Action/Pose/Expression], [Costume/Appearance], [Scene/Environment], [Time/Weather], [Lighting Effect], [Color Mood], [Camera Language], [Details & Decoration]
```

### 使用示例
**输入**:
- 风格: 电影感
- 主体: 年轻女子
- 动作: 回眸微笑
- 服装: 白色连衣裙
- 场景: 海边悬崖
- 时间: 黄昏
- 光线: 侧逆光金色阳光
- 色调: 温暖橙粉色
- 镜头: 中近景 + 浅景深
- 细节: 海鸥、飘动的发丝

**输出 - 中文版**:
```
电影感, 一位身穿白色飘逸连衣裙的年轻女子, 优雅回眸露出温柔微笑, 海风吹拂长发与裙摆, 站在海边悬崖之上, 黄昏 golden hour 的温暖时刻, 金色的侧逆光勾勒出轮廓光, 整体呈现温暖的橙粉色调, 采用中近景构图配合浅景深虚化背景, 远处有几只海鸥飞翔, 发丝在风中轻轻舞动
```

**输出 - 英文版**:
```
cinematic film style, a young woman wearing a flowing white dress, gracefully turning back with a gentle smile, sea breeze blowing through her hair and dress, standing on a seaside cliff edge during the golden hour of sunset, warm side-backlight creating a beautiful rim light, overall warm orange-pink color palette, medium close-up composition with shallow depth of view blurring the background, seagulls flying in the distance, hair dancing lightly in the wind
```

---

## 模板2: 视频生成提示词

### 中文模板
```
[风格], [主体], [缓慢连贯的动作描述], [镜头运动方式], [环境中的动态变化], [光影的动态效果], [时长暗示词], [整体氛围]
```

### 英文模板
```
[Style], [Subject], [Slow continuous action description], [Camera movement], [Environmental dynamics], [Dynamic lighting effects], [Duration hints], [Overall atmosphere]
```

### 关键差异（图像 vs 视频）

| 维度 | 图像提示词 | 视频提示词 |
|------|-----------|-----------|
| **动作** | 静态姿态 | 连贯动作（用"缓慢地""正在""逐渐"等动态词汇）|
| **镜头** | 固定景别 | 运镜（推拉摇移、环绕、航拍等）|
| **环境** | 静态背景 | 有变化（风吹、水流动、云飘移等）|
| **光影** | 固定光照 | 可有变化（光线移动、明暗过渡）|
| **时长** | 无需 | 暗示"X秒钟的...""持续性的..."|

### 视频专用词汇库

#### 动作动态词汇
```
中文：缓慢转身、正在行走、轻轻抬起、渐渐绽放笑容、随风摆动、缓缓低头、正在舞动、逐步靠近
英文：slowly turning, walking gently, slowly lifting, gradually smiling, swaying with the wind, slowly lowering head, dancing gracefully, gradually approaching
```

#### 镜头运动词汇
```
中文：镜头缓缓推进、相机围绕旋转、从左向右平移、航拍俯冲、镜头拉远揭示
英文：camera slowly pushing in, orbiting around subject, panning from left to right, aerial dive shot, pulling back to reveal
```

#### 环境动态词汇
```
中文：云层缓缓移动、波浪不断拍岸、树叶沙沙作响、火焰跳动、烟雾缭绕上升
英文：clouds drifting slowly, waves continuously crashing, leaves rustling, flames flickering, smoke swirling upward
```

### 使用示例

**输入**: 一个武侠剑客竹林舞剑的视频片段

**输出**:
```
中文：中国风电影感，一位身着白色汉服的东方剑客，在翠绿的竹林中缓缓挥舞长剑，剑光如流水般划破空气，镜头围绕他做360度环绕拍摄，竹叶被剑气带动纷纷飘落，透过竹叶缝隙的金色阳光形成斑驳的光影随动作闪烁，5秒钟的连贯动作展示行云流水的剑术之美，仙气缭绕的氛围中透着武学的力量感

English: Chinese wuxia cinematic style, an Eastern swordsman dressed in flowing white hanfu, slowly wielding a long sword in the emerald bamboo forest, blade cutting through air like flowing water, camera orbiting 360 degrees around him, bamboo leaves stirred by sword energy falling and dancing, dappled golden sunlight filtering through bamboo gaps flickering with the movement, 5 seconds of continuous motion showcasing fluid swordsmanship, an atmosphere of immortal qi mixed with martial power
```

---

## 模板3: 分镜脚本 (Storyboard Template)

### 分镜表格模板

```markdown
## 分镜脚本: [项目名称]

**故事概要**: [一句话描述完整叙事]
**总时长目标**: [XX] 秒
**镜头数量**: [N] 个
**整体风格**: [风格选择]

---

### 镜头 1 / [总镜头数]

**基础信息**
- 时长: [X] 秒
- 景别: [远景/全景/中景/近景/特写]
- 场景: [地点]
- 时间: [日/夜/黄昏/黎明]

**画面内容**
- 主体: [人物/物体]
- 动作: [具体动作]
- 氛围: [情绪状态]

**技术参数**
- 镜头运动: [固定/推/拉/摇/移/升降/环绕]
- 光线: [光源类型+方向]
- 色调: [主色调]
- 关键细节: [1-3个重要细节]

**提示词 - 中文**
[完整的中文提示词]

**提示词 - 英文**
[完整的英文提示词]

**转场说明**
→ 到下一镜头: [淡入淡出/切镜头/推拉转场/叠化/擦除]

---
（每个镜头重复上述格式）
```

### 完整分镜示例框架

```markdown
# 分镜脚本: 《城市邂逅》

**故事概要**: 一个忙碌的都市白领女性在下班途中偶然遇见让她停下脚步的美好瞬间
**总时长目标**: 30秒
**镜头数量**: 5个
**整体风格**: 日系清新 + 电影感

---

## 镜头 1/5: 开场建立场景（3秒）

- 时长: 3秒
- 景别: 远景大全景（Establishing Shot）
- 场景: 繁忙的城市十字路口，黄昏时分
- 时间: 傍晚/黄昏 golden hour

**画面内容**
- 主体: 匆匆忙忙的人群（不突出个人）
- 动作: 人潮涌动、红绿灯切换、车流穿梭
- 氛围: 忙碌、快节奏、略带压抑

**技术参数**
- 镜头运动: 固定镜头或极慢推
- 光线: 城市黄昏的混合光（路灯初亮+夕阳余晖）
- 色调: 暖橙渐变到城市霓虹的蓝紫
- 关键细节: 红绿灯倒计时、公交车驶过

**提示词 - 中文**:
日系清新的电影感，繁忙的城市十字路口远景大全景，黄昏 golden hour 时刻，熙熙攘攘的人潮穿过斑马线，车流如织的红绿灯路口，城市的路灯开始亮起与夕阳余晖交织，暖橙色天空向城市霓虹的蓝紫色调过渡，固定镜头捕捉这座城市的忙碌节奏，略微的胶片颗粒感增加真实氛围

**提示词 - English**:
Japanese fresh cinematic aesthetic, wide establishing shot of a busy city intersection during golden hour, crowds of people crossing the pedestrian crossing, heavy traffic at the signalized intersection, city streetlights beginning to glow mingling with the last rays of sunset, warm orange sky transitioning to blue-purple urban neon tones, static camera capturing the rhythm of this bustling city, slight film grain adding authentic atmosphere

**转场**: → 切镜头（Cut）到镜头2

---

## 镜头 2/5: 主角登场（5秒）

- 时长: 5秒
- 景别: 中全景（Full Shot）
- 场景: 人行道上
- 时间: 同上（连续）

**画面内容**
- 主体: 一位25岁左右的年轻职场女性
- 动作: 快步走着，突然放慢脚步
- 氛围: 从匆忙到被吸引的转变

**技术参数**
- 镜头运动: 跟踪拍摄（Tracking Shot）
- 光线: 侧面暖光（夕阳侧光）
- 色调: 保持暖调但主角稍微提亮
- 关键细节: 公文包、职业装但略显疲惫

**(后续镜头省略，按照同样格式继续...)**
```

---

## 模板4: 批量生成表格

### CSV导出格式

```csv
序号,主题,风格,主体,动作,场景,光线,色调,中文提示词,英文提示词,参数建议
1,春日樱花,吉卜力风,穿JK制服的少女,伸手接住飘落的樱花瓣,樱花大道树下,柔和春日日光,粉白嫩绿,[完整提示词],[complete prompt],1:1/高画质
2,夏夜烟火,日系清新,浴衣少女,仰望夜空绽放的烟花,夏日祭会场,烟花照亮脸庞,深蓝底色+烟花彩色,[完整提示词],[complete prompt],16:9/视频5s
...(继续)
```

### 批量生成清单格式

```markdown
# 批量生成任务清单

**统一设置**:
- 风格基准: [默认风格]
- 质量标准: 最高画质
- 输出语言: 双语（中+英）

---

## 任务 1/N: [主题名称]

**核心要素**:
- 主体:
- 场景:
- 特殊要求:

**生成的提示词**:

### 中文:
[提示词内容]

### English:
[prompt content]

**备注**:
[特殊说明、参数建议等]

---
(每个任务重复)
```

---

## 模板5: 提示词优化记录表

### 原始 → 优化对照表

| 项目 | 原始版本 | 优化版本 | 修改原因 |
|------|----------|----------|----------|
| **风格描述** | "好看的照片" | "电影感、浅景深、胶片颗粒感" | 太模糊→具体可执行 |
| **主体描述** | "一个女人" | "一位20多岁的亚洲女性，黑色长发及腰，五官精致" | 缺少细节→增加辨识度 |
| **动作描述** | "站着" | "侧身站立，重心落在右腿上，左手轻抚发梢" | 太静态→增加姿态美感 |
| **场景描述** | "在外面" | "欧洲石板路小巷，两侧是文艺复兴风格的建筑，地面湿润反光" | 模糊→精确到可想象 |
| **光效描述** | （无） | "阴天散射光形成的柔和顶光，偶尔有云隙光穿透" | 补充关键维度 |
| **色彩描述** | （无）| "莫兰迪色系为主，灰粉与雾霾蓝的搭配" | 增加色彩指导 |
| **镜头描述** | （无）| "采用三分法构图，人物位于右侧交点，左侧留有引导线空间" | 增加专业构图 |
| **细节描述** | （无）| "手中拿着一本旧书，脚边有一只橘猫，远处有模糊的咖啡馆灯光" | 增加趣味点和层次 |

### 优化检查清单

```
□ 是否补充了风格关键词？（至少2个具体风格词）
□ 主体是否有足够的细节？（年龄/性别/服饰/特征）
□ 动作是否具体而非笼统？
□ 场景是否能让人产生空间想象？
□ 是否包含光线信息？（至少一种光源）
□ 是否包含色调/色彩倾向？
□ 是否考虑了镜头/构图？（即使简单提及）
□ 是否有1-3个点睛细节？
□ 字数是否在合适范围？（50-200字中文）
□ 中英文是否准确对应？
```
