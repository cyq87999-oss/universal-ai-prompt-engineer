---
name: universal-ai-prompt-engineer
description: "全链路 AI 短视频生产引擎 — 从剧本撰写、导演级提示词工程、AI 图像/视频生成，到 FFmpeg/剪映 API 剪辑合成。当用户需要：①创建端到端 AI 短视频（主题→剧本→提示词→图像→视频→成片）；②生成即梦AI/Midjourney/SD 导演级提示词；③编写分镜脚本并自动化剪辑；④使用 FFmpeg 或剪映 API 完成视频合成时使用。触发词：短视频、提示词、prompt、AI 生成、即梦、分镜、剪辑、FFmpeg、剪映、导演级"
---

# 万能AI短视频生产引擎 v3.0

## 技能概述

本技能实现了从一句话创意到完整短视频的**全自动生产流水线**，整合了 4 个专业 Agent 工作流、8 大提示词维度、导演级分镜节奏模板，以及 FFmpeg/剪映 API 两条剪辑路径。

### 端到端生产流程

```
用户输入主题
    ↓
Phase 1: 剧本撰写 (script_writing Agent)
    ↓
Phase 2: 导演级提示词工程 (8 大维度 + 6 大公式体系)
    ↓
Phase 3: AI 图像生成 (batch_image_gen Agent / 即梦API / SD)
    ↓
Phase 4: AI 视频片段生成 (batch_video_gen Agent / 即梦 Seedance)
    ↓
Phase 5: 视频剪辑合成 (video_edit Agent / FFmpeg / 剪映 API)
    ↓
Phase 6: 导出与发布
```

### 核心能力矩阵

| 阶段 | 产出 | 技术方案 |
|------|------|----------|
| **剧本** | 分场景剧本 + 分镜头表 | script_writing Agent (豆包大模型) |
| **提示词** | 6 公式体系 + 自定义词库组合 | 8 大维度 + 20 章分类数据 |
| **图像** | 每场景一张高质量图片 | batch_image_gen Agent / 即梦 Seedream |
| **视频片段** | 每场景一段连续视频 | batch_video_gen Agent / 即梦 Seedance |
| **剪辑合成** | 完整短视频 | video_edit Agent / FFmpeg / 剪映 API |

---

## 触发条件

以下任一需求即可激活：

- "帮我做个短视频" / "AI 短视频" / "视频生成"
- "帮我写提示词" / "生成 prompt" / "即梦提示词"
- "分镜脚本" / "Storyboard" / "分镜头设计"
- "提示词万能公式" / "导演级提示词" / "SACSC"
- "FFmpeg 剪辑" / "视频合成" / "剪映 API"
- "/video" / "/prompt" / "/jimeng" / "/storyboard"

---

## Phase 1: 剧本撰写（script_writing Agent）

### Step 1.1: 需求收集

```
1. 【视频主题】一句话描述
2. 【视频类型】剧情短片 / 产品展示 / 知识科普 / 宣传片 / 音乐视频
3. 【目标时长】3-10秒 / 15秒 / 30秒 / 60秒
4. 【风格调性】电影感 / 国潮 / 赛博朋克 / 治愈 / 动漫风 / 其他
5. 【核心信息】必须传达的信息（可选）
6. 【目标受众】谁看（可选）
```

### Step 1.2: 生成剧本 + 分镜头表

参考 `references/agents-workflow.md` 中 script_writing Agent 的流程，使用大模型按以下结构输出：

```markdown
## 剧本: [标题]

**总时长**: XX 秒 | **镜头数**: N 个 | **叙事结构**: 开端 → 发展 → 高潮 → 结尾

| 镜头 | 时长 | 景别 | 画面内容 | 台词/旁白 | 转场 |
|------|------|------|----------|-----------|------|
| 1 | 3s | 远景 | ... | ... | 切 |
| 2 | 5s | 中景 | ... | ... | 淡入 |
```

**节奏设计原则**（参考 `references/director-prompt-template.md`）：
- 0-2秒 铺垫：建立场景基调，清晰引入主体
- 2-3.5秒 递进：情绪/运镜/特效逐步升级
- 3.5-5秒 爆发：推向高潮，定格"名场面"

---

## Phase 2: 导演级提示词工程

本阶段集成了 **6 套提示词公式体系**，覆盖从基础到导演级的全部需求。

### Step 2.1: 公式选择矩阵

| 级别 | 公式名称 | 适用场景 | 参考文件 |
|------|---------|---------|----------|
| **基础** | 7 大元素公式 | 快速出词 | `references/formula-ai-prompt.md` |
| **标准** | 视频/图像双公式 | 通用生成 | `references/ai-prompt-formula.md` |
| **进阶** | 8 大维度组合公式 | 精细控制 | `references/scene_background.md` 等 |
| **高级** | 6 模块万能公式 | 专业创作 | `references/prompt-universal-formula.md` |
| **导演级** | S-A-C-S-C 五步法 | 精确参数化控制 | `references/director-prompt-template.md` |
| **参考** | 20 章完整数据体系 | 自定义词库组合 | `references/prompt-data-complete.md` |

### Step 2.2: 导演级建模 — S-A-C-S-C 五步法

来自 `references/director-prompt-template.md` 的即梦官方推荐方法：

```
S - Subject (锚定主体): 贴参考图 + 明确主体/特征/环境
    例：白色短发女生，日系校服，樱花树下

A - Action (定义动作): 用英文动词标注物理动作，区分快慢幅度
    例：walk slowly（缓慢行走），抬手轻触樱花

C - Camera (规范运镜): 专业摄影术语 + 英文标注
    例：close-up（特写），slow pan right（缓慢右移）

S - Style (设定风格): 光线 + 画质 + 艺术风格
    例：影棚柔光，4K超清，日系清新胶片风

C - Constraints (添加约束): 「无XX」句式列商业禁忌
    例：无水印，无侵权元素，无模糊边缘，五官无变形
```

### Step 2.3: 图像提示词公式

```
主体内容 + 场景设定 + 风格参考 + 色彩/色调 + 构图视角 + 附加细节
```

**输出示例**（从 `references/prompt-data-complete.md` 实战案例）：
> 女子，倾世容颜，眉如远黛，眼眸深邃如星河，长发如瀑，碧玉簪束发，一袭白衣广袖流仙裙，银丝绣边随风飘动，立于云海之巅，手持长剑(剑身寒光凛冽) + 云雾缭绕的天宫废墟 + 东方玄幻水墨风 + 青白冷调 + 仰拍全景 + 挥剑瞬间(剑光如虹划破长空) + 4K电影质感 + 极致细节渲染

### Step 2.4: 视频提示词公式

```
(镜头语言 + 景别角度 + 光影) + 主体(主体描述) + 主体运动 + 场景(场景描述) + (氛围)
```

**输出示例**（5秒科幻能量爆发，来自 `references/director-prompt-template.md`）：
```
分镜 1 (0-2s):
  主体/动作: 银发少女身着未来战斗服，缓慢转身，眼神坚毅
  场景/运镜: 赛博朋克城市天台，黄昏侧逆光；中景固定镜头
  音效: 环境音-25dB，轻微风声

分镜 2 (2-3.5s):
  主体/动作: 少女抬手，掌心凝聚蓝紫色光球
  场景/运镜: 同天台；镜头从腰部缓慢推进至面部特写
  音效: 电子音效渐起，音量-20dB

分镜 3 (3.5-5s):
  主体/动作: 能量爆发，手掌猛力前推
  场景/运镜: 急速推进+轻微环绕，爆发瞬间定格
  音效: 闪电+漩涡+冲击波三段爆发，-5dB+BGM高潮
```

### Step 2.5: 20 章完整数据调用

当用户需要自定义词库选择时，从 `references/prompt-data-complete.md` 调用相应章节：

| 数据章节 | 内容 | 适用场景 |
|---------|------|---------|
| 第1章 风格(60+) | 经典绘画/现代艺术/影视摄影等 8 大类 | 选定视觉风格 |
| 第2章 镜头(50+) | 焦距/角度/景深/构图等 8 类 | 设定镜头类型 |
| 第3-7章 运镜 | 基础→高级→动态→情绪→特殊场景 | 细化运镜方式 |
| 第8章 人物详细 | 面部/发型/身材/服装 4 层细分 | 精确人物刻画 |
| 第9章 人物服饰 | 古风/都市/奇幻/职业等组合 | 快速设定服装 |
| 第10章 场景 | 自然/建筑/街景/室内等 | 场景描述 |
| 第11章 色调光效 | 20 种色调 + 20 种光效 | 光影设定 |
| 第12-16章 扩展库 | 场景60组/细节60组/天气30组/情绪30组/材质30组 | 丰富画面细节 |
| 第17章 动作 | 手部/头部/身体/武打/日常 | 动作描述 |
| 第18章 表情 | 基础表情/微表情/复合情绪/神态 | 表情刻画 |
| 第19章 动作延展 | 分解序列/残影/特效/互动 | 视频时序描述 |

---

## Phase 3: AI 图像生成（batch_image_gen Agent）

### Step 3.1: Agent 工作流

参考 `references/agents-workflow.md` 的 `batch_image_gen` 节点：

```
对 Phase 1 生成的每个场景：
  1. 使用 Phase 2 输出的图像提示词
  2. 调用图片生成 API（即梦 Seedream 5.0 / SD 本地 / Midjourney）
  3. 生成匹配场景描述的高质量图片
  4. 循环处理所有场景 → 输出 N 张图片
```

### Step 3.2: 平台参数模板

| 平台 | 提示词语言 | 比例 | 关键参数 | 参考 |
|------|-----------|------|---------|------|
| 即梦AI Seedream | 中文 | 根据最终视频比例 | 风格强度80% | API: doubao-seedream-5-0-260128 |
| Midjourney | 英文 | --ar 16:9/9:16 | --s 250, --v 6 | 参考公式体系 |
| Stable Diffusion | 英文 | 16:9 | CFG 7-12, Steps 20-50 | `scripts/sd_model.py` |

### Step 3.3: SD 模型配置（可选子模块）

- **LoRA 微调**：`scripts/lora_train.py`（rank=32, lr=1e-4, steps=1000）
- **DPO 优化**：`scripts/dpo_train.py`
- **推理管线**：`scripts/sd_model.py`（参考 `references/prompt-universal-formula.md` 中 SKILL (1).md 的详细操作步骤）

---

## Phase 4: AI 视频片段生成（batch_video_gen Agent）

### Step 4.1: Agent 工作流

参考 `references/agents-workflow.md` 的 `batch_video_gen` 节点：

```
对 Phase 3 生成的每张图片：
  1. 使用图片 + 对应的视频提示词
  2. 调用视频生成 API（即梦 Seedance 1.5 Pro / 其他平台）
  3. 生成带运动效果的短视频片段（3-5秒）
  4. 循环处理所有图片 → 输出 N 个视频片段
```

### Step 4.2: 视频提示词增强（导演级）

使用 `references/director-prompt-template.md` 的专业指导：

**运镜语言**（推/拉/移/跟/摇/升降/环绕）→ 组合使用黄金组合：
- 推进 + 环绕：引导视线聚焦主体
- 拉远 + 抬升：揭示全貌制造宏大感
- 跟拍 + 横移：稳定沉浸式追踪

**动态效果分层**（从微弱到强烈，与节奏同步）：
- 动态模糊：轻度 / 中度 / 重度
- 光轨拖尾：短拖尾 / 长拖尾 / 渐消散
- 冲击波：两段 / 三段 / 渐进式

**画面质感**：
- 4K超高清 + 电影级质感 + 胶片颗粒感（8%）
- 电影暗角 + 画面锐化

---

## Phase 5: 视频剪辑与合成（video_edit Agent）

### Step 5.1: Agent 工作流

参考 `references/agents-workflow.md` 的 `video_edit` 节点：

```
1. 拼接 Phase 4 输出的所有视频片段
2. 按分镜表顺序排列
3. 添加转场特效
4. 叠加字幕
5. 添加 BGM + 音效
6. 调整全片节奏
```

### 路径 A: FFmpeg 本地剪辑

```bash
# 1. 图片序列 → 视频
ffmpeg -framerate 1/3 -i scene_%d.png -c:v libx264 -r 30 temp_scenes.mp4

# 2. 合并视频片段
ffmpeg -f concat -safe 0 -i filelist.txt -c copy assembled.mp4

# 3. 添加转场
ffmpeg -i assembled.mp4 -vf "fade=t=in:st=0:d=0.5,fade=t=out:st=2.5:d=0.5" trans.mp4

# 4. 添加 BGM（音量 30%）
ffmpeg -i trans.mp4 -i bgm.mp3 -c:v copy -c:a aac -shortest -af "volume=0.3" with_bgm.mp4

# 5. 添加字幕
ffmpeg -i with_bgm.mp4 -vf "subtitles=captions.srt:force_style='FontName=Microsoft YaHei,FontSize=16'" final.mp4

# 6. 裁剪时长
ffmpeg -i final.mp4 -t [目标时长] -c copy output.mp4
```

### 路径 B: 剪映创作者工具 API

从 `references/agents-workflow.md` 和 `references/workflow/` 中的完整工作流提取的 9 步调用序列：

```
1. create_draft(name, width=1920, height=1080, fps=30)      → 创建草稿
2. add_video_tracks(draft_id, video_path, start_time, duration) → 添加片段
3. add_keyframes(video_id, position, scale, rotation)        → 关键帧动画
4. add_effects(video_id, effect_type)                        → 视觉特效
5. add_captions(draft_id, texts, font="DouyinSansBold", size=48) → 字幕
6. add_audios(draft_id, bgm_path, volume=0.3)               → 音频
7. save_draft(draft_id, user_id)                             → 保存草稿
8. makeVideoByToken(content) → {worker, token}               → 提交渲染
9. getVideoDetail(workerId, token) 轮询 → {data: [最终视频URL]} → 获取结果
```

### Step 5.2: 节奏设计（导演级）

参考 `references/director-prompt-template.md` 的「节奏设计」章节：

**情绪递进时间轴**：
```
平静 (0-2s) → 蓄力 (2-3.5s) → 释放 (3.5-5s) → 定格 (最后0.5s)
```

**每 1.5 秒原则**：
- 配合音乐鼓点，情绪/运镜/特效复杂度逐步升级
- 最后 0.5 秒定格慢动作，打造"名场面"

---

## Phase 6: 导出与发布

### 交付物清单

```markdown
✅ 剧本文件（markdown）
✅ 分镜头表（含每个镜头的中英文导演级提示词）
✅ 原始图片素材（N 张）
✅ 视频片段素材（N 个）
✅ 剪辑脚本（FFmpeg CLI 或 剪映 API 调用序列）
✅ 最终 MP4 短视频文件 / 剪映草稿项目
```

### 平台格式

| 平台 | 分辨率 | 比例 | 编码 | 帧率 |
|------|--------|------|------|------|
| 抖音/快手 | 1080×1920 | 9:16 | H.264 | 30fps |
| B 站 | 1920×1080 | 16:9 | H.264 | 30/60fps |
| YouTube | 1920×1080 | 16:9 | H.264 | 30/60fps |
| 视频号 | 1080×1920 | 9:16 | H.264 | 30fps |

---

## 技能文件结构

```
universal-ai-prompt-engineer/
├── SKILL.md                        # 本文件 — 全链路主控文档 v3.0
├── references/
│   ├── agents-workflow.md          # 4 节点 Agent 工作流定义（AGENTS.md）
│   ├── director-prompt-template.md # 即梦视频导演级提示词模板（PPTX 提取）
│   ├── prompt-data-complete.md     # 20 章完整提示词数据体系（SKILL.md 完整版）
│   ├── formula-ai-prompt.md        # AI 提示词万能公式（ai-prompt-formula.skill）
│   ├── ai-prompt-formula.md        # AI 视频/图像提示词构建方法论
│   ├── prompt-universal-formula.md # AI 提示词万能公式技能手册
│   ├── prompt_templates.md         # 5 套提示词模板
│   ├── scene_background.md         # ①场景背景
│   ├── art_style.md                # ②风格艺术
│   ├── camera_language.md          # ③镜头语言
│   ├── shot_description.md         # ④镜头描述
│   ├── character_costume.md        # ⑤人物服装
│   ├── color_lighting.md           # ⑥色调光效
│   ├── culture_environment.md      # ⑦文化与环境
│   ├── details_decoration.md       # ⑧细节装饰
│   └── workflow/
│       ├── MANIFEST.yml            # 短视频工作流清单
│       └── qianghuabanshipingongzuoliu-draft.yaml  # 完整工作流定义
├── scripts/
│   ├── sd_model.py                 # SD 完整推理管线
│   ├── lora_train.py               # LoRA 微调训练
│   └── dpo_train.py                # DPO 偏好优化
└── assets/
    └── prompt_templates.md         # 可复制的模板文档
```

---

## 完整使用示例

### 用户输入："帮我做一个 5 秒科幻能量爆发短视频"

**技能全流程输出**：

**Phase 1 剧本** →
```
镜头 1 (0-2s): 赛博朋克天台，银发少女转身，中景固定
镜头 2 (2-3.5s): 掌心凝聚光球，推进至面部特写
镜头 3 (3.5-5s): 能量爆发，急速推镜+环绕，定格
```

**Phase 2 提示词** →
```
使用 SACSC 五步法：
S: 银发少女，未来战斗服，赛博朋克天台
A: slowly turn → raise hand → push forward
C: close-up → slow push-in → rapid orbit dolly
S: 影棚侧逆光，4K超清，电影级胶片颗粒感
C: 无闪烁/崩坏，五官无变形，无水印

输出完整视频提示词（中英双语），含 3 个分镜的详细描述
```

**Phase 3-4 生成** →
```
batch_image_gen: 生成 3 张场景图片（即梦 Seedream 5.0）
batch_video_gen: 每张图→3-5秒视频片段（即梦 Seedance 1.5 Pro）
```

**Phase 5 剪辑** →
```
方法A: FFmpeg 命令合成（concat + fade转场 + BGM + 字幕）
方法B: 剪映 API 调用（create_draft → add_tracks → ... → makeVideoByToken）
```

**Phase 6 导出** →
```
交付：final_科幻能量爆发_15s.mp4 / 剪映草稿项目
```

---

## 注意事项

1. **API 依赖**：即梦 Seedream/Seedance 需要 豆包 API 访问权限；SD 模型需要 GPU 环境
2. **剪映 API**：需安装剪映专业版 + 创作者工具（安装包已提供）
3. **FFmpeg**：提供的 `ffmpeg-8.1.1.tar.xz` 可本地编译
4. **内容安全**：不生成暴力、色情、政治敏感等内容
5. **版权意识**：BGM 使用免版权音乐，避免侵权
6. **AI 不确定性**：多次尝试同一提示词可能出现不同结果
7. **导演级提示词需练习**：参考 PPTX 中的「7 天精通计划」逐天训练

---

## 参考与致谢

- 工作流定义：Coze Workflow 强化版短视频工作流 + AGENTS.md 4 节点定义
- 提示词体系：AI提示词构建方法论 + 万能公式技能手册 + 20 章完整数据
- 导演级模板：即梦视频导演级提示词模板（沙漠扣扣）
- 视频剪辑：FFmpeg 8.1.1 + 剪映创作者工具 API
- 模型配置：Stable Diffusion Model Config（LoRA + DPO）
- 本技能融合了 6 大参考源、18 个数据文件、4 个 Agent 工作流

---

**技能作者**: AI Assistant
**最后更新**: 2026-06-29
**版本**: v3.0 (Directors Edition)
**适用平台**: 即梦AI Seedream/Seedance / Stable Diffusion / Midjourney / FFmpeg / 剪映专业版
